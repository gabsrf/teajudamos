<?php
session_start();

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    // A sessão não existe ou o papel não é 'admin'
    
    session_unset();
    session_destroy();

    header("Location: login.php");
    exit;
}


// Supondo que 'conexao.php' está disponível e configura a variável $conexao
include 'conexao.php';

// Verifica se a conexão com o banco de dados foi estabelecida
if (!isset($conexao) || $conexao->connect_error) {
    die("Erro de Conexão com o Banco de Dados.");
}

$feedbacks_positivos = [];
$feedbacks_negativos = [];
$feedbacks_resultado = false;

if ($conexao && !$conexao->connect_error) {

    $feedbacks_resultado = $conexao->query(
        "SELECT f.ID, f.AVALIACAO, f.TEXTO, u.ID as USUARIO_ID, u.NOME, u.DATA_ATUALIZACAO, 
        (CASE WHEN u.FOTO_PERFIL IS NOT NULL AND LENGTH(u.FOTO_PERFIL) > 0 THEN 1 ELSE 0 END) as TEM_FOTO
         FROM FEEDBACKS_SITE f 
         JOIN USUARIOS u ON f.USUARIO_ID = u.ID 
         ORDER BY f.AVALIACAO DESC, f.ID DESC"
    );

    if ($feedbacks_resultado && $feedbacks_resultado->num_rows > 0) {
        while ($fb = $feedbacks_resultado->fetch_assoc()) {
            if ($fb['AVALIACAO'] == 5) {
                $feedbacks_positivos[] = $fb;
            } elseif ($fb['AVALIACAO'] == 1) {
                $feedbacks_negativos[] = $fb;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliações dos Usuários | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">    

    <style>

        :root {
            --cor-principal: #fff; 
            --cor-destaque: #8B0091; 
            --cor-fundo-card: rgba(255, 255, 255, 0.1); 
            --cor-sombra: rgba(0, 0, 0, 0.2);
            --cor-positiva: #28a745; 
            --cor-negativa: #dc3545; 
            --gradiente-btn: linear-gradient(90deg, #8B0091 0%, #46004A 100%);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(#46004A, #8B0091);
            color: var(--cor-principal);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* --- Header/Título/Botão Voltar --- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            padding-bottom: 10px;
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        .header h1 {
            font-size: 2.8rem;
            color: var(--cor-principal);
            font-weight: 700;
            margin: 0;
            text-shadow: 0 3px 5px var(--cor-sombra);
        }

        .btn-voltar {
            background: var(--gradiente-btn);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px var(--cor-sombra);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-voltar:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.4);
            filter: brightness(1.1);
        }

        /* --- Estrutura de Colunas de Feedbacks --- */
        .feedbacks-wrapper {
            display: flex;
            gap: 40px;
        }

        .feedback-column {
            flex: 1;
            min-width: 0;
        }

        .column-title {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 3px solid var(--cor-destaque);
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--cor-principal);
        }

        /* Cores específicas para os títulos das colunas */
        .positives .column-title { border-color: var(--cor-positiva); }
        .negatives .column-title { border-color: var(--cor-negativa); }
        .positives .column-title i { color: var(--cor-positiva); }
        .negatives .column-title i { color: var(--cor-negativa); }

        /* --- Estilo do Card de Feedback --- */
        .feedback-card {
            background: var(--cor-fundo-card);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px var(--cor-sombra);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
        }
        
        .feedback-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .feedback-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed rgba(255, 255, 255, 0.3);
        }

        .feedback-header h4 {
            margin: 0;
            font-size: 1.2em;
            font-weight: 600;
            color: var(--cor-principal);
        }

        .feedback-text p {
            font-style: italic;
            font-size: 1em;
            margin: 0;
            padding-left: 5px;
        }

        /* Ícone de perfil / Foto */
        .profile-image, .default-profile-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
            border: 3px solid var(--cor-destaque);
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .default-profile-icon i {
            font-size: 30px;
            color: white;
        }

        /* Ícone de avaliação (Rosto) */
        .sentiment-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 2.5em;
        }

        .sentiment-icon.positive { color: var(--cor-positiva); }
        .sentiment-icon.negative { color: var(--cor-negativa); }

        /* --- Estilo do Botão Excluir (Lixeira) --- */
        .btn-excluir {
            position: absolute;
            top: 12px;
            /* Move para a esquerda do ícone de sentimento, mas esconde em mobile */
            right: 80px; 
            color: var(--cor-negativa);
            font-size: 1.8em;
            cursor: pointer;
            padding: 5px;
            border-radius: 50%;
            transition: color 0.3s, background-color 0.3s;
            z-index: 10;
            background-color: transparent;
            transition: color .5s ease-in-out, background-color .3s ease-in-out ;
        }

        .btn-excluir:hover {
            color: darkred;
        }
        
        /* --- Responsividade (Adaptação para Celular) --- */
        @media (max-width: 992px) {
            .feedbacks-wrapper {
                flex-direction: column;
                gap: 20px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            .header h1 {
                font-size: 2.2rem;
                margin-bottom: 15px;
            }
            
            .btn-voltar {
                width: 100%;
                justify-content: center;
            }
            
            .feedback-card {
                padding: 15px;
                margin-bottom: 15px;
            }
            
            .column-title {
                font-size: 1.8rem;
                margin-top: 30px;
            }
            
            /* Ajusta a posição do botão de lixeira no mobile */
            .btn-excluir {
                 right: 15px; /* Volta para o canto se o ícone de sentimento for removido */
                 top: 15px;
                 font-size: 1em;
            }
            .sentiment-icon {
                display: none; /* Oculta o ícone de sentimento no mobile para dar espaço */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Avaliações dos Usuários</h1>
            <a href="administrador.php" class="btn-voltar">
                <i class="fa-solid fa-arrow-left"></i> Voltar para Administração
            </a>
        </header>

        <div class="feedbacks-wrapper">

            <section class="feedback-column positives">
                <h2 class="column-title">
                    <i class="fa-solid fa-face-smile-beam"></i>
                    Positivos
                </h2>
                
                <?php if (!empty($feedbacks_positivos)): ?>
                    <?php foreach ($feedbacks_positivos as $fb): ?>
                        <div class="feedback-card">
                            <a href="excluir_feedback.php?id=<?php echo $fb['ID']; ?>" 
                               class="btn-excluir" 
                               title="Excluir Feedback"
                               onclick="return confirm('Tem certeza que deseja excluir este feedback? Esta ação é irreversível.');">
                                <i class="fa-solid fa-trash-can"></i>
                            </a>
                            <i class="sentiment-icon fa-solid fa-face-smile-beam positive"></i>

                            <div class="feedback-header">
                                <?php if ($fb['TEM_FOTO']): ?>
                                    <div class="profile-image">
                                        <img src="get_imagem_usuario.php?id=<?php echo $fb['USUARIO_ID']; ?>&v=<?php echo urlencode($fb['DATA_ATUALIZACAO'] ?? time()); ?>" alt="Perfil usuário">
                                    </div>
                                <?php else: ?>
                                    <div class="default-profile-icon">
                                        <i class="fa-solid fa-user"></i>
                                    </div>
                                <?php endif; ?>
                                <h4><?php echo htmlspecialchars($fb['NOME']); ?></h4>
                            </div>

                            <div class="feedback-text">
                                <p>"<?php echo htmlspecialchars($fb['TEXTO']); ?>"</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Nenhum feedback positivo encontrado no momento.</p>
                <?php endif; ?>
            </section>

            <section class="feedback-column negatives">
                <h2 class="column-title">
                    <i class="fa-solid fa-face-frown"></i>
                    Negativos
                </h2>

                <?php if (!empty($feedbacks_negativos)): ?>
                    <?php foreach ($feedbacks_negativos as $fb): ?>
                        <div class="feedback-card">
                            <a href="excluir_feedback.php?id=<?php echo $fb['ID']; ?>" 
                               class="btn-excluir" 
                               title="Excluir Feedback"
                               onclick="return confirm('Tem certeza que deseja excluir este feedback? Esta ação é irreversível.');">
                                <i class="fa-solid fa-trash-can"></i>
                            </a>
                            <i class="sentiment-icon fa-solid fa-face-frown negative"></i>

                            <div class="feedback-header">
                                <?php if ($fb['TEM_FOTO']): ?>
                                    <div class="profile-image">
                                        <img src="get_imagem_usuario.php?id=<?php echo $fb['USUARIO_ID']; ?>&v=<?php echo urlencode($fb['DATA_ATUALIZACAO'] ?? time()); ?>" alt="Perfil usuário">
                                    </div>
                                <?php else: ?>
                                    <div class="default-profile-icon">
                                        <i class="fa-solid fa-user"></i>
                                    </div>
                                <?php endif; ?>
                                <h4><?php echo htmlspecialchars($fb['NOME']); ?></h4>
                            </div>

                            <div class="feedback-text">
                                <p>"<?php echo htmlspecialchars($fb['TEXTO']); ?>"</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Nenhum feedback negativo encontrado no momento.</p>
                <?php endif; ?>
            </section>
        </div>
    </div>

</body>
</html>