<?php
session_start();

if (!isset($_SESSION['previa']['files']['anexo'])) {
    exit;
}

$index = (int)($_GET['index'] ?? 0);
$file_data = null;

// Busca no índice específico (0 ou 1)
if (!empty($_SESSION['previa']['files']['anexo'][$index])) {
    $file_data = $_SESSION['previa']['files']['anexo'][$index];
}

if ($file_data) {
    // Limpa buffer
    if (ob_get_level()) ob_end_clean();

    header("Content-Type: " . $file_data['tipo']);
    // Força o download com o nome original
    header("Content-Disposition: attachment; filename=\"" . addslashes($file_data['nome']) . "\""); 
    echo $file_data['conteudo'];
} else {
    echo "Arquivo não encontrado na prévia.";
}
exit;
?>