<?php
session_start();

// Verifica login
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php?erro=naologado');
    exit;
}

// Lógica de Prévia
$dados_previa = [];
$arquivos_previa = [];
$is_edit_mode = (isset($_GET['edit']) && $_GET['edit'] == 'previa' && isset($_SESSION['previa']));

if ($is_edit_mode) {
    $dados_previa = $_SESSION['previa']['post'];
    $arquivos_previa = $_SESSION['previa']['files'];
} else {
    unset($_SESSION['previa']);
}

// Arrays para campos dinâmicos
$observacoes = $dados_previa['obs'] ?? [""];
$objetivos = $dados_previa['obj'] ?? [""];
if (count($observacoes) > 1) $observacoes = array_filter($observacoes);
if (count($objetivos) > 1) $objetivos = array_filter($objetivos);

function is_selected($valor_db, $valor_option) {
    if (strtolower($valor_db ?? '') == strtolower($valor_option)) {
        return 'selected';
    }
    return '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Adicionar Lição</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* --- GERAL (DESKTOP) --- */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(#46004A, #8B0091);
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            padding: 160px 0 50px 0;
            overflow-y: auto;
        }

        .header_logo {
            position: absolute;
            top: -100px;
            left: 0;
            z-index: 1000;
        }

        .logo img {
            width: 300px;
            height: auto;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        /* Container Principal */
        .container {
            background-color: #d8a9e0;
            margin-top: -50px;
            border-radius: 12px;
            padding: 25px;
            width: 1000px !important; 
            min-height: 550px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: block;
            position: relative;
        }

        .titulo {
            border: none;
            font-size: 20px;
            color: #333;
            width: 100%;
            margin: auto;
            text-align: center;
            font-weight: bold;
            background: #fff;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .titulo:focus {
            outline: none;
            box-shadow: 0 0 0 3px #c806dec0;
        }

        .materia-select,
        .email-field {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 15px auto;
            width: 100%;
            text-align: left;
        }

        .materia-select label,
        .email-field label {
            font-weight: 600;
            color: #9a23d1ff;
            margin-bottom: 6px;
            font-size: 18px;
            align-self: flex-start;
        }

        .materia-select select,
        .email-field input {
            width: 100%;
            background: #fff;
            color: #6a2b88ff;
            border: 2.5px solid #C806DE;
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 17px;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .materia-select select:focus,
        .email-field input:focus {
            outline: none;
            border-color: #a855f7;
            box-shadow: 0 0 0 3px rgba(168, 85, 247, 0.2);
        }

        /* Cover Upload */
        .cover-upload {
            margin: 15px auto;
            width: 100%;
            text-align: center;
            background: #fff;
            border-radius: 12px;
            padding: 20px;
        }

        .cover-upload h3 {
            font-weight: 600;
            color: #6a2b88ff;
            margin-bottom: 10px;
        }

        #cover-input {
            display: none;
        }

        .cover-label {
            cursor: pointer;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border: 2px dashed #d8b4fe;
            border-radius: 12px;
            padding: 25px;
            width: 100%;
            transition: all 0.3s ease;
            background: #faf5ff;
        }

        .cover-label:hover {
            border-color: #c084fc;
            background: #f3e8ff;
        }

        .cover-label i {
            font-size: 50px;
            color: #a855f7;
            margin-bottom: 8px;
        }

        .cover-label p {
            font-weight: 500;
            color: #6b46c1;
        }

        .cover-preview img {
            display: block;
            margin: 20px auto 0 auto;
            width: 100%;
            max-height: 350px;
            border-radius: 10px;
            object-fit: contain;
            background-color: #f3f4f6;
        }

        .cover-preview .cover-wrap {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .remove-cover-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #ef4444;
            font-size: 18px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .remove-cover-btn:hover {
            color: #b91c1c;
            transform: scale(1.1);
        }

        /* Layout Horizontal (Lado a Lado no Desktop) */
        .conteudo {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }

        .box {
            flex: 1;
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            font-weight: bold;
        }

        .box .observacao p,
        .box .objetivo p {
            margin-bottom: 10px;
            margin-top: 20px;
            font-size: 18px;
            color: #9a23d1ff;
        }

        .conteudo-dinamico {
            position: relative;
            margin-bottom: 10px;
        }

        .box textarea {
            width: 100%;
            min-height: 95px;
            padding: 12px 30px 12px 16px;
            border-radius: 8px;
            resize: none;
            color: #333;
            font-size: 16px;
            font-weight: bold;
            border: 2.5px inset #C806DE;
            background-color: transparent;
            font-family: inherit;
        }

        .box textarea:focus {
            outline: none;
            border: 2.5px solid #e81cff;
        }

        .remove-field-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            color: #ef4444;
            font-size: 14px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remove-field-btn:hover {
            color: #b91c1c;
            background: #fff;
        }

        .mais {
            text-align: center;
            margin-top: 10px;
        }

        .mais i {
            font-size: 35px;
            cursor: pointer;
            color: purple;
            transition: transform 0.3s ease-in-out;
        }

        .mais i:hover {
            transform: scale(1.2);
        }

        /* Anexos */
        .input-group {
            margin-top: 20px;
        }

        .anexo-upload {
            position: relative;
            background: #faf5ff;
            border: 2px dashed #d8b4fe;
            border-radius: 10px;
            padding: 15px;
            margin-top: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: block;
            text-align: left;
        }

        .anexo-upload:hover {
            border-color: #c084fc;
            background-color: #f3e8ff;
        }

        .anexo-upload input[type="file"] {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            cursor: pointer;
        }

        .anexo-content {
            display: flex;
            align-items: center;
            gap: 15px;
            pointer-events: none;
        }

        .anexo-icon {
            font-size: 24px;
            color: #a855f7;
        }

        .anexo-text p {
            font-weight: 600;
            color: #6b46c1;
            margin: 0;
            font-size: 16px;
        }

        .anexo-text span {
            font-weight: 400;
            color: #8b5cf6;
            font-size: 14px;
        }

        /* Upload Imagens Laterais */
        .upload-container {
            background-color: #fff;
            border-radius: 12px;
            padding: 15px;
            margin-top: 10px;
        }

        .upload-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: #2d3748;
        }

        .upload-input {
            display: none;
        }

        .upload-box {
            border: 2px dashed #d8b4fe;
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .upload-box:hover {
            border-color: #c084fc;
            background-color: #faf5ff;
        }

        .upload-icon {
            font-size: 2rem;
            color: #a855f7;
            margin-bottom: 8px;
        }

        .upload-text {
            font-weight: 500;
            color: #374151;
            font-size: 1rem;
        }

        .single-preview {
            position: relative;
            margin-bottom: 15px;
            background: #f9fafb;
            border-radius: 8px;
        }

        .single-preview img {
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: contain;
            border-radius: 8px;
            border: 1px solid #eee;
        }

        .single-preview .remove-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: white;
            color: red;
            border-radius: 50%;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .salvar {
            display: flex;
            background-color: #C806DE;
            padding: 15px;
            border-radius: 10px;
            margin: 30px auto 0 auto;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            cursor: pointer;
            transition: transform .3s ease-in-out, background-color .3s ease-in-out;
            width: 100%;
            border: none;
            color: #fff;
        }

        .salvar:hover {
            transform: scale(1.01);
            background-color: #e81cff;
        }

        /* Toast Notification */
        .custom-toast {
            visibility: hidden;
            min-width: 300px;
            background-color: #dc2626;
            color: #fff;
            text-align: center;
            border-radius: 50px;
            padding: 12px 24px;
            position: fixed;
            z-index: 2000;
            left: 50%;
            top: 30px;
            transform: translateX(-50%);
            font-size: 16px;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(220, 38, 38, 0.4);
            opacity: 0;
            transition: opacity 0.4s ease, top 0.4s ease;
        }

        .custom-toast.show {
            visibility: visible;
            opacity: 1;
            top: 50px;
        }

        .custom-toast i {
            margin-right: 8px;
        }


        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 768px) {
            body {
                /* Ajuste de largura e comportamento para mobile */
                width: 100%;
                height: auto;
                min-height: 100vh;
                padding: 160px 0 50px 0;
            }

            .header_logo {
                position: absolute;
                top: -125px;
            }

            .logo img {
                min-width: 350px;
                width: 90%;
                margin-left: 20px;
            }

            .container {
                width: 95% !important;
                padding: 20px;
                margin-top: 50px;
            }

            .titulo {
                font-size: 30px;
                height: auto;
                padding: 15px;
            }

            /* Materia e Email - Aumentando fontes */
            .materia-select label,
            .email-field label {
                font-size: 30px;
            }

            .materia-select select,
            .email-field input {
                font-size: 27px;
                height: 60px;
            }

            /* Cover Upload - Mais destaque */
            .cover-upload h3 {
                font-size: 35px;
            }

            .cover-label i {
                font-size: 80px;
                margin-bottom: 30px;
            }

            .cover-label p {
                font-size: 30px;
            }

            .cover-preview img {
                max-height: 650px;
            }

            .remove-cover-btn {
                width: 40px;
                height: 40px;
                font-size: 24px;
            }

            /* Layout em Coluna Única */
            .conteudo {
                flex-direction: column;
            }

            .box {
                width: 100%;
                margin-bottom: 20px;
            }

            .box .observacao p,
            .box .objetivo p {
                font-size: 40px;
                margin-bottom: 35px;
            }

            .box textarea {
                font-size: 30px;
                height: 350px;
            }

            .box .mais i {
                font-size: 65px;
            }

            .remove-field-btn {
                width: 40px;
                height: 40px;
                font-size: 24px;
            }

            /* Anexos */
            .anexo-upload {
                padding: 25px;
                border-width: 3px;
            }

            .anexo-icon {
                font-size: 60px;
            }

            .anexo-text p {
                font-size: 30px;
            }

            .anexo-text span {
                font-size: 25px;
            }

            /* Upload Imagens */
            .upload-title {
                font-size: 40px;
            }

            .upload-icon {
                font-size: 100px;
            }

            .upload-text {
                font-size: 40px;
            }

            .single-preview img {
                max-height: 500px;
            }

            /* Botão Salvar */
            .salvar {
                font-size: 35px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <div id="toast-limit" class="custom-toast">
        <i class="fa-solid fa-circle-exclamation"></i> Limite de 3 itens atingido!
    </div>

    <div class="header_logo">
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </div>

    <form class="container" action="processar_previa.php" method="POST" enctype="multipart/form-data">

        <input type="text" class="titulo" name="titulo" placeholder="TÍTULO (Máximo 40 caracteres)" maxlength="40" required
            value="<?php echo htmlspecialchars($dados_previa['titulo'] ?? ''); ?>">

        <div class="materia-select">
            <label for="materia">Matéria:</label>
            <select id="materia" name="materia" required>
                <option value="" disabled <?php echo !$is_edit_mode ? 'selected' : ''; ?>>Selecione a matéria</option>
                <option value="portugues" <?php echo is_selected($dados_previa['materia'] ?? '', 'portugues'); ?>>Português</option>
                <option value="matematica" <?php echo is_selected($dados_previa['materia'] ?? '', 'matematica'); ?>>Matemática</option>
            </select>
        </div>

        <div class="email-field">
            <label for="email">E-mail (opcional):</label>
            <input type="email" id="email" name="email_contato"
                value="<?php echo htmlspecialchars($dados_previa['email_contato'] ?? ''); ?>">
        </div>

        <div class="cover-upload">
            <h3>Capa da lição</h3>

            <label for="cover-input" class="cover-label" style="<?php echo !empty($arquivos_previa['capa']) ? 'display:none' : 'display:inline-flex'; ?>">
                <i class="fa-solid fa-image"></i>
                <p>Clique para escolher uma imagem</p>
            </label>

            <input type="file" id="cover-input" name="capa" accept="image/*" onchange="previewCover(event)">

            <div class="cover-preview" id="cover-preview">
                <?php if (!empty($arquivos_previa['capa'])): ?>
                    <div class="cover-wrap">
                        <img src="get_imagem_previa.php?tipo=capa&t=<?php echo time(); ?>" alt="Capa">
                        <span class="remove-cover-btn" onclick="removeCover()"><i class="fa-solid fa-xmark"></i></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="conteudo">
            <div class="box">
                
                <div class="observacao">
                    <p>Métodos</p>
                    <div id="container-obs">
                        <div class="conteudo-dinamico">
                            <textarea name="obs[]" placeholder="Digite o método 1"><?php echo htmlspecialchars($observacoes[0] ?? ''); ?></textarea>
                        </div>
                        <?php for ($i = 1; $i < count($observacoes); $i++): ?>
                            <div class="conteudo-dinamico">
                                <textarea name="obs[]" placeholder="Digite o método"><?php echo htmlspecialchars($observacoes[$i]); ?></textarea>
                                <i class="fa-solid fa-xmark remove-field-btn" onclick="removeField(this)"></i>
                            </div>
                        <?php endfor; ?>
                    </div>
                    <div class="mais">
                        <i class="fa-solid fa-plus" title="Adicionar" onclick="addField('container-obs', 'obs[]', 'Digite o método')"></i>
                    </div>
                </div>

                <div class="objetivo" style="margin-top: 20px;">
                    <p>Objetivos</p>
                    <div id="container-obj">
                        <div class="conteudo-dinamico">
                            <textarea name="obj[]" placeholder="Digite o objetivo 1"><?php echo htmlspecialchars($objetivos[0] ?? ''); ?></textarea>
                        </div>
                        <?php for ($i = 1; $i < count($objetivos); $i++): ?>
                            <div class="conteudo-dinamico">
                                <textarea name="obj[]" placeholder="Digite o objetivo"><?php echo htmlspecialchars($objetivos[$i]); ?></textarea>
                                <i class="fa-solid fa-xmark remove-field-btn" onclick="removeField(this)"></i>
                            </div>
                        <?php endfor; ?>
                    </div>
                    <div class="mais">
                        <i class="fa-solid fa-plus" title="Adicionar" onclick="addField('container-obj', 'obj[]', 'Digite o objetivo')"></i>
                    </div>
                </div>

                <div class="input-group">
                    <label class="anexo-upload" for="file_anexo1">
                        <input type="file" id="file_anexo1" name="anexo1" onchange="updateFileName(this)">
                        <div class="anexo-content">
                            <i class="fa-solid fa-folder-open anexo-icon"></i>
                            <div class="anexo-text">
                                <p>Anexo 1 (opcional)</p>
                                <span class="file-name"><?php echo !empty($arquivos_previa['anexo'][0]) ? htmlspecialchars($arquivos_previa['anexo'][0]['nome']) : 'Clique para selecionar'; ?></span>
                            </div>
                        </div>
                    </label>

                    <label class="anexo-upload" for="file_anexo2" style="margin-top: 10px;">
                        <input type="file" id="file_anexo2" name="anexo2" onchange="updateFileName(this)">
                        <div class="anexo-content">
                            <i class="fa-solid fa-folder-open anexo-icon"></i>
                            <div class="anexo-text">
                                <p>Anexo 2 (opcional)</p>
                                <span class="file-name"><?php echo !empty($arquivos_previa['anexo'][1]) ? htmlspecialchars($arquivos_previa['anexo'][1]['nome']) : 'Clique para selecionar'; ?></span>
                            </div>
                        </div>
                    </label>
                </div>
            </div>

            <div class="box">
                <div class="imagem" style="font-size: 18px; color: #9a23d1ff; margin-bottom: 15px;">IMAGENS</div>
                <div class="upload-container">
                    <h3 class="upload-title">(Máximo 2)</h3>

                    <div id="preview-img1">
                        <?php if (!empty($arquivos_previa['img'][0])): ?>
                            <div class="single-preview">
                                <img src="get_imagem_previa.php?tipo=img&index=0&t=<?php echo time(); ?>">
                                <div class="remove-btn" onclick="removeImagePreview('preview-img1', 'upload-box1', 'input-img1')">×</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <label class="upload-label" id="upload-box1" style="<?php echo !empty($arquivos_previa['img'][0]) ? 'display:none' : ''; ?>">
                        <div class="upload-box">
                            <div class="upload-icon"><i class="fa-solid fa-image"></i></div>
                            <p class="upload-text">Adicionar Imagem 1</p>
                        </div>
                        <input type="file" name="img1" id="input-img1" class="upload-input" accept="image/*" onchange="previewImage(this, 'preview-img1', 'upload-box1')">
                    </label>

                    <div id="preview-img2">
                        <?php if (!empty($arquivos_previa['img'][1])): ?>
                            <div class="single-preview">
                                <img src="get_imagem_previa.php?tipo=img&index=1&t=<?php echo time(); ?>">
                                <div class="remove-btn" onclick="removeImagePreview('preview-img2', 'upload-box2', 'input-img2')">×</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <label class="upload-label" id="upload-box2" style="<?php echo !empty($arquivos_previa['img'][1]) ? 'display:none' : ''; ?>">
                        <div class="upload-box">
                            <div class="upload-icon"><i class="fa-solid fa-image"></i></div>
                            <p class="upload-text">Adicionar Imagem 2</p>
                        </div>
                        <input type="file" name="img2" id="input-img2" class="upload-input" accept="image/*" onchange="previewImage(this, 'preview-img2', 'upload-box2')">
                    </label>
                </div>
            </div>
        </div>

        <button type="submit" class="salvar"><?php echo $is_edit_mode ? 'Atualizar Prévia' : 'Visualizar Prévia'; ?></button>

    </form>

    <script>
        // Toast Notification
        function showLimitToast() {
            const toast = document.getElementById('toast-limit');
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Campos Dinâmicos
        function addField(containerId, fieldName, placeholder) {
            const container = document.getElementById(containerId);
            const currentFields = container.querySelectorAll('textarea').length; 

            if (currentFields >= 3) {
                showLimitToast();
                return;
            }

            const div = document.createElement('div');
            div.className = 'conteudo-dinamico';
            div.innerHTML = `
                <textarea name="${fieldName}" placeholder="${placeholder}"></textarea>
                <i class="fa-solid fa-xmark remove-field-btn" onclick="removeField(this)"></i>
            `;
            container.appendChild(div);
        }

        function removeField(btn) {
            btn.parentElement.remove();
        }

        // Preview Capa
        function previewCover(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('cover-preview');
            const label = document.querySelector('.cover-label');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    label.style.display = 'none';
                    preview.innerHTML = `
                        <div class="cover-wrap">
                            <img src="${e.target.result}" alt="Capa">
                            <span class="remove-cover-btn" onclick="removeCover()"><i class="fa-solid fa-xmark"></i></span>
                        </div>
                    `;
                };
                reader.readAsDataURL(file);
            }
        }

        function removeCover() {
            document.getElementById('cover-input').value = '';
            document.getElementById('cover-preview').innerHTML = '';
            document.querySelector('.cover-label').style.display = 'inline-flex';
        }

        // Preview Imagens
        function previewImage(input, previewId, boxId) {
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById(boxId).style.display = 'none';
                    document.getElementById(previewId).innerHTML = `
                        <div class="single-preview">
                            <img src="${e.target.result}">
                            <div class="remove-btn" onclick="removeImagePreview('${previewId}', '${boxId}', '${input.id}')">×</div>
                        </div>
                    `;
                };
                reader.readAsDataURL(file);
            }
        }

        function removeImagePreview(previewId, boxId, inputId) {
            document.getElementById(inputId).value = '';
            document.getElementById(previewId).innerHTML = '';
            document.getElementById(boxId).style.display = 'block';
        }

        // Anexos
        function updateFileName(input, num) {
            const fileNameDisplay = input.nextElementSibling.querySelector('.file-name');
            if (input.files.length > 0) {
                fileNameDisplay.textContent = input.files[0].name;
            } else {
                fileNameDisplay.textContent = 'Clique para selecionar';
            }
        }
    </script>

</body>
</html>