<?php
session_start();
include 'conexao.php'; // Inclui a conexão e o fuso horário

// (MODIFICADO) Define o cabeçalho como JSON
header('Content-Type: application/json');

// 1. Verifica se o usuário está logado
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Você precisa estar logado para avaliar.']);
    exit;
}

// 2. Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $licao_id = intval($_POST['licao_id']);
    $avaliacao = intval($_POST['avaliacao']); // 5 (Like) ou 1 (Dislike)
    $user_id = intval($_SESSION['user_id']);

    if ($licao_id == 0 || $user_id == 0) {
        echo json_encode(['status' => 'error', 'message' => 'Dados inválidos.']);
        exit;
    }

    if ($conexao->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Falha na conexão com o banco.']);
        exit;
    }

    // 3. Verifica se o usuário é o autor da lição
    $stmt_autor = $conexao->prepare("SELECT PROFESSOR_ID FROM LICAO WHERE ID = ?");
    $stmt_autor->bind_param("i", $licao_id);
    $stmt_autor->execute();
    $result_autor = $stmt_autor->get_result();
    
    if ($result_autor->num_rows > 0) {
        $licao_data = $result_autor->fetch_assoc();
        if ($licao_data['PROFESSOR_ID'] == $user_id) {
            // O usuário é o autor, não pode avaliar
            echo json_encode(['status' => 'error', 'message' => 'Você não pode avaliar sua própria lição.']);
            exit;
        }
    }
    $stmt_autor->close();


    // 4. Verifica se já existe um feedback desse usuário para essa lição
    $stmt_check = $conexao->prepare(
        "SELECT ID, AVALIACAO FROM FEEDBACK 
         WHERE LICAO_ID = ? AND PROFESSOR_AVALIADOR = ?"
    );
    $stmt_check->bind_param("ii", $licao_id, $user_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    $nova_avaliacao = 0; // 0 = Neutro, 1 = Dislike, 5 = Like

    if ($result_check->num_rows > 0) {
        // FEEDBACK JÁ EXISTE
        $feedback_existente = $result_check->fetch_assoc();
        $id_feedback = $feedback_existente['ID'];
        $avaliacao_antiga = $feedback_existente['AVALIACAO'];

        // Se o usuário clicou no mesmo botão (ex: curtiu e curtiu de novo),
        // vamos remover a avaliação (dar "unlike" ou "undislike")
        
        // (Lógica do "toggle-off")
        if (($avaliacao == 5 && $avaliacao_antiga >= 3) || ($avaliacao == 1 && $avaliacao_antiga <= 2 && $avaliacao_antiga > 0)) {
            // Clicou no mesmo botão, então remove (seta para 0)
            $nova_avaliacao = 0; // 0 = Neutro
        } else {
            // Clicou no botão oposto (ex: tinha curtido e clicou em não curtir)
            $nova_avaliacao = $avaliacao;
        }

        // 5. ATUALIZA (UPDATE) o feedback existente
        $stmt_update = $conexao->prepare(
            "UPDATE FEEDBACK SET AVALIACAO = ? 
             WHERE ID = ?"
        );
        $stmt_update->bind_param("ii", $nova_avaliacao, $id_feedback);
        $stmt_update->execute();
        $stmt_update->close();

    } else {
        // 6. INSERE (INSERT) um novo feedback
        $nova_avaliacao = $avaliacao; // Define a avaliação para o clique atual
        $stmt_insert = $conexao->prepare(
            "INSERT INTO FEEDBACK (AVALIACAO, LICAO_ID, PROFESSOR_AVALIADOR) 
             VALUES (?, ?, ?)"
        );
        $stmt_insert->bind_param("iii", $nova_avaliacao, $licao_id, $user_id);
        $stmt_insert->execute();
        $stmt_insert->close();
    }
    $stmt_check->close();

    // 7. (NOVO) Busca as novas contagens
    $stmt_count_like = $conexao->prepare("SELECT COUNT(*) as total FROM FEEDBACK WHERE LICAO_ID = ? AND AVALIACAO >= 3");
    $stmt_count_like->bind_param("i", $licao_id);
    $stmt_count_like->execute();
    $like_count = $stmt_count_like->get_result()->fetch_assoc()['total'];
    $stmt_count_like->close();

    $stmt_count_dislike = $conexao->prepare("SELECT COUNT(*) as total FROM FEEDBACK WHERE LICAO_ID = ? AND AVALIACAO <= 2 AND AVALIACAO > 0");
    $stmt_count_dislike->bind_param("i", $licao_id);
    $stmt_count_dislike->execute();
    $dislike_count = $stmt_count_dislike->get_result()->fetch_assoc()['total'];
    $stmt_count_dislike->close();

    $conexao->close();

    // 8. (MODIFICADO) Retorna a resposta JSON
    echo json_encode([
        'status' => 'success',
        'like_count' => $like_count,
        'dislike_count' => $dislike_count,
        'voto_atual' => $nova_avaliacao // 0, 1, ou 5
    ]);
    exit;

} else {
    // Se não for POST
    echo json_encode(['status' => 'error', 'message' => 'Método de requisição inválido.']);
    exit;
}
?>