<?php
session_start();

if (!isset($_SESSION['previa']['files'])) {
    exit;
}

$tipo = $_GET['tipo'] ?? 'img'; // 'capa' ou 'img'
$index = (int)($_GET['index'] ?? 0);

$file_data = null;

if ($tipo == 'capa') {
    if (!empty($_SESSION['previa']['files']['capa'])) {
        $file_data = $_SESSION['previa']['files']['capa'];
    }
} elseif ($tipo == 'img') {
    // Busca no índice específico (0 ou 1)
    if (!empty($_SESSION['previa']['files']['img'][$index])) {
        $file_data = $_SESSION['previa']['files']['img'][$index];
    }
}

if ($file_data) {
    // Limpa qualquer buffer de saída anterior para não corromper a imagem
    if (ob_get_level()) ob_end_clean();
    
    header("Content-Type: " . $file_data['tipo']);
    echo $file_data['conteudo'];
}
exit;
?>