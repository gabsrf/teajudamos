<?php
session_start();



if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    // A sessão não existe ou o papel não é 'admin'
    
    // Opcional: Destrói qualquer sessão existente e redireciona para o login
    session_unset();
    session_destroy();

    // Redireciona o usuário de volta para a tela de login principal
    header("Location: login.php");
    exit;
}


define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');

try {
    // Cria a string DSN (Data Source Name)
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    
    // Configurações PDO
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lança exceções em caso de erro
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Retorna resultados como array associativo
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $conexao = new PDO($dsn, DB_USER, DB_PASS, $options);
    

} catch (\PDOException $e) {
    $erro = true;
    $mensagem = "Erro na conexão com o banco de dados: " . $e->getMessage();
    // Em produção, a mensagem acima deve ser genérica por segurança
}




?>


<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    
    
    <title>Central de Administração</title>
    <style>
        :root {
            --bg-start: #46004A;
            --bg-end: #8B0091;
            --card-base: rgba(139, 0, 145, 0.25); 
            --accent-light: #FFC0FF; 
            --accent-vibrant: #D83FFF; 
        }

        body {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(var(--bg-start), var(--bg-end));
            width: 100%;
            min-height: 100vh;
            overflow-x: hidden;
        }
        * { 
            box-sizing: border-box; 
        }
        
        .back-button {
    position: absolute;
    top: 30px;
    left: 30px;
    z-index: 10;
    display: inline-flex;
    align-items: center;
    padding: 10px 20px;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(5px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 10px;
    text-decoration: none;
    color: var(--accent-light);
    font-size: 16px;
    font-weight: 600;
    transition: all 0.3s ease;
}
.back-button i {
    margin-right: 8px;
    font-size: 18px;
    color: var(--accent-vibrant);
    transition: margin-right 0.3s ease;
}
.back-button:hover {
    background: rgba(255, 255, 255, 0.2);
    border-color: var(--accent-vibrant);
    color: white;
    box-shadow: 0 4px 15px rgba(216, 63, 255, 0.4);
    transform: translateY(-2px);
}
.back-button:hover i {
    margin-right: 12px;
}

        /* Layout e Componentes */
        .app-container {
            width: 100%;
            min-height: 100vh;
            padding: 60px 40px;
            position: relative;
            z-index: 2;
        }
        .header {
            text-align: center;
            margin-bottom: 60px;
            animation: fadeInDown 0.8s ease-out;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .main-title {
            font-size: 48px;
            font-weight: 700;
            color: #ffffff;
            margin: 0 0 16px 0;
            text-shadow: 0 0 25px rgba(216, 63, 255, 0.6); 
        }
        .subtitle {
            font-size: 20px;
            color: var(--accent-light); 
            margin: 0;
        }
        .cards-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 32px;
            padding: 0 20px;
        }
        .admin-card {
            /* Fundo Semi-Transparente e Blurry */
            background: var(--card-base); 
            backdrop-filter: blur(10px);
            /* Borda usando a cor vibrante */
            border: 2px solid rgba(216, 63, 255, 0.3); 
            border-radius: 24px;
            padding: 40px 32px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.8s ease-out backwards;
        }

        /* Atrasos de Animação */
        .admin-card:nth-child(1) { animation-delay: 0.1s; }
        .admin-card:nth-child(2) { animation-delay: 0.2s; }
        .admin-card:nth-child(3) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Efeito de Brilho ao Hover (Swipe) */
        .admin-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            /* Brilho magenta/roxo */
            background: linear-gradient(90deg, transparent, rgba(216, 63, 255, 0.3), transparent); 
            transition: left 0.5s;
        }
        .admin-card:hover::before { left: 100%; }

        /* Hover e Active */
        .admin-card:hover {
            transform: translateY(-8px) scale(1.02);
            /* Borda e sombra mais intensa */
            border-color: rgba(216, 63, 255, 0.8);
            box-shadow: 0 20px 60px rgba(216, 63, 255, 0.5); 
            background: rgba(139, 0, 145, 0.45); /* Base mais opaca */
        }
        .admin-card:active { transform: translateY(-4px) scale(1); }

        .card-icon-wrapper {
            width: 80px;
            height: 80px;
            margin: 0 auto 24px;
            /* Gradiente vibrante para o ícone */
            background: linear-gradient(135deg, var(--accent-vibrant) 0%, #A600A6 100%); 
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            /* Sombra do ícone */
            box-shadow: 0 8px 24px rgba(216, 63, 255, 0.4); 
            transition: all 0.3s ease;
            color: white; /* Cor do ícone */
        }
        .admin-card:hover .card-icon-wrapper {
            transform: rotate(5deg) scale(1.1);
            box-shadow: 0 12px 32px rgba(216, 63, 255, 0.6);
        }
        .card-icon i { font-size: 40px; }
        
        .card-title {
            font-size: 28px;
            font-weight: 600;
            color: #ffffff;
            margin: 0 0 16px 0;
            text-align: center;
        }
        .card-description {
            font-size: 16px;
            color: var(--accent-light);
            margin: 0 0 24px 0;
            text-align: center;
            line-height: 1.6;
        }
        .card-button {
            width: 100%;
            padding: 14px 28px;
            background: linear-gradient(135deg, #FF88FF 0%, var(--accent-vibrant) 100%); 
            color: var(--bg-start); 
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(216, 63, 255, 0.5);
        }
        .card-button:hover {
            background: linear-gradient(135deg, var(--accent-vibrant) 0%, #FF88FF 100%);
            box-shadow: 0 8px 25px rgba(216, 63, 255, 0.7);
            transform: translateY(-2px);
            color: white;
        }
        .card-button:active { transform: translateY(0); }

        @media (max-width: 768px) {
            .app-container { padding: 40px 20px; }
            .main-title { font-size: 36px; }
            .subtitle { font-size: 18px; }
            .cards-wrapper {
                grid-template-columns: 1fr;
                gap: 24px;
            }
            .back-button {
            top: 20px;
            left: 20px;
            padding: 8px 16px;
            font-size: 14px;
    }
        }
    </style>
    <style>@view-transition { navigation: auto; }</style>
</head>
<body>
    <a href="index.php" class="back-button" aria-label="Voltar para a página inicial"><i class="fa-solid fa-arrow-left"></i>Voltar para a Home</a>
    <div class="app-container">
        <header class="header">
            <h1 class="main-title" id="mainTitle">Central de Administração</h1>
            <p class="subtitle" id="subtitle">Painel Administrativo</p>
        </header>
        <div class="cards-wrapper">
            <article class="admin-card" data-page="users">
                <div class="card-icon-wrapper">
                    <div class="card-icon"><i class="fa-solid fa-user"></i></div>
                </div>
                <h2 class="card-title" id="card1Title">Usuários</h2>
                <p class="card-description" id="card1Description">Aprovação das solictações de cadastros dos usuários</p>
                <a href="aprovacao_cadastro.php"> <button class="card-button" aria-label="Acessar gerenciamento de usuários">Acessar</button> </a>
            </article>
            <article class="admin-card" data-page="content">
                <div class="card-icon-wrapper">
                    <div class="card-icon"><i class="fa-solid fa-pencil"></i></div>
                </div>
                <h2 class="card-title" id="card2Title">Conteúdo</h2>
                <p class="card-description" id="card2Description">Administrar as lições publicadas pelos usuários</p>
              <a href="admin_licoes.php"> <button class="card-button" aria-label="Acessar gerenciamento de conteúdo">Acessar</button> </a>  
            </article>
            <article class="admin-card" data-page="analytics">
                <div class="card-icon-wrapper">
                    <div class="card-icon"><i class="fa-solid fa-comment"></i></div>
                </div>
                <h2 class="card-title" id="card3Title">Feedbacks</h2>
                <p class="card-description" id="card3Description">Visualize os feedbacks dos usuários</p>
                <a href="admin_feedback.php"> <button class="card-button" aria-label="Acessar análises e relatórios">Acessar</button> </a>
            </article>
        </div>
    </div>
</body>
</html>