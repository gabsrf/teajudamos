<?php
session_start(); 

// Lógica para buscar foto de perfil do usuário logado
$usuario_logado = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$nome_usuario = "";
$foto_perfil_existe = false;
$user_id = 0;

include 'conexao.php'; 

if ($usuario_logado) {
    $user_id = $_SESSION['user_id'];
    
    if ($conexao && !$conexao->connect_error) {
        $stmt_user = $conexao->prepare("SELECT NOME, FOTO_PERFIL, DATA_ATUALIZACAO FROM USUARIOS WHERE ID = ?");
        if ($stmt_user) {
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            
            if ($result_user->num_rows > 0) {
                $user_data = $result_user->fetch_assoc();
                $full_name = $user_data['NOME'] ?? 'Perfil';
                $first_name = explode(' ', $full_name)[0];
                $nome_usuario = htmlspecialchars($first_name);
                $foto_perfil_existe = !empty($user_data['FOTO_PERFIL']);
            }
            $stmt_user->close();
        }
    }
}

?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width" >
  <title>TEAJUDAMOS - Blog</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

  
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: white;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    header {
      background-color: purple;
      width: 100%;
      padding: 10px 30px;
      border-radius: 4.3px;
      display: flex;
      align-items: center;
      justify-content: space-between; 
      z-index: 1;
      height: 80px;
      position: fixed;
      top: 0;
      left: 0;
    }


    .logo img {
      margin-top: 15px;
      width: 250px;
      height: auto;
      object-fit: cover;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    .logo img:hover {
      transform: scale(1.1);
    }

    nav {
      display: flex;
      gap: 5px;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
    }
/* From Uiverse.io by gharsh11032000 */ 
.menu {
  font-size: 16px;
  line-height: 1.6;
  color: white;
  width: fit-content;
  display: flex;
  background-color: rgb(76, 0, 76);
  width: 100%;
  list-style: none;
  font-weight: 600;
}

.menu a {
  text-decoration: none;
  color: white;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

.menu .link {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 10px 36px;
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .link::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 85%;
  height: 80%;
  background-color: purple;
  z-index: -1;
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .link svg {
  width: 14px;
  height: 14px;
  margin-right: -10px;
  fill: white;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .item {
  position: relative;
}

.menu .item .submenu {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: absolute;
  top: 100%;
  border-radius: 0 0 16px 16px;
  left: 0;
  width: 100%;
  overflow: hidden;
  border: 1px solid #cccccc;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-12px);
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
  z-index: 1;
  pointer-events: none;
  list-style: none;
  background-color: purple;
}

.menu .item:hover .submenu {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
  pointer-events: auto;
  border-top: transparent;
  border-color: purple;
  filter: brightness(1.2);
}

.menu .item:hover .link {
  color: #ffffff;
  border-radius: 16px 16px 0 0;
}

.menu .item:hover .link::after {
  transform: scaleX(1);
  transform-origin: right;
}

.menu .item:hover .link svg {
  fill: #ffffff;
  transform: rotate(-180deg);
}

.submenu .submenu-item {
  width: 100%;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-link {
  display: block;
  padding: 12px 24px;
  width: 100%;
  position: relative;
  text-align: center;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-item:last-child .submenu-link {
  border-bottom: none;
}

.submenu .submenu-link::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  transform: scaleX(0);
  width: 100%;
  height: 100%;
  background-color: purple;
  filter: brightness(1.2);
  z-index: -1;
  transform-origin: left;
  transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-link:hover:before {
  transform: scaleX(1);
  transform-origin: right;
}

.submenu .submenu-link:hover {
  color: #ffffff;
}

   .profile-icon {
        position: relative;
        display: inline-block;
    }

    .profile-icon i {
        cursor: pointer;
        transition: transform 0.3s ease-in-out;
        border-radius: 100px;
        position: relative;
        z-index: 1;
        font-size: 50px;
        color: #000000ff;
        transition: color 0.35s ease-in-out, transform 0.3s ease-in-out;
    }
    

    .profile-icon:hover i {
        transform: scale(1.15);
        cursor: pointer;
        color: white;
    }

    .profile-icon img.profile-pic {
        font-size: 50px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #000000ff;
        cursor: pointer;
        transition: transform 0.3s ease-in-out, border-color 0.35s ease-in-out;
        position: relative;
        z-index: 1;
    }

    .profile-icon:hover img.profile-pic {
        transform: scale(1.15);
        border-color: white;
    }
    
    /* From Uiverse.io by reglobby */ 
.user-profile {
  width: 131px;
  height: 51px;
  border-radius: 15px;
  cursor: pointer;
  transition: 0.3s ease;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
}

.user-profile:hover,
.user-profile:focus {
  background-color: rgba(185, 0, 185);
  box-shadow: 0 0 10px rgba(185, 0, 185);
  outline: none;
}

.user-profile-inner {
  width: 127px;
  height: 47px;
  border-radius: 13px;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  color: #fff;
  font-weight: 600;
}

.user-profile-inner svg {
  width: 27px;
  height: 27px;
  fill: #fff;
}

    main {
      width: 100%;
      padding: 130px 0;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 40px;  
      background: linear-gradient( 180deg, purple, #7c24a1ff );
      padding: none;
      position: relative;
      height: 100%;
    }

    /*card do blog*/
    .blog-card {
      background-color: #800080;
      color: white;
      border-radius: 12px;
      overflow: hidden;
      width: 300px;
      min-height: 400px;
      display: flex;
      flex-direction: column;
      cursor: pointer;
      transition: transform .3s ease, box-shadow .3s ease;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .blog-card:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    }

    .blog-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .blog-card-content {
      padding: 15px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .blog-card-content h3 {
      font-size: 20px;
      margin-bottom: 10px;
    }

    .blog-card-content p {
      font-size: 14px;
      opacity: 0.9;
      margin-bottom: 15px;
    }

    .blog-card-content .read-more {
      color: #fff;
      font-weight: bold;
      text-decoration: none;
      align-self: flex-start;
      transition: color 0.3s, margin-left 0.3s;
    }

    .blog-card:hover .read-more {
      margin-left: 35%;
    }

    .blog-card-content .read-more:hover {
      color: #ee8feeff;
    }

    /* Footer */
    footer {
      width: 100%;
      background: linear-gradient(90deg, rgb(76,0,76), purple);
      color: white;
      padding: 50px 0 20px;
      font-family: 'Poppins', sans-serif;
    }

    .footer-container {
      width: 90%;
      margin: auto;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
    }

.footer-logo img {
  position: absolute;
  margin-top: -100px;
  width: 400px;
  margin-left: -30px;
}
    .footer-links, .footer-contact {
      min-width: 200px;
    }

    .footer-links h3, .footer-contact h3 {
      font-size: 18px;
      margin-bottom: 15px;
      color: #fff;
      position: relative;
    }

    .footer-links ul, .footer-contact ul {
      list-style: none;
      padding: 0;
    }

    .footer-links ul li, .footer-contact ul li {
      margin: 10px 0;
      font-size: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .footer-links ul li a {
      color: white;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .footer-links ul li a:hover {
      color: #d63de4;
    }

    .footer-bottom {
      text-align: center;
      border-top: 1px solid rgba(255,255,255,0.2);
      margin-top: 50px;
      padding-top: 15px;
      font-size: 14px;
      color: #e0d6ff;
    }

    @media (max-width: 480px) {
        body{
    width: 480px;
  }

      header {
        height: 60px; 
        padding: 10px 15px; 
      }

      .logo img {
        width: 220px; 
        margin-top: 15px;
        margin-left: -15px;
      }

      nav {
        width: 100px;
        margin-left: 10%;
      }

      .menu {
        font-size: 14px;
      }

      .menu a {
  text-decoration: none;
  color: white;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

.menu .submenu-item a{
  justify-content: center;
  align-items: center;
  margin: auto;
  display: flex;
}

.menu .link {
  position: relative;
  margin-left: -8px;
  gap: 8px;
  padding: 10px 36px;
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .link::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 80%;
  background-color: purple;
  z-index: -1;
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .link svg {
  width: 14px;
  height: 14px;
  fill: white;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.menu .item {
  position: relative;
}

.menu .item .submenu {
  display: flex;
  
  position: absolute;
  top: 100%;
  border-radius: 0 0 16px 16px;
  left: 0;
  width: 90%;
  overflow: hidden;
  border: 1px solid #cccccc;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-12px);
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
  z-index: 1;
  pointer-events: none;
  list-style: none;
  background-color: purple;
}

.menu .item:hover .submenu {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
  pointer-events: auto;
  border-top: transparent;
  border-color: purple;
  filter: brightness(1.2);
}

.menu .item:hover .link {
  color: #ffffff;
  border-radius: 16px 16px 0 0;
}

.menu .item:hover .link::after {
  transform: scaleX(1);
  transform-origin: right;
}

.menu .item:hover .link svg {
  fill: #ffffff;
  transform: rotate(-180deg);
}

.submenu .submenu-item {
  width: 80%;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-link {
  display: block;
  padding: 12px 24px;
  width: 80%;
  position: relative;
  text-align: center;
  transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-item:last-child .submenu-link {
  border-bottom: none;
}

.submenu .submenu-link::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  transform: scaleX(0);
  width: 80%;
  height: 80%;
  background-color: purple;
  filter: brightness(1.2);
  z-index: -1;
  transform-origin: left;
  transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
}

.submenu .submenu-link:hover:before {
  transform: scaleX(1);
  transform-origin: right;
}

.submenu .submenu-link:hover {
  color: #ffffff;
}


      .user-profile {
        width: 100px;
        height: 40px;
        border-radius: 12px;
    }

    .user-profile-inner {
        width: 96px;
        height: 36px;
        gap: 8px;
        font-size: 0.9rem;
    }

    .user-profile-inner svg {
        width: 20px;
        height: 20px;
    }


        footer {
        padding: 30px 0 10px;
    }

    .footer-container {
        flex-direction: column; /* Empilha os itens do footer */
        align-items: center;
        gap: 30px;
        text-align: center;
    }

    .footer-logo img {
        display: none;
    }
    
    .footer-links h3, .footer-contact h3 {
        text-align: center;
    }

    .footer-links h3::after, .footer-contact h3::after {
        left: 50%;
        transform: translateX(-50%);
    }

    .footer-links ul li, .footer-contact ul li {
        justify-content: center; 
    }

    .footer-bottom {
        margin-top: 30px;
    }
}



  </style>
</head>

<body>
  <header>
    <a href="index.php" class="logo"><img src="imagens/logo-teajudamos.png" alt="logo"></a>
    <nav>
      <!-- From Uiverse.io by gharsh11032000 --> 
<div class="menu">
  <div class="item">
    <a href="#" class="link">
      <span> Mais </span>
      <svg viewBox="0 0 360 360" xml:space="preserve">
        <g id="SVGRepo_iconCarrier">
          <path
            id="XMLID_225_"
            d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393 c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393 s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"
          ></path>
        </g>
      </svg>
    </a>

    <div class="submenu">
      <div class="submenu-item">
        <a href="tarefas.php" class="submenu-link"> Tarefas </a>
      </div>
      <div class="submenu-item">
        <a href="feedback.php" class="submenu-link"> Feedback </a>
      </div>
      <div class="submenu-item">
        <a href="#footer" class="submenu-link"> Contato </a>
      </div>
      <div class="submenu-item">
        <a href="index.php" class="submenu-link"> Início </a>
      </div>
        
    </div>
  </div>
</div>

    </nav>
    
    
 <div class="profile-icon">

  <?php if ($usuario_logado): ?>

      <a href="perfil.php" style="text-decoration: none;">

          <?php
            echo $foto_perfil_existe
                ? '<img class="profile-pic" src="get_imagem_usuario.php?id='. $user_id .'&v='. urlencode($user_data['DATA_ATUALIZACAO'] ?? time()) .'" alt="'. $nome_usuario .'" />'
                : '<i class="fa-solid fa-user-circle"></i>';
          ?>

      </a>

  <?php else: ?>

      <a href="login.php" style="text-decoration: none;">
        <div aria-label="User Login Button" tabindex="0" role="button" class="user-profile">
          <div class="user-profile-inner">
            <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                 viewBox="0 0 24 24">
                <g id="Layer_2">
                  <path d="m15.626 11.769a6 6 0 1 0 -7.252 0 9.008 9.008 0 0 0 -5.374 8.231 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 9.008 9.008 0 0 0 -5.374-8.231zm-7.626-4.769a4 4 0 1 1 4 4 4 4 0 0 1 -4-4zm10 14h-12a1 1 0 0 1 -1-1 7 7 0 0 1 14 0 1 1 0 0 1 -1 1z">
                  </path>
                </g>
            </svg>
            <p>Entrar</p>
          </div>
        </div>
      </a>

  <?php endif; ?>

</div>

  </header>

  <main>
    <div class="blog-card">
      <img src="https://www.gov.br/mec/pt-br/assuntos/noticias/2025/abril/crescem-matriculas-de-alunos-com-transtorno-do-espectro-autista/censo-escolar_coletiva_luis-fortes.jpg/@@images/64977bf1-c69c-4836-ab82-22e001ebf89e.jpeg" >
      <div class="blog-card-content">
        <h3>Crescem matrículas de alunos com transtorno do espectro autista</h3>
        <p>a educação básica, as matrículas de estudantes com transtorno do espectro autista (TEA) aumentaram 44,4%, entre 2023 e 2024. De acordo com o Censo Escolar 2024, o número saltou de 636.202 para 918.877 nesse período. O Ministério da Educação (MEC) e o Instituto Nacional de Estudos e Pesquisas Educacionais Anísio Teixeira (Inep) contextualizaram os resultados da primeira etapa da pesquisa estatística em coletiva de imprensa,no dia 9 de abril.  </p>
        <a href="https://www.gov.br/mec/pt-br/assuntos/noticias/2025/abril/crescem-matriculas-de-alunos-com-transtorno-do-espectro-autista" target="_blank" class="read-more">Ler mais →</a>
      </div>
    </div>

    <div class="blog-card">
      <img src="https://admin.cnnbrasil.com.br/wp-content/uploads/sites/12/2025/05/autismo.jpg?w=1200&h=900&crop=0" >
      <div class="blog-card-content">
        <h3>IBGE divulga dados sobre educação de pessoas com autismo</h3>
        <p>Além de recortes por gênero, raça e faixa etária, o levantamento disponibilizou dados envolvendo a educação de pessoas com TEA. A taxa de escolarização (proporção de estudantes em determinada faixa etária) de pessoas com autismo com mais de 6 anos é superior (36,9%) em relação à observada na população geral (24,3%), segundo o IBGE. </p>
        <a href="https://www.cnnbrasil.com.br/educacao/ibge-divulga-dados-sobre-educacao-de-pessoas-com-autismo/" target="_blank" class="read-more">Ler mais →</a>
      </div>
    </div>

    <div class="blog-card">
      <img src="https://mediaserver.almg.gov.br/acervo/283/508/2283508.jpg" alt="Neurodiversidade">
      <div class="blog-card-content">
        <h3> Inclusão de alunos com autismo na escola ainda é desafio</h3>
        <p>Apesar dos avanços recentes, a inclusão de pessoas com transtorno do espectro autista (TEA) na escola e no mercado de trabalho ainda precisa superar inúmeros obstáculos. A avaliação foi feita pelos participantes do Debate Público Autismo, Saúde e Educação – Desafios e perspectivas, realizado pela Comissão de Defesa da Pessoa com Deficiência da Assembleia Legislativa de Minas Gerais (ALMG). (31/3/25).</p>
        <a href="https://www.almg.gov.br/comunicacao/noticias/arquivos/Inclusao-de-alunos-com-autismo-na-escola-ainda-e-desafio/" target="_blank" class="read-more">Ler mais →</a>
      </div>
    </div>
  </main>
  

  <footer id="footer">
    <div class="footer-container">
      <div class="footer-logo">
        <img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS">
      </div>

      <?php 
// 1. Verifica se a sessão está iniciada e se o usuário é administrador
// É crucial garantir que session_start(); foi chamado no topo da sua página.
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
          <h3>Navegação</h3>
          <ul>

        <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
        <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
        <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
        <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
        
        <?php 
        // 3. Bloco Condicional para Administrador
        if ($is_admin) {
            // Este link só será renderizado se o papel for 'admin'
            // Utilize o ícone 'fa-user-cog' para o ícone de administrador
            echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
        }
        ?>

        <!-- 4. Link de Entrar/Sair Dinâmico -->
        <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

            
          </ul>
        </div>
      <div class="footer-contact">
        <h3>Contato</h3>
        <ul>
          <li><i class="fa-solid fa-envelope"></i> teajudamos@gmail.com</li>
          <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>

        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
    </div>
  </footer>
</body>
</html>
