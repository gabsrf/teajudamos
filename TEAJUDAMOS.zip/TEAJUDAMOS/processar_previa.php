<?php
session_start();

// Limpa qualquer prévia antiga para evitar misturar dados
unset($_SESSION['previa']);

// 1. Salva todos os dados de TEXTO na sessão
$_SESSION['previa']['post'] = $_POST;

// Inicializa o array de arquivos
$_SESSION['previa']['files'] = [
    'capa' => null,
    'img' => [0 => null, 1 => null],   // Garante os índices 0 e 1
    'anexo' => [0 => null, 1 => null] // Garante os índices 0 e 1
];

// 2. Processa a CAPA
if (isset($_FILES['capa']) && $_FILES['capa']['error'] == 0) {
    $_SESSION['previa']['files']['capa'] = [
        'nome' => $_FILES['capa']['name'],
        'tipo' => $_FILES['capa']['type'],
        'conteudo' => file_get_contents($_FILES['capa']['tmp_name'])
    ];
}

// 3. Processa IMAGEM 1 (Salva no índice 0)
if (isset($_FILES['img1']) && $_FILES['img1']['error'] == 0) {
    $_SESSION['previa']['files']['img'][0] = [
        'nome' => $_FILES['img1']['name'],
        'tipo' => $_FILES['img1']['type'],
        'conteudo' => file_get_contents($_FILES['img1']['tmp_name'])
    ];
}

// 4. Processa IMAGEM 2 (Salva no índice 1)
if (isset($_FILES['img2']) && $_FILES['img2']['error'] == 0) {
    $_SESSION['previa']['files']['img'][1] = [
        'nome' => $_FILES['img2']['name'],
        'tipo' => $_FILES['img2']['type'],
        'conteudo' => file_get_contents($_FILES['img2']['tmp_name'])
    ];
}

// 5. Processa ANEXO 1 (Salva no índice 0)
if (isset($_FILES['anexo1']) && $_FILES['anexo1']['error'] == 0) {
    $_SESSION['previa']['files']['anexo'][0] = [
        'nome' => $_FILES['anexo1']['name'],
        'tipo' => $_FILES['anexo1']['type'],
        'conteudo' => file_get_contents($_FILES['anexo1']['tmp_name'])
    ];
}

// 6. Processa ANEXO 2 (Salva no índice 1)
if (isset($_FILES['anexo2']) && $_FILES['anexo2']['error'] == 0) {
    $_SESSION['previa']['files']['anexo'][1] = [
        'nome' => $_FILES['anexo2']['name'],
        'tipo' => $_FILES['anexo2']['type'],
        'conteudo' => file_get_contents($_FILES['anexo2']['tmp_name'])
    ];
}

// Redireciona para a página de pré-visualização
header('Location: visualizacao_licao.php');
exit;
?>