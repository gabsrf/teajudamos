<?php
session_start();
include 'conexao.php';

// 1. Verifica se o usuário está logado
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php?erro=naologado');
    exit;
}

// 2. Verifica se foi enviado via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $texto = $_POST['feedback'] ?? '';
    $emocao = $_POST['emocao'] ?? '';
    $user_id = $_SESSION['user_id'];

    // Define a nota (1 ou 5)
    $nota = 0;
    if ($emocao === 'feliz') {
        $nota = 5;
    } elseif ($emocao === 'triste') {
        $nota = 1;
    }

    // Validação simples
    if ($nota === 0 || empty(trim($texto))) {
        header('Location: feedback.php?erro=vazio');
        exit;
    }

    if ($conexao->connect_error) {
        die("Falha na conexão: " . $conexao->connect_error);
    }

    // 3. Insere na nova tabela FEEDBACKS_SITE
    $sql = "INSERT INTO FEEDBACKS_SITE (TEXTO, AVALIACAO, USUARIO_ID) VALUES (?, ?, ?)";
    
    $stmt = $conexao->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("sii", $texto, $nota, $user_id);
        
        if ($stmt->execute()) {
            header('Location: index.php?feedback=sucesso');
        } else {
            echo "Erro ao salvar: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Erro na preparação da query: " . $conexao->error;
    }
    
    $conexao->close();
    exit;
} else {
    header('Location: index.php');
    exit;
}
?>