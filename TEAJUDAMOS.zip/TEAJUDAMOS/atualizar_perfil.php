<?php
session_start();
include 'conexao.php';

// Prepara uma resposta JSON
header('Content-Type: application/json');

// 1. Verifica se o usuário está logado
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Usuário não autenticado. Faça o login novamente.']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// 2. Verifica a conexão com o banco
if ($conexao->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Falha na conexão com o banco de dados.']);
    exit;
}

// 3. Monta a query dinamicamente
$sql_parts = [];     // Partes da query SQL (ex: "NOME = ?")
$types = "";         // String de tipos (ex: "ssb")
$params = [];        // Array de valores para o bind
$blob_data = [];     // Array separado para guardar os blobs
$blob_indices = [];  // Array para guardar os índices dos placeholders

// 4. Verifica o Nome (sempre enviado pelo JS)
if (isset($_POST['nome'])) {
    $sql_parts[] = "NOME = ?";
    $types .= "s";
    $params[] = $_POST['nome']; // Adiciona o valor real
}

// 5. Verifica a Instituição (sempre enviada pelo JS)
if (isset($_POST['instituicao'])) {
    $sql_parts[] = "INSTITUICAO_ENSINO = ?";
    $types .= "s";
    $params[] = $_POST['instituicao']; // Adiciona o valor real
}

// 6. Verifica a Foto de Perfil
$remover_foto = isset($_POST['remove_foto']) && $_POST['remove_foto'] == '1';
$file_error = $_FILES['foto_perfil']['error'] ?? UPLOAD_ERR_NO_FILE; 

if ($remover_foto) {
    // (MODIFICADO) Se a flag de remoção estiver ativa, define FOTO_PERFIL como NULL
    $sql_parts[] = "FOTO_PERFIL = NULL"; 
    // Não adiciona tipo nem parâmetro, pois o valor é NULL direto na query
    
} elseif ($file_error === UPLOAD_ERR_OK) {
    // Sucesso, arquivo novo recebido
    $foto_blob = file_get_contents($_FILES['foto_perfil']['tmp_name']);
    $sql_parts[] = "FOTO_PERFIL = ?";
    $types .= "b";
    $params[] = null; // Adiciona NULL como placeholder
    $blob_data[] = $foto_blob; // Guarda o blob real
    $blob_indices[] = strlen($types) - 1; // Guarda o índice do placeholder 'b'
    
} elseif ($file_error === UPLOAD_ERR_INI_SIZE || $file_error === UPLOAD_ERR_FORM_SIZE) {
    echo json_encode(['status' => 'error', 'message' => 'Erro: O arquivo de foto é muito grande.']);
    exit;
} elseif ($file_error !== UPLOAD_ERR_NO_FILE) {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao enviar o arquivo: ' . $file_error]);
    exit;
}
// Se nem 'remover_foto' nem 'foto_perfil' nova foram enviados, a foto não é alterada.


// 7. Finaliza a query
$sql = "UPDATE USUARIOS SET " . implode(", ", $sql_parts) . " WHERE ID = ?";
$types .= "i"; // 'i' para o ID
$params[] = $user_id;

$stmt = $conexao->prepare($sql);
if ($stmt === false) {
     echo json_encode(['status' => 'error', 'message' => 'Erro ao preparar a query: ' . $conexao->error]);
     exit;
}

// 8. Faz o bind dos parâmetros
$bind_params = [$types];
foreach ($params as $key => &$value) { // O '&' é crucial
    $bind_params[] = &$value;
}
call_user_func_array([$stmt, 'bind_param'], $bind_params);

// 9. Envia os dados BLOB separadamente
$blob_count = 0;
foreach ($blob_indices as $index) {
    $stmt->send_long_data($index, $blob_data[$blob_count]);
    $blob_count++;
}

// 10. Executa e retorna
if ($stmt->execute()) {
    // Atualiza o nome na sessão, se foi alterado
    if (isset($_POST['nome'])) {
        $_SESSION['user_nome'] = $_POST['nome'];
    }
    echo json_encode(['status' => 'success', 'message' => 'Perfil atualizado com sucesso!']);
} else {
    if ($stmt->errno == 1153 || $stmt->errno == 2006) {
        echo json_encode(['status' => 'error', 'message' => 'Erro: A foto é muito grande para o banco de dados (max_allowed_packet).']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar no banco: ' . $stmt->error]);
    }
}

$stmt->close();
$conexao->close();
?>