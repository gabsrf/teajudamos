<?php
session_start();


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('America/Sao_Paulo');





if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    // A sessão não existe ou o papel não é 'admin'
    
    // Opcional: Destrói qualquer sessão existente e redireciona para o login
    session_unset();
    session_destroy();

    // Redireciona o usuário de volta para a tela de login principal
    header("Location: login.php");
    exit;
}


//conexão banco de dados

define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');

$pdo = null;

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,      
        PDO::ATTR_EMULATE_PREPARES   => false,                 
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    try {
        $pdo->exec("SET time_zone = 'America/Sao_Paulo'");
    } catch (\Throwable $e) {
        $pdo->exec("SET time_zone = '-03:00'");
    }

} catch (PDOException $e) {
    error_log("Erro de Conexão PDO (CRÍTICO): " . $e->getMessage());
    die("Desculpe, não foi possível conectar ao banco de dados. Credenciais ou servidor incorretos.");
}

//fim da conexão 

// Variável para armazenar mensagens de feedback (sucesso/erro)
$feedback_message = "";

// -------------------------------------------------------------------------------------
// 1. Processamento da Ação (Aprovar ou Rejeitar)
// -------------------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);

    if ($request_id && $request_id > 0 && ($action === 'approve' || $action === 'reject')) {
        try {
            // Inicia a transação para garantir que as operações sejam concluídas ou desfeitas
            $pdo->beginTransaction();

            if ($action === 'approve') {
                $stmt_fetch = $pdo->prepare("SELECT nome_primeiro, nome_sobrenome, cpf, email, rg, ra, senha_hash FROM CADASTROS_PENDENTES WHERE id = :id");
                $stmt_fetch->execute(['id' => $request_id]);
                $pending_user = $stmt_fetch->fetch();

                if ($pending_user) {
                    // PASSO B: Inserir na tabela USUARIOS
                    $full_name = $pending_user['nome_primeiro'] . ' ' . $pending_user['nome_sobrenome'];
                    
                    $stmt_insert = $pdo->prepare("INSERT INTO USUARIOS (CPF, EMAIL, RG, RA, SENHA, NOME) 
                                                     VALUES (:cpf, :email, :rg, :ra, :senha, :nome)");
                    
                    $success = $stmt_insert->execute([
                        'cpf'   => $pending_user['cpf'],
                        'email' => $pending_user['email'],
                        'rg'    => $pending_user['rg'],
                        'ra'    => $pending_user['ra'],
                        'senha' => $pending_user['senha_hash'], 
                        'nome'  => $full_name,
                    ]);

                    if ($success) {
                        // PASSO C: Remover da tabela CADASTROS_PENDENTES após aprovação
                        $stmt_delete = $pdo->prepare("DELETE FROM CADASTROS_PENDENTES WHERE id = :id");
                        $stmt_delete->execute(['id' => $request_id]);
                        $feedback_message = "Cadastro de " . $full_name . " APROVADO com sucesso!";
                    } else {
                        $feedback_message = "Erro ao inserir o usuário em USUARIOS. Verifique o log.";
                    }
                } else {
                    $feedback_message = "Erro: Solicitação pendente não encontrada (ID: " . $request_id . ").";
                }

            } elseif ($action === 'reject') {
                // NOVO PASSO A (CORRIGIDO): Buscar dados para obter o nome antes de deletar
                $stmt_fetch = $pdo->prepare("SELECT nome_primeiro, nome_sobrenome FROM CADASTROS_PENDENTES WHERE id = :id");
                $stmt_fetch->execute(['id' => $request_id]);
                $pending_user = $stmt_fetch->fetch();
                
                if ($pending_user) {
                    $full_name = $pending_user['nome_primeiro'] . ' ' . $pending_user['nome_sobrenome'];
                    
                    // PASSO B: Remover da tabela CADASTROS_PENDENTES
                    $stmt_delete = $pdo->prepare("DELETE FROM CADASTROS_PENDENTES WHERE id = :id");
                    $stmt_delete->execute(['id' => $request_id]);
                    
                    // Atualiza a mensagem de feedback com o nome do usuário
                    $feedback_message = "Cadastro de " . $full_name . " REJEITADO e removido com sucesso.";
                } else {
                    $feedback_message = "Erro: Solicitação pendente não encontrada (ID: " . $request_id . ").";
                }
            }

            $pdo->commit();
            
            // Redireciona para evitar reenvio do formulário (Padrão PRG)
            header("Location: aprovacao_cadastro.php?msg=" . urlencode($feedback_message));
            exit();

        } catch (PDOException $e) {
            $pdo->rollBack();
            // Em ambiente de desenvolvimento, exibimos o erro. Em produção, você deve logar.
            $feedback_message = "Erro no banco de dados: " . $e->getMessage() . ". A transação foi desfeita.";
            header("Location: aprovacao_cadastro.php?msg=" . urlencode($feedback_message));
            exit();
        }
    }
}

// -------------------------------------------------------------------------------------
// 2. Busca de Dados de Solicitações Pendentes (Para Exibição)
// -------------------------------------------------------------------------------------
// Verifica se há mensagem de feedback após redirecionamento
if (isset($_GET['msg'])) {
    $feedback_message = htmlspecialchars($_GET['msg']);
}

$pending_requests = [];
$total_requests = 0;
try {
    // Busca todas as solicitações pendentes
    $stmt = $pdo->query("SELECT id, nome_primeiro, nome_sobrenome, cpf, rg, ra, email, senha_hash FROM CADASTROS_PENDENTES ORDER BY data_solicitacao ASC");
    $pending_requests = $stmt->fetchAll();
    $total_requests = count($pending_requests);
} catch (PDOException $e) {
    // Caso a tabela CADASTROS_PENDENTES não exista, ou outro erro de DB
    error_log("Erro ao buscar cadastros pendentes: " . $e->getMessage());
    $feedback_message = "Erro ao carregar solicitações. Execute o script cadastros_pendentes.sql primeiro.";
}

// Se não houver solicitações, insere um item "Vazio" para exibição.
if ($total_requests === 0) {
    $pending_requests[] = [
        'id' => 0, // ID 0 indica que é um card de placeholder
        'nome_primeiro' => '',
        'nome_sobrenome' => 'Nenhuma Solicitação Pendente',
        'cpf' => '-',
        'rg' => '-',
        'ra' => '-',
        'email' => 'Não há novos cadastros para aprovação no momento.',
        'senha_hash' => 'Sem senha',
    ];
    $total_requests = 1; // Para o carrossel ter 1 item (o item de "vazio")
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    
    <title>Painel de Aprovação de Cadastros</title>
    <style>
/* CSS do Usuário (Mantido para preservar o design original) */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            height: 100%;
            overflow: hidden;
        }
        
        body {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            /* Gradiente Original */
            background: linear-gradient(#46004A, #8B0091); 
        }
        
        #app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .main-container {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            padding: 32px;
        }
        
        /* Estilos do Cabeçalho */
        header {
            margin-bottom: 24px;
            flex-shrink: 0;
        }
        
        #main-title {
            font-size: 32px;
            font-weight: bold;
            color: white; /* Mantido branco para destaque no fundo escuro */
            margin-bottom: 8px;
        }
        
        .subtitle {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.9); /* Mantido claro para contraste */
        }

        /* Estilos da mensagem de feedback */
        .feedback-box {
            background-color: #fcf8e3;
            color: #8a6d3b;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
            border: 1px solid #faebcc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        /* Estilos do Carrossel/Card */
        .carousel-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            position: relative;
            min-height: 0;
            margin-bottom: 24px;
        }
        
        .carousel-wrapper {
            flex: 1;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            min-height: 0;
        }
        
        .carousel-track {
            display: flex;
            transition: transform 0.5s ease-in-out;
            height: 100%;
            width: 100%;
            transform: translateX(0%);
        }
        
        .request-card {
            min-width: 100%;
            width: 100%;
            height: 100%;
            /* NOVO: Fundo do cartão harmonizado com um violeta muito suave */
            background: #FBF9FC; 
            border-radius: 12px;
            padding: 32px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            overflow-y: auto; 
            
            /* NOVO: Cor da fonte harmonizada com o roxo escuro */
            color: #46004A; 
        }

        .empty-card {
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-size: 24px;
            color: #46004A;
            opacity: 0.7;
            font-weight: 600;
        }
        
        /* Estilos do Grid de Campos */
        .fields-grid {
            /* 2 colunas para campos pequenos, como antes */
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            width: 100%;
        }

        /* Removendo o estilo full-width que não será mais necessário */
        
        .field {
            display: flex;
            flex-direction: column;
        }
        
        .field-label {
            font-size: 13px;
            opacity: 0.8; /* Aumentada a opacidade */
            font-weight: 600;
            margin-bottom: 8px;
            /* NOVO: Cor da fonte em roxo escuro */
            color: #46004A;
        }
        
        .field-value {
            font-size: 16px;
            padding: 12px;
            /* NOVO: Fundo do campo em lavanda claro */
            background: #EBE4EB; 
            border-radius: 6px;
            word-break: break-word;
            /* NOVO: Cor da fonte em roxo escuro */
            color: #46004A;
        }
        
        .password-value {
            filter: blur(4px);
            user-select: none;
            letter-spacing: 2px;
        }
        
        /* Estilos dos Botões de Ação (Mantido para semântica) */
        .actions-fixed {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .btn {
            color: white;
            padding: 14px 28px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none; /* Adicionado para âncoras */
            line-height: 1; /* Alinha o texto corretamente */
        }
        
        .btn:hover:not(:disabled) {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }
        
        .btn:active:not(:disabled) {
            transform: translateY(0);
        }
        
        .btn:disabled {
            cursor: not-allowed;
            opacity: 0.6;
            transform: none;
        }
        
        /* Mantendo cores de aprovação/rejeição para clareza visual */
        .btn-approve {
            background: #10b981; 
        }
        
        .btn-reject {
            background: #ef4444;
        }
        
        /* NOVO ESTILO: Botão de Voltar (cinza neutro) */
        .btn-back {
            background: #6b7280; /* Cor neutra, Cinza Escuro */
        }
        
        .btn-back:hover {
            background: #4b5563;
        }
        
        /* Estilos dos Controles do Carrossel */
        .carousel-controls {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin-top: 24px;
            flex-shrink: 0;
        }
        
        .carousel-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            width: 48px;
            height: 48px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: all 0.2s;
            backdrop-filter: blur(10px);
        }
        
        .carousel-btn:hover:not(:disabled) {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            transform: scale(1.1);
        }
        
        .carousel-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: none;
        }
        
        .carousel-indicators {
            display: flex;
            gap: 8px;
        }
        
        .indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s;
        }
        
        .indicator.active {
            background: white;
            width: 24px;
            border-radius: 5px;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .main-container {
                padding: 16px;
            }
            
            .request-card {
                padding: 20px;
            }
            
            .fields-grid {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .actions-fixed {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
        
        @media (min-width: 769px) and (max-width: 1024px) {
            .fields-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
            }
        }
    </style>
</head>
<body>
    <div id="app">
        <div class="main-container">

            <?php if (!empty($feedback_message)): ?>
            <div class="feedback-box">
                <?php echo $feedback_message; ?>
            </div>
            <?php endif; ?>

            <header>
                <h1 id="main-title">Aprovação de Cadastro</h1>
                <p class="subtitle" id="subtitle-count">
                    <?php 
                        $count = count($pending_requests);
                        if ($pending_requests[0]['id'] === 0) {
                            echo "Nenhuma solicitação pendente";
                        } else {
                            echo $count > 1 ? "$count solicitações pendentes" : "$count solicitação pendente";
                        }
                    ?>
                </p>
            </header>
            
            <div class="carousel-container">
                <div class="carousel-wrapper">
                    <div class="carousel-track" id="carousel-track">
                        
                        <?php 
                        // Loop para gerar os cards dinamicamente
                        foreach ($pending_requests as $request): ?>
                        <div class="request-card <?php echo $request['id'] === 0 ? 'empty-card' : ''; ?>" data-request-id="<?php echo htmlspecialchars($request['id']); ?>">
                            
                            <?php if ($request['id'] === 0): ?>
                                <p><?php echo htmlspecialchars($request['email']); ?></p>
                            <?php else: ?>
                                <div class="fields-grid">
                                    <div class="field">
                                        <label class="field-label">Nome</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['nome_primeiro']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">Sobrenome</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['nome_sobrenome']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">CPF</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['cpf']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">RG</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['rg']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">RA</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['ra']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">E-mail</label>
                                        <p class="field-value"><?php echo htmlspecialchars($request['email']); ?></p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">Status</label>
                                        <p class="field-value">Pendente</p>
                                    </div>
                                    <div class="field">
                                        <label class="field-label">Senha (Hash)</label>
                                        <div class="field-value password-value">
                                            <?php echo str_repeat('•', 12); ?> 
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                        
                    </div>
                </div>
                
                <div class="carousel-controls">
                    <button class="carousel-btn" id="prev-btn" disabled>
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    
                    <div class="carousel-indicators" id="carousel-indicators">
                        </div>
                    
                    <button class="carousel-btn" id="next-btn" disabled>
                        <i class="fa-solid fa-chevron-right"></i>
                    </button>
                </div>
            </div>
            
            <div class="actions-fixed">
                <a href="administrador.php" class="btn btn-back">
                    <i class="fa-solid fa-arrow-left"></i> Voltar
                </a>
                
                <form method="POST" id="reject-form" style="display: inline;">
                    <input type="hidden" name="request_id" id="reject-request-id" value="<?php echo $pending_requests[0]['id']; ?>">
                    <input type="hidden" name="action" value="reject">
                    <button class="btn btn-reject" id="reject-btn-main" <?php echo $pending_requests[0]['id'] === 0 ? 'disabled' : ''; ?>>
                        <i class="fa-solid fa-times"></i> Rejeitar
                    </button>
                </form>
                
                <form method="POST" id="approve-form" style="display: inline;">
                    <input type="hidden" name="request_id" id="approve-request-id" value="<?php echo $pending_requests[0]['id']; ?>">
                    <input type="hidden" name="action" value="approve">
                    <button class="btn btn-approve" id="approve-btn-main" <?php echo $pending_requests[0]['id'] === 0 ? 'disabled' : ''; ?>>
                        <i class="fa-solid fa-check"></i> Aprovar
                    </button>
                </form>

            </div>
        </div>
    </div>
    
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Referências aos elementos do DOM
            const track = document.getElementById('carousel-track');
            const prevBtn = document.getElementById('prev-btn');
            const nextBtn = document.getElementById('next-btn');
            const indicatorsContainer = document.getElementById('carousel-indicators');
            const approveIdInput = document.getElementById('approve-request-id');
            const rejectIdInput = document.getElementById('reject-request-id');
            const approveBtn = document.getElementById('approve-btn-main');
            const rejectBtn = document.getElementById('reject-btn-main');
            
            // Itens do carrossel (os cartões)
            const items = document.querySelectorAll('.request-card');
            const totalItems = items.length;
            let currentIndex = 0;

            // 1. Geração Dinâmica de Indicadores
            function setupIndicators() {
                indicatorsContainer.innerHTML = ''; // Limpa indicadores existentes
                // Gera indicadores apenas se houver mais de um item REAL OU se houver apenas o item de placeholder (ID != 0)
                if (totalItems > 1 || (totalItems === 1 && items[0].dataset.requestId != 0)) {
                    for (let i = 0; i < totalItems; i++) {
                        const indicator = document.createElement('div');
                        indicator.classList.add('indicator');
                        if (i === currentIndex) {
                            indicator.classList.add('active');
                        }
                        indicatorsContainer.appendChild(indicator);
                    }
                }
            }
            
            // 2. Função para atualizar o estado dos formulários de ação
            function updateActionButtons() {
                if (totalItems > 0) {
                    const currentItem = items[currentIndex];
                    const currentRequestId = currentItem.dataset.requestId;
                    
                    const isZeroId = currentRequestId === '0';

                    // Atualiza o ID do pedido nos formulários ocultos
                    approveIdInput.value = currentRequestId;
                    rejectIdInput.value = currentRequestId;
                    
                    // Desabilita botões se for o card de placeholder
                    approveBtn.disabled = isZeroId;
                    rejectBtn.disabled = isZeroId;
                } else {
                    // Caso não haja itens (deveria ser coberto pelo item placeholder)
                    approveBtn.disabled = true;
                    rejectBtn.disabled = true;
                }
            }

            // 3. Função para atualizar a visualização do carrossel (movimento, botões e indicadores)
            function updateCarousel() {
                if (totalItems === 0) return; // Não faz nada se não houver itens

                // 3.1. Movimenta o track
                const offset = -currentIndex * 100;
                track.style.transform = `translateX(${offset}%)`;

                // 3.2. Atualiza o estado dos botões (habilita/desabilita)
                prevBtn.disabled = currentIndex === 0;
                nextBtn.disabled = currentIndex === totalItems - 1;

                // 3.3. Atualiza os indicadores
                const indicators = indicatorsContainer.querySelectorAll('.indicator');
                indicators.forEach((indicator, index) => {
                    if (index === currentIndex) {
                        indicator.classList.add('active');
                    } else {
                        indicator.classList.remove('active');
                    }
                });

                // 3.4. Atualiza os botões de Aprovar/Rejeitar
                updateActionButtons();
            }

            // --- LISTENERS DE EVENTOS ---
            
            // Botão Anterior
            prevBtn.addEventListener('click', () => {
                if (currentIndex > 0) {
                    currentIndex--;
                    updateCarousel();
                }
            });

            // Botão Próximo
            nextBtn.addEventListener('click', () => {
                if (currentIndex < totalItems - 1) {
                    currentIndex++;
                    updateCarousel();
                }
            });
            
            // Inicializa a configuração do carrossel e botões
            setupIndicators();
            updateCarousel();
        });
    </script>
</body>
</html>