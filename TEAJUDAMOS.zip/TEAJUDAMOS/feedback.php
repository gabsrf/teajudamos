<?php
session_start();
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php?erro=naologado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Feedback</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">


    <style>
        /* --- GERAL (DESKTOP) --- */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(#46004A, #8B0091);
            height: 100vh;
            position: relative;
        }

        header {
            position: absolute;
            top: -95px;
            left: 20px;
        }

        .logo img {
            width: 300px;
            height: auto;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        .container {
            min-width: 620px;
            min-height: 495px;
            background-color: #F0F0F0;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .container p {
            margin-top: 35px;
            color: #BBBBBB;
            font-size: 35px;
            font-weight: bold;
            display: flex;
            margin-left: 50px;
        }

        .container textarea {
            margin-left: 50px;
            margin-top: -20px;
            border-radius: 5px;
            background-color: #BBBBBB;
            min-width: 500px;
            max-width: 530px;
            min-height: 270px;
            font-size: 20px;
            padding: 10px;
            color: #4e4e4eff;
            font-weight: bold;
            resize: none;
            border: none;
            outline: none;
        }

        .icones-feedback {
            display: flex;
            align-items: center;
            margin: 15px 45px 0 60px;
        }

        .icones-feedback i.fa-face-smile,
        .icones-feedback i.fa-face-frown {
            font-size: 40px;
            color: #4e4e4eff;
            margin-right: 15px;
            transition: color 0.3s;
            cursor: pointer;
        }

        .icones-feedback i.fa-face-smile:hover {
            color: #2dda0bff;
        }

        .icones-feedback i.fa-face-frown:hover {
            color: red;
        }

        .icones-feedback button {
            background: none;
            border: none;
            cursor: pointer;
            margin-left: auto;
            padding: 8px;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .icones-feedback button i {
            font-size: 40px;
            color: #3a3a3a;
            transition: color 0.3s, padding 0.25s ease;
        }

        .icones-feedback button:hover {
            background-color: #3a3a3a;
        }

        .icones-feedback button:hover i {
            color: white;
            padding: 8px;
            border-radius: 5px;
        }

        .selecionado-feliz {
            color: #2dda0bff !important;
        }

        .selecionado-triste {
            color: red !important;
        }

        /* Toast Notification (Aviso Vermelho) */
        .custom-toast {
            visibility: hidden;
            min-width: 300px;
            background-color: #dc2626;
            color: #fff;
            text-align: center;
            border-radius: 50px;
            padding: 12px 24px;
            position: fixed;
            z-index: 2000;
            left: 50%;
            top: 30px;
            transform: translateX(-50%);
            font-size: 16px;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(220, 38, 38, 0.4);
            opacity: 0;
            transition: opacity 0.4s ease, top 0.4s ease;
        }

        .custom-toast.show {
            visibility: visible;
            opacity: 1;
            top: 50px;
        }

        .custom-toast i {
            margin-right: 8px;
        }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 480px) {
            body {
                width: 100%;
                height: auto;
                min-height: 100vh;
            }

            header {
                position: absolute;
                left: 50%;
                transform: translateX(-50%);
                top: -95px;
                width: 100%;
                display: flex;
                justify-content: center;
            }

            .logo img {
                width: 350px;
            }

            .container {
                min-width: 90%;
                width: 90%;
                /* Ajuste para centralizar corretamente no mobile */
                left: 50%;
                top: 55%;
                transform: translate(-50%, -50%);
                padding: 14px;
                min-height: auto;
                box-sizing: border-box;
            }

            .container p {
                font-size: 32px;
                margin-top: 10px;
                margin-left: 5px;
                justify-content: center;
            }

            .container textarea {
                font-size: 20px;
                margin-left: 0;
                margin-top: 10px;
                min-width: 100%;
                width: 100%;
                min-height: 270px;
                padding: 10px;
                box-sizing: border-box;
            }

            .icones-feedback {
                margin: 15px 10px 0 10px;
                justify-content: space-between;
            }

            .icones-feedback button i {
                font-size: 50px;
            }

            .icones-feedback i.fa-face-smile,
            .icones-feedback i.fa-face-frown {
                font-size: 50px;
            }
        }
    </style>
</head>

<body>

    <div id="toast-feedback" class="custom-toast">
        <i class="fa-solid fa-circle-exclamation"></i> Selecione uma avaliação antes de enviar!
    </div>

    <header>
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </header>

    <div class="container">
        <form id="feedbackForm" method="POST" action="salvar_feedback.php">
            <p> FEEDBACK </p>

            <textarea name="feedback" placeholder="Digite seu Feedback" required></textarea>

            <input type="hidden" name="emocao" id="campo-emocao">

            <div class="icones-feedback">
                <i id="icone-feliz" class="fa-solid fa-face-smile"></i>
                <i id="icone-triste" class="fa-solid fa-face-frown"></i>
                <button type="submit">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
        </form>
    </div>

    <script>
        const feliz = document.getElementById("icone-feliz");
        const triste = document.getElementById("icone-triste");
        const campoEmocao = document.getElementById("campo-emocao");
        const form = document.getElementById("feedbackForm");
        const toast = document.getElementById("toast-feedback");

        let selecionado = null;

        // Lógica de Seleção
        feliz.addEventListener("click", () => {
            if (selecionado === "feliz") {
                feliz.classList.remove("selecionado-feliz");
                campoEmocao.value = "";
                selecionado = null;
            } else {
                feliz.classList.add("selecionado-feliz");
                triste.classList.remove("selecionado-triste");
                campoEmocao.value = "feliz";
                selecionado = "feliz";
            }
        });

        triste.addEventListener("click", () => {
            if (selecionado === "triste") {
                triste.classList.remove("selecionado-triste");
                campoEmocao.value = "";
                selecionado = null;
            } else {
                triste.classList.add("selecionado-triste");
                feliz.classList.remove("selecionado-feliz");
                campoEmocao.value = "triste";
                selecionado = "triste";
            }
        });

        // Validação antes de enviar
        form.addEventListener("submit", function(event) {
            if (campoEmocao.value === "") {
                event.preventDefault(); // Impede o envio
                showToast(); // Mostra o aviso
            }
        });

        function showToast() {
            toast.classList.add("show");
            setTimeout(() => {
                toast.classList.remove("show");
            }, 3000);
        }
    </script>

</body>

</html>