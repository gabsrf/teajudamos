<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

date_default_timezone_set('America/Sao_Paulo');

define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');

mysqli_report(MYSQLI_REPORT_OFF);

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Desculpe, a conexão com o banco de dados falhou: " . $conn->connect_error);
}

try {
    @$conn->query("SET time_zone = 'America/Sao_Paulo'");
    if ($conn->error) {
        throw new Exception();
    }
} catch (Exception $e) {
    $conn->query("SET time_zone = '-03:00'");
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$sql = "
    SELECT
        L.ID,
        L.TITULO,
        L.MATERIA,
        L.DATA_PUBLICACAO,
        U.NOME AS NOME_AUTOR,
        L.CAPA,
        COALESCE(SUM(CASE WHEN F.AVALIACAO = 1 THEN 1 ELSE 0 END), 0) AS likes,
        COALESCE(SUM(CASE WHEN F.AVALIACAO = 0 THEN 1 ELSE 0 END), 0) AS dislikes
    FROM
        LICAO L
    INNER JOIN
        USUARIOS U ON L.PROFESSOR_ID = U.ID
    LEFT JOIN
        FEEDBACK F ON L.ID = F.LICAO_ID
    GROUP BY
        L.ID, L.TITULO, L.MATERIA, L.DATA_PUBLICACAO, U.NOME, L.CAPA
    ORDER BY
        L.DATA_PUBLICACAO DESC;
";

$result = $conn->query($sql);
$lessons = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $lessons[] = $row;
    }
}

$totalLessonsCount = count($lessons);

$conn->close();

function formatTimeAgo($datetimeString) {
    $now = new DateTime();
    $date = new DateTime($datetimeString);
    $diff = $now->diff($date);

    if ($diff->y > 0) return "há " . $diff->y . " ano(s)";
    if ($diff->m > 0) return "há " . $diff->m . " mês(es)";
    if ($diff->d > 0) {
        if ($diff->d == 1) return "há 1 dia";
        if ($diff->d < 7) return "há " . $diff->d . " dia(s)";
        return "em " . $date->format('d/m/Y');
    }
    if ($diff->h > 0) return "há " . $diff->h . " hora(s)";
    if ($diff->i > 0) return "há " . $diff->i . " minuto(s)";
    if ($diff->s > 0) return "agora mesmo";

    return "em " . $date->format('d/m/Y');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Gerenciamento de Lições</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');

        :root {
            /* Paleta de Cores Baseada no Gradiente Fornecido */
            --dark-purple: #46004A; /* Cor escura do gradiente */
            --light-purple: #8B0091; /* Cor clara do gradiente */
            --background-color: #f8fafc; /* Fundo principal claro */
            --text-color: #1f2937; /* Cor de texto padrão */
            --card-border: #e5e7eb; /* Borda de card sutil */
            --subtle-shadow: 0 4px 12px rgba(0, 0, 0, 0.07);
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background-color);
            margin: 0;
            padding: 0;
            min-height: 150vh;
            position: relative;
        }

        /* Cor de fundo do cabeçalho com o gradiente solicitado */
        .header-bg {
            background: linear-gradient(#46004A, #8B0091);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Sombra mais destacada */
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }

        .header-content {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0.75rem 0;
            position: relative;
        }

        .header-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: white;
            letter-spacing: 0.05em;
        }

        /* Ícone de Voltar */
        .home-icon {
            position: absolute;
            left: 1.5rem;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0.5rem;
            margin-left: -0.5rem;
            transition: color 0.2s, transform 0.2s;
            text-decoration: none;
        }

        .home-icon:hover {
            color: #E0B0FF; /* Um roxo mais claro no hover */
            transform: scale(1.05);
        }

        .main-content {
            padding-top: 2rem;
            padding-bottom: 5rem;
        }

        .page-title-section {
            margin-bottom: 2rem;
            padding-bottom: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Cor do Título Principal da Página */
        .page-title {
            font-size: 2rem;
            font-weight: 800;
            color: var(--dark-purple);
        }

        /* Card de Estatística */
        .stat-card {
            background-color: white;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1); /* Sombra mais notável */
            border-left: 5px solid var(--light-purple); /* Borda lateral mais espessa */
            margin-bottom: 2rem;
            transition: transform 0.3s ease-in-out;
        }

        .stat-card:hover {
             transform: translateY(-2px);
        }

        .stat-value {
            font-size: 2.2rem; /* Levemente maior */
            font-weight: 900;
            color: var(--dark-purple);
            margin-top: 0.25rem;
        }

        .lessons-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); /* Cards levemente maiores */
            gap: 1.5rem;
        }

        /* Card de Lição */
        .lesson-card {
            background-color: white;
            border-radius: 0.75rem;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(139, 0, 145, 0.1); /* Borda sutil com cor da paleta */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08); /* Sombra inicial mais suave */
            transition: all 0.35s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        /* Efeito Visual Aprimorado no Hover */
        .lesson-card:hover {
            transform: translateY(-5px); /* Efeito de elevação mais pronunciado */
            box-shadow: 0 15px 30px -8px rgba(70, 0, 74, 0.35); /* Sombra roxa forte para "viver" */
            border-color: var(--light-purple); /* Borda clara no hover */
        }

        .image-placeholder {
            height: 140px; /* Levemente maior */
            background-color: #f3f0f3;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark-purple);
            font-size: 0.9rem;
            font-weight: 600;
            border-bottom: 1px solid var(--card-border);
        }

        .image-placeholder i.fa-book-open {
            font-size: 2.5rem;
            color: var(--dark-purple);
            opacity: 0.8;
        }

        .image-placeholder img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 0.75rem 0.75rem 0 0;
        }

        .status-tag {
            padding: 0.3rem 0.8rem;
            font-size: 0.75rem;
            font-weight: 700;
            border-radius: 9999px;
            margin-bottom: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        /* Cores de status de exemplo ajustadas para harmonizar */
        .status-publicado {
            background-color: #d8f5e7; /* Verde/Menta suave */
            color: #0d795d;
            border: 1px solid #48c78e;
        }

        .status-rascunho {
            background-color: #fff9e1; /* Amarelo/Creme suave */
            color: #a37200;
            border: 1px solid #ffce42;
        }

        .status-revisao {
            background-color: #ffe0ee; /* Rosa/Lavanda suave */
            color: #a50e50;
            border: 1px solid #f472b6;
        }

        .card-content {
            padding: 1rem 1.25rem;
            flex-grow: 1;
        }

        .card-title {
            font-size: 1.2rem;
            font-weight: 800;
            color: var(--dark-purple);
            margin-bottom: 0.5rem;
            line-height: 1.3;
            transition: color 0.15s;
        }

        .card-title a {
            text-decoration: none;
            color: inherit;
        }

        .card-title a:hover {
            color: var(--light-purple);
        }

        .card-info {
            font-size: 0.85rem;
            color: #4b5563;
            margin-bottom: 0.1rem;
        }

        .card-info span {
            font-weight: 700;
            color: var(--dark-purple);
        }

        .card-stats {
            display: flex;
            justify-content: space-between;
            padding-top: 0.75rem;
            border-top: 1px solid #f3f4f6;
            font-size: 0.8rem;
            color: #6b7280;
            margin-top: 0.75rem;
        }

        .stat-item {
            display: flex;
            align-items: center;
            font-weight: 600;
        }

        .stat-item i {
            font-size: 1rem;
            margin-right: 0.3rem;
            color: inherit;
        }

        .stat-item.time i {
            color: #9ca3af;
        }

        .stat-item.likes {
            color: #10b981;
        }

        .stat-item.dislikes {
            color: #ef4444;
        }

        .card-actions {
            display: flex;
            justify-content: flex-end;
            padding: 0.75rem 1.25rem;
            border-top: 1px solid var(--card-border);
            background-color: #fcfcfc;
        }

        .btn-action {
            font-size: 0.8rem;
            font-weight: 700; /* Mais negrito */
            transition: color 0.2s ease-in-out;
            display: flex;
            align-items: center;
            cursor: pointer;
            text-transform: uppercase;
            background: none;
            border: none;
            padding: 0;
            text-decoration: none;
            letter-spacing: 0.03em;
        }

        .btn-action i {
            font-size: 1.1rem; /* Ícones levemente maiores */
            margin-right: 0.3rem;
        }

        .btn-action.view {
            color: var(--light-purple);
            margin-right: 1.2rem; /* Mais espaçamento */
        }

        .btn-action.view:hover {
            color: var(--dark-purple);
        }

        .btn-action.delete {
            color: #c02020;
        }

        .btn-action.delete:hover {
            color: #9a1a1a;
        }

        /* Botão Voltar ao Topo */
        #backToTopBtn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: var(--light-purple); /* Roxo claro */
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            font-size: 1.2rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s, visibility 0.3s, background-color 0.2s, transform 0.2s;
            z-index: 99;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        #backToTopBtn i {
            font-size: 1.2rem;
        }

        #backToTopBtn:hover {
            background-color: var(--dark-purple); /* Roxo escuro no hover */
            transform: scale(1.1); /* Efeito de zoom */
        }

        #backToTopBtn.show {
            opacity: 1;
            visibility: visible;
        }

        @media (max-width: 640px) {
            .container {
                padding: 0 1rem;
            }

            .page-title {
                font-size: 1.8rem;
            }

            .lessons-grid {
                grid-template-columns: 1fr;
            }

            #backToTopBtn {
                width: 45px;
                height: 45px;
                bottom: 15px;
                right: 15px;
            }

            .home-icon {
                left: 1rem;
            }
        }
    </style>
</head>

<body>
    <header class="header-bg">
        <div class="container">
            <div class="header-content">
                <a href="administrador.php" class="home-icon" title="Voltar">
                    <i class="fa-solid fa-arrow-left"></i>
                </a>
                <h1 class="header-title">GERENCIAMENTO DAS LIÇÕES</h1>
            </div>
        </div>
    </header>

    <main class="container main-content">
        <div class="page-title-section">
            <h2 class="page-title">Gerenciamento de Lições</h2>
        </div>

        <div class="stat-card">
            <p style="font-size: 0.85rem; font-weight: 600; color: #4b5563; margin-bottom: 0;">TOTAL DE LIÇÕES CADASTRADAS</p>
            <p class="stat-value" id="totalLessonsCount"><?php echo $totalLessonsCount; ?></p>
        </div>

        <div id="lessonsGrid" class="lessons-grid">
            <?php foreach ($lessons as $lesson): ?>
                <div class="lesson-card">

                    <div class="image-placeholder">
                        <?php if (!empty($lesson['CAPA'])):
                            $base64_image = base64_encode($lesson['CAPA']);
                        ?>
                            <img src="data:image/jpeg;base64,<?php echo $base64_image; ?>" 
                                alt="<?php echo htmlspecialchars($lesson['TITULO']); ?> - Capa" />
                        <?php else: ?>
                            <i class="fa-solid fa-book-open"></i>
                            <span style="margin-left: 8px;">SEM IMAGEM DE CAPA</span>
                        <?php endif; ?>
                    </div>

                    <div class="card-content">
                        <span class="status-tag status-publicado">PUBLICADO</span>

                        <h3 class="card-title">
                            <a href="licao.php?id=<?php echo $lesson['ID']; ?>" 
                               title="<?php echo htmlspecialchars($lesson['TITULO']); ?>" 
                               target="_blank">
                                <?php echo htmlspecialchars($lesson['TITULO']); ?>
                            </a>
                        </h3>

                        <p class="card-info">
                            <span>Matéria:</span> <?php echo htmlspecialchars($lesson['MATERIA']); ?>
                        </p>
                        <p class="card-info" style="margin-bottom: 0.5rem;">
                            <span>Autor:</span> <?php echo htmlspecialchars($lesson['NOME_AUTOR']); ?>
                        </p>

                        <div class="card-stats">
                            <p class="stat-item likes">
                                <i class="fa-solid fa-thumbs-up"></i>
                                <?php echo number_format($lesson['likes'], 0, ',', '.'); ?>
                            </p>
                            <p class="stat-item dislikes">
                                <i class="fa-solid fa-thumbs-down"></i>
                                <?php echo number_format($lesson['dislikes'], 0, ',', '.'); ?>
                            </p>
                            <p class="stat-item time">
                                <i class="fa-solid fa-clock"></i>
                                <?php echo formatTimeAgo($lesson['DATA_PUBLICACAO']); ?>
                            </p>
                        </div>
                    </div>

                    <div class="card-actions">
                        <a class="btn-action view" href="licao.php?id=<?php echo $lesson['ID']; ?>" target="_blank">
                            <i class="fa-solid fa-eye"></i> Ver
                        </a>
                        <button class="btn-action delete" type="button" 
                            onclick="confirmDelete(<?php echo $lesson['ID']; ?>, '<?php echo htmlspecialchars($lesson['TITULO'], ENT_QUOTES, 'UTF-8'); ?>')">
                            <i class="fa-solid fa-trash"></i> Excluir
                        </button>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>

    </main>

    <button id="backToTopBtn">
        <i class="fa-solid fa-arrow-up"></i>
    </button>

    <script>
        const backToTopBtn = document.getElementById("backToTopBtn");

        window.addEventListener("scroll", () => {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add("show");
            } else {
                backToTopBtn.classList.remove("show");
            }
        });

        backToTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });

        // ===========================================
        // FUNÇÕES DE EXCLUSÃO (CORREÇÃO DO MÉTODO INVÁLIDO)
        // ===========================================

        /**
         * Pede confirmação ao usuário e, se confirmada, inicia a exclusão.
         * @param {number} licaoId - O ID da lição a ser excluída.
         * @param {string} tituloLicao - O título da lição para exibição na mensagem.
         */
        function confirmDelete(licaoId, tituloLicao) {
            if (confirm(`Tem certeza que deseja EXCLUIR a lição "${tituloLicao}" (ID: ${licaoId})? Esta ação é irreversível.`)) {
                deleteLicao(licaoId);
            }
        }

        /**
         * Envia a requisição POST assíncrona para o script de exclusão.
         * @param {number} licaoId - O ID da lição.
         */
        function deleteLicao(licaoId) {
            // Cria um FormData para simular o envio de um formulário POST
            const formData = new FormData();
            formData.append('licao_id', licaoId); 

            fetch('deletar_licao.php', {
                method: 'POST', // Essencial para evitar o erro "Método inválido."
                body: formData,
            })
            .then(response => {
                // Checa se a resposta HTTP é bem-sucedida (ex: 200 OK)
                if (!response.ok) {
                    throw new Error(`Erro HTTP! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    alert('✅ Lição excluída com sucesso!');
                    
                    // Lógica para remover o card da lição da tela
                    const cardToRemove = document.querySelector(`.lesson-card button[onclick*="${licaoId}"]`).closest('.lesson-card');
                    if (cardToRemove) {
                        cardToRemove.remove();
                        
                        // Atualiza a contagem total de lições
                        const countElement = document.getElementById('totalLessonsCount');
                        let currentCount = parseInt(countElement.textContent);
                        countElement.textContent = currentCount > 0 ? currentCount - 1 : 0;
                    }

                } else {
                    // Exibe a mensagem de erro retornada pelo PHP (ex: "Você não tem permissão...")
                    alert(`❌ Erro ao excluir a lição: ${data.message}`);
                    console.error('Erro de exclusão no servidor:', data.message);
                }
            })
            .catch(error => {
                alert('❌ Falha na comunicação com o servidor. Tente novamente. ' + error.message);
                console.error('Erro de requisição:', error);
            });
        }
    </script>

</body>
</html>