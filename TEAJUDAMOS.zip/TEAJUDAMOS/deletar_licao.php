<?php
session_start();
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Você precisa estar logado para excluir.']);
    exit;
}
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $licao_id = isset($_POST['licao_id']) ? intval($_POST['licao_id']) : 0;

    if ($licao_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID da lição inválido.']);
        exit;
    }

    if ($conexao->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Erro de conexão com o banco.']);
        exit;
    }

    $stmt = $conexao->prepare("SELECT PROFESSOR_ID FROM LICAO WHERE ID = ?");
    $stmt->bind_param("i", $licao_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $licao = $result->fetch_assoc();
    $stmt->close();

    if (!$licao) {
        echo json_encode(['status' => 'error', 'message' => 'Lição não encontrada.']);
        exit;
    }


    $user_role = $_SESSION['user_role'] ?? 'user'; 


    if ($licao['PROFESSOR_ID'] != $user_id && $user_role !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Você não tem permissão para excluir esta lição.']);
        exit;
    }


    $stmt_feedback = $conexao->prepare("DELETE FROM FEEDBACK WHERE LICAO_ID = ?");
    $stmt_feedback->bind_param("i", $licao_id);
    $stmt_feedback->execute();
    $stmt_feedback->close();
    

    $stmt_del = $conexao->prepare("DELETE FROM LICAO WHERE ID = ?");
    $stmt_del->bind_param("i", $licao_id);

    if ($stmt_del->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao excluir lição: ' . $conexao->error]);
    }
    
    $stmt_del->close();
    $conexao->close();
    exit;
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método inválido.']);
    exit;
}
?>