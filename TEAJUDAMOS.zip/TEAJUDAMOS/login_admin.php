<?php
// Define o cabeçalho para garantir que a sessão funcione antes de qualquer output
session_start();

// =========================================================================
// NOVO: 1. VERIFICAÇÃO DA ETAPA 1 (LOGIN PENDENTE)
// =========================================================================
if (!isset($_SESSION['admin_pending_id']) || !isset($_SESSION['admin_pending_email'])) {

    // Se não passou pela primeira etapa, destrói e redireciona.
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

// VARIÁVEIS DE ESTADO
$mensagem = "";
$erro = false;
$conexao = null; 

// Obtém o e-mail da sessão pendente (será usado no value do input e na validação)
$email_sessao = $_SESSION['admin_pending_email'];


define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');

try {
    // Cria a string DSN (Data Source Name)
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    
    // Configurações PDO
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lança exceções em caso de erro
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Retorna resultados como array associativo
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $conexao = new PDO($dsn, DB_USER, DB_PASS, $options);
    

} catch (\PDOException $e) {
    $erro = true;
    $mensagem = "Erro na conexão com o banco de dados: " . $e->getMessage();
    // Em produção, a mensagem acima deve ser genérica por segurança
}


// =========================================================================
// 2. LÓGICA DE PROCESSAMENTO DO FORMULÁRIO (Verifica senha2)
// =========================================================================

// Verifica se a conexão foi bem-sucedida e se o formulário foi submetido
if (!$erro && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['email']) && !empty($_POST['senha'])) {
        
        $email = trim($_POST['email']);
        $senha_digitada = trim($_POST['senha']);
        
        // Validação de e-mail contra a sessão pendente
        if ($email !== $email_sessao) {
            $erro = true;
            $mensagem = "Erro de sessão ou tentativa de acesso inválida. Tente logar novamente.";
        }

        if (!$erro && $conexao instanceof PDO) { 
            try {

                // MUDANÇA CRUCIAL: Seleciona apenas 'id' e 'email' para evitar erro se 'nome' não existir.
                $sql = "SELECT id, email FROM ADMINISTRADORES WHERE email = :email AND senha2 = :senha_digitada";
                
                $stmt = $conexao->prepare($sql);
                $stmt->bindParam(':email', $email, PDO::PARAM_STR);
                $stmt->bindParam(':senha_digitada', $senha_digitada, PDO::PARAM_STR); 
                $stmt->execute();

                if ($stmt->rowCount() === 1) {
                    $admin = $stmt->fetch(); // Obtém os dados do administrador

                    // Definição da sessão final de administrador:
                    $_SESSION['user_id'] = $admin['id'];
                    // MUDANÇA: Sessão definida apenas com o email, garantindo que não falhe.
                    $_SESSION['user_nome'] = 'Administrador (' . htmlspecialchars($admin['email']) . ')';
                    $_SESSION['user_role'] = 'admin';
                    
                    // Limpa as variáveis de sessão pendentes
                    unset($_SESSION['admin_pending_id']);
                    unset($_SESSION['admin_pending_email']);
                    
                    // Redireciona para a página do administrador
                    header('Location: administrador.php');
                    exit;
                } else {
                    // Credenciais inválidas (senha2 errada)
                    $erro = true;
                    $mensagem = "Credenciais inválidas. Verifique o e-mail e a senha.";
                }
            } catch (PDOException $e) {
                $erro = true;
                // Mantenha esta linha para produção:
                $mensagem = "Ocorreu um erro no servidor ao tentar processar o login.";
                
                // MODO DEBUG: Se a correção acima não funcionar, COMENTE a linha acima 
                // e DESCOMENTE a linha abaixo temporariamente para ver o erro real do SQL:
                // $mensagem = "Erro PDO para debug: " . $e->getMessage();
            }
        } else {
            $erro = true;
            $mensagem = "Erro: Conexão com o banco de dados falhou após a tentativa de login.";
        }
    } else {
        $erro = true;
        $mensagem = "Por favor, preencha todos os campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login de Administrador</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">
    <style>
        /* Variáveis de Cores (Ajustadas para melhor contraste e paleta) */
        :root {
            --dark-purple: #46004A; /* Fundo mais escuro */
            --light-purple: #8B0091; /* Fundo mais claro */
            --card-bg: rgba(20, 0, 20, 0.7); /* Fundo da caixa de login */
            --text-color: #F7E6FF; /* Roxo bem claro para o texto */
            --primary-button: #ffffff;
            --primary-button-text: #46004A;
            --secondary-button-border: #BB88C3; /* Roxo claro para borda secundária */
            --input-focus: #FFFFFF;
        }

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            /* Aplica o gradiente roxo solicitado */
            background: linear-gradient(to bottom, var(--dark-purple), var(--light-purple));
            padding: 24px;
        }

        .login-card {
            width: 100%;
            max-width: 440px; 
            padding: 40px; 
            background-color: var(--card-bg);
            border-radius: 16px; /* Mais arredondado */
            /* Sombra forte e com toque de cor roxa (efeito Tailwind shadow-xl) */
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.6), 0 0 10px rgba(139, 0, 145, 0.5); 
            color: var(--text-color);
            transition: transform 0.3s ease;
        }

        .login-card:hover {
            transform: translateY(-5px); /* Efeito sutil de elevação */
        }

        h1 {
            text-align: center;
            font-size: 2.2em;
            margin-bottom: 10px;
            font-weight: 800; /* Mais negrito */
            color: var(--text-color);
        }

        p.subtitle {
            text-align: center;
            margin-bottom: 35px;
            color: var(--text-color);
            opacity: 0.7;
            font-size: 1.0em;
        }

        .input-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-size: 0.95em;
            color: var(--text-color);
            opacity: 0.9;
            font-weight: 600;
        }

        /* Envolve o input de senha e o botão de toggle */
        .password-wrapper {
            position: relative; 
            width: 100%;
        }

        .input-field {
            width: 100%;
            padding: 14px;
            border: 1px solid var(--secondary-button-border);
            border-radius: 10px;
            background-color: var(--dark-purple); /* Cor de fundo mais escura */
            color: white;
            transition: all 0.3s ease;
            box-sizing: border-box;
            font-size: 1.0em;
            padding-right: 45px; /* Espaço para o ícone do olho */
        }

        .input-field::placeholder {
            color: var(--text-color);
            opacity: 0.4;
        }

        .input-field:focus {
            border-color: var(--input-focus);
            outline: 2px solid var(--input-focus); /* O efeito do anel branco do Tailwind */
            outline-offset: 2px;
            background-color: var(--dark-purple);
            box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.1); /* Sombra suave no foco */
        }
        
        /* Estilo para campo readonly */
        .input-field[readonly] {
            cursor: default;
            background-color: #330033; /* Cor ligeiramente diferente para indicar que é somente leitura */
            opacity: 0.8;
        }


        /* Estilo do botão de toggle da senha */
        .toggle-password {
            position: absolute;
            right: 0;
            top: 50%; 
            transform: translateY(-50%);
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 10px;
            color: var(--text-color);
            opacity: 0.6;
            transition: opacity 0.3s;
        }

        .toggle-password:hover {
            opacity: 1;
        }

        .toggle-password svg {
            width: 20px;
            height: 20px;
            display: block;
        }

        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
            margin-top: 15px;
            font-size: 1.05em;
            letter-spacing: 0.5px;
            display: block; /* Garante que 'a' e 'button' se comportem como blocos */
        }

        /* Botão de Login (Principal) */
        .btn-primary {
            background-color: var(--primary-button);
            color: var(--primary-button-text);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.4);
        }

        .btn-primary:hover {
            background-color: #eee;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }

        /* Botão de Voltar (Secundário) */
        .btn-secondary {
            background-color: transparent;
            color: var(--text-color);
            border: 1px solid var(--secondary-button-border);
            margin-top: 12px;
            width: 94%;
        }

        .btn-secondary:hover {
            background-color: rgba(139, 0, 145, 0.3); /* Roxo mais claro com transparência */
            border-color: var(--text-color);
        }

        /* Estilos da caixa de mensagem */
        .message-box {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 10px;
            text-align: center;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }

        .error {
            background-color: #A00000; /* Vermelho mais vibrante */
            color: white;
        }

        .success {
            background-color: #008000; 
            color: white;
        }

        /* Mídia Query para Responsividade Móvel */
        @media (max-width: 600px) {
            body {
                padding: 15px;
            }
            .login-card {
                padding: 25px;
                border-radius: 10px;
            }
            h1 {
                font-size: 1.8em;
            }
            .input-field, .btn {
                padding: 12px;
                font-size: 1em;
            }
        }
    </style>
</head>
<body>

    <div class="login-card">
        
        <h1>Acesso Administrativo</h1>
        <p class="subtitle">Use suas credenciais de recuperação para acessar.</p>

        <?php if (!empty($mensagem)): ?>
            <div class="message-box <?php echo $erro ? 'error' : 'success'; ?>">
                <?php echo htmlspecialchars($mensagem); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            
            <div class="input-group">
                <label for="email">E-mail</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    required 
                    class="input-field"
                    placeholder="seu.email@dominio.com"
                    value="<?php echo htmlspecialchars($email_sessao); ?>"
                    readonly
                >
            </div>

            <div class="input-group">
                <label for="senha">Digite a Senha</label>
                <div class="password-wrapper">
                    <input 
                        type="password" 
                        id="senha" 
                        name="senha" 
                        required 
                        class="input-field"
                        placeholder="Senha de acesso"
                    >
                    <button type="button" id="togglePassword" class="toggle-password" title="Mostrar Senha">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.43-.01.639C20.573 16.49 16.638 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </button>
                </div>
            </div>

            <button 
                type="submit" 
                class="btn btn-primary"
            >
                Acessar Painel
            </button>

            <a 
                href="index.php" 
                class="btn btn-secondary"
            >
                Voltar para o Início
            </a>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleButton = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('senha');
            
            if (toggleButton && passwordInput) {
                toggleButton.addEventListener('click', function() {
                    // Alterna o atributo 'type' entre 'password' e 'text'
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    
                    // Opcional: Altera o texto de acessibilidade do botão
                    // O SVG se encarrega de mostrar/esconder o olho
                    this.setAttribute('title', type === 'password' ? 'Mostrar Senha' : 'Ocultar Senha');
                });
            }
        });
    </script>

</body>
</html>