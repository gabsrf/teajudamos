<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- 0. CONFIGURAÇÃO E CONEXÃO COM O BANCO DE DADOS ---
// O arquivo conexao.php (cujo conteúdo foi fornecido) faz a conexão mysqli.
// Incluímos o conteúdo de conexao.php diretamente aqui para fins de demonstração completa.
date_default_timezone_set('America/Sao_Paulo'); 

define('DB_HOST', 'localhost'); 
define('DB_USER', 'u896535670_user'); 
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025'); 
define('DB_NAME', 'u896535670_TEAJUDAMOS');        

mysqli_report(MYSQLI_REPORT_OFF); 

$conexao = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME); 
$erro_conexao = '';

if ($conexao->connect_error) {
    $erro_conexao = "Falha na conexão com o banco de dados: " . $conexao->connect_error;
    $conexao = null;
} else {
    try {
        @$conexao->query("SET time_zone = 'America/Sao_Paulo'"); 
        if ($conexao->error) {
            throw new Exception("Timezone name failed, using offset."); 
        }
    } catch (Exception $e) {
        $conexao->query("SET time_zone = '-03:00'"); 
    }
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); 
}

// 1. VERIFICA AUTENTICAÇÃO
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php?erro=naologado');
    exit;
}

$user_id = $_SESSION['user_id'];

// **NOVA LÓGICA: Armazenar a página de origem (Referer) para redirecionamento futuro**
$current_script_name = basename(__FILE__); // Retorna "editar_feedback.php"

// Armazena o referer APENAS se for um GET E não for a própria página de edição.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && 
    isset($_SERVER['HTTP_REFERER']) && 
    strpos($_SERVER['HTTP_REFERER'], $current_script_name) === false) {
    
    $_SESSION['previous_page'] = $_SERVER['HTTP_REFERER'];
}
$previous_page = $_SESSION['previous_page'] ?? 'index.php'; // Fallback para index.php


// Pega o ID da URL (GET) ou do campo hidden (POST)
$feedback_id = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['feedback_id']) ? $_POST['feedback_id'] : null); 

// Variáveis para preencher o formulário e status
$feedback_texto = '';
$feedback_avaliacao = null; 
$emocao_selecionada = ''; 
$erro = $erro_conexao;
$sucesso = '';


// --- 2. LÓGICA DE ATUALIZAÇÃO (POST) ---
if ($conexao && $_SERVER['REQUEST_METHOD'] === 'POST' && !$erro) {
    
    $novo_feedback = trim($_POST['feedback'] ?? '');
    $nova_emocao = $_POST['emocao'] ?? '';

    if (empty($novo_feedback) || empty($nova_emocao) || !$feedback_id) {
        $erro = "Todos os campos são obrigatórios.";
        $feedback_texto = $novo_feedback;
        $emocao_selecionada = $nova_emocao;
    } else {
        $nova_avaliacao = ($nova_emocao === 'feliz') ? 5 : 1; 

        try {
            $sql_update = "UPDATE FEEDBACKS_SITE SET TEXTO = ?, AVALIACAO = ? WHERE ID = ? AND USUARIO_ID = ?";
            
            $stmt_update = $conexao->prepare($sql_update);
            
            if (!$stmt_update) {
                throw new Exception("Falha na preparação do statement de UPDATE: " . $conexao->error);
            }

            $stmt_update->bind_param('siii', $novo_feedback, $nova_avaliacao, $feedback_id, $user_id);
            
            if ($stmt_update->execute()) {
                if ($stmt_update->affected_rows > 0) {
                    // *** PADRÃO POST/REDIRECT/GET (PRG) ***
                    // Guarda a URL de retorno na sessão para o JS usar após o redirect
                    $_SESSION['return_to_page'] = $previous_page; 

                    header("Location: editar_feedback.php?id=" . urlencode($feedback_id) . "&status=sucesso");
                    exit;
                } else {
                    $erro = "Nenhuma alteração detectada ou feedback não encontrado/permissão negada.";
                }
            } else {
                $erro = "Erro ao editar o feedback. Tente novamente: " . $stmt_update->error;
            }
            
            $stmt_update->close();
            
            if ($erro) {
                $feedback_texto = $novo_feedback;
                $emocao_selecionada = $nova_emocao;
            }

        } catch (Exception $e) {
            $erro = "Erro de execução do MySQLi: " . $e->getMessage();
            $feedback_texto = $novo_feedback;
            $emocao_selecionada = $nova_emocao;
        }
    }
}


// --- 3. LÓGICA DE BUSCA DE DADOS (GET / Após Sucesso PRG / Após POST Falha) ---
if ($conexao && $feedback_id && !$erro) {
    try {
        $sql_select = "SELECT TEXTO, AVALIACAO FROM FEEDBACKS_SITE WHERE ID = ? AND USUARIO_ID = ?";
        
        $stmt_select = $conexao->prepare($sql_select);
        
        if (!$stmt_select) {
            throw new Exception("Falha na preparação do statement de SELECT: " . $conexao->error);
        }
        
        $stmt_select->bind_param('ii', $feedback_id, $user_id);
        $stmt_select->execute();
        
        $resultado = $stmt_select->get_result();
        $feedback_data = $resultado->fetch_assoc();
        $stmt_select->close();

        if ($feedback_data) {
            
            if ($_SERVER['REQUEST_METHOD'] === 'GET' || empty($feedback_texto)) {
                $feedback_texto = $feedback_data['TEXTO'];
                $feedback_avaliacao = $feedback_data['AVALIACAO'];
                $emocao_selecionada = ($feedback_avaliacao >= 4) ? 'feliz' : 'triste';
            }
        } else {
            $erro = "Feedback não encontrado ou você não tem permissão para editá-lo.";
            $feedback_id = null;
        }
    } catch (Exception $e) {
        $erro = "Erro ao buscar feedback: " . $e->getMessage();
        $feedback_id = null;
    }
} elseif (!$feedback_id && !$erro) {
    $erro = "ID do feedback não fornecido.";
}

// --- 4. TRATAMENTO DO REDIRECT (GET) ---
$return_to_page = 'index.php'; // Default fallback

if (isset($_GET['status']) && $_GET['status'] === 'sucesso') {
    $sucesso = "Feedback editado com sucesso!";
    // Recupera a URL de retorno e limpa a sessão após o redirect de sucesso
    $return_to_page = $_SESSION['return_to_page'] ?? $previous_page;
    unset($_SESSION['return_to_page']);
}

// Fechamento da conexão
if ($conexao) {
    $conexao->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Editar Feedback</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    <style>
        /* --- GERAL (DESKTOP) --- */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(#46004A, #8B0091);
            height: 100vh;
            position: relative;
        }

        header {
            position: absolute;
            top: -95px;
            left: 20px;
            z-index: 100; /* Garante que o logo fique acima do overlay */
        }

        .logo img {
            width: 300px;
            height: auto;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        .container {
            min-width: 620px;
            min-height: 495px;
            background-color: #F0F0F0;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10;
        }
        
        /* ... (Estilos de container, h1, textarea, icones-feedback, selecionado-feliz, selecionado-triste) ... */

        .container h1 {
            color: #4e4e4eff;
            text-align: center;
            margin-top: 35px;
            font-size: 32px;
        }

        .container textarea {
            margin-left: 50px;
            margin-top: 10px;
            border-radius: 5px;
            background-color: #BBBBBB;
            min-width: 500px;
            max-width: 530px;
            min-height: 270px;
            font-size: 20px;
            padding: 10px;
            color: #4e4e4eff;
            font-weight: bold;
            resize: none;
            border: none;
            outline: none;
        }

        .icones-feedback {
            display: flex;
            align-items: center;
            margin: 15px 45px 0 60px;
        }

        .icones-feedback i.fa-face-smile,
        .icones-feedback i.fa-face-frown {
            font-size: 40px;
            color: #4e4e4eff;
            margin-right: 15px;
            transition: color 0.3s;
            cursor: pointer;
        }
        
        .icones-feedback i.fa-face-smile:hover {
            color: #2dda0bff;
        }

        .icones-feedback i.fa-face-frown:hover {
            color: red;
        }

        .icones-feedback button {
            background: none;
            border: none;
            cursor: pointer;
            margin-left: auto;
            padding: 8px;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .icones-feedback button i {
            font-size: 40px;
            color: #3a3a3a;
            transition: color 0.3s, padding 0.25s ease;
        }

        .icones-feedback button:hover {
            background-color: #3a3a3a;
        }

        .icones-feedback button:hover i {
            color: white;
            padding: 8px;
            border-radius: 5px;
        }

        .selecionado-feliz {
            color: #2dda0bff !important;
        }

        .selecionado-triste {
            color: red !important;
        }
        
        /* Toast Notification (APENAS ERRO) */
        .custom-toast {
            visibility: hidden;
            min-width: 300px;
            text-align: center;
            border-radius: 50px;
            padding: 12px 24px;
            position: fixed;
            z-index: 2000;
            left: 50%;
            top: 30px;
            transform: translateX(-50%);
            font-size: 16px;
            font-weight: 600;
            opacity: 0;
            transition: opacity 0.4s ease, top 0.4s ease;
        }
        
        .toast-erro {
            background-color: #dc2626; /* Vermelho */
            color: #fff;
            box-shadow: 0 5px 15px rgba(220, 38, 38, 0.4);
        }
        
        .custom-toast.show {
            visibility: visible;
            opacity: 1;
            top: 50px;
        }

        .custom-toast i {
            margin-right: 8px;
        }

        /* --- NOVO: MODAL DE SUCESSO --- */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none; /* Inicia oculto */
            justify-content: center;
            align-items: center;
            z-index: 500;
        }

        .modal-content {
            background: #fff;
            padding: 40px 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4);
            max-width: 400px;
            width: 90%;
            transform: scale(0.8);
            opacity: 0;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out;
        }

        .modal-overlay.show .modal-content {
            transform: scale(1);
            opacity: 1;
        }
        
        .modal-content i.fa-check-circle {
            color: #16a34a; /* Verde */
            font-size: 60px;
            margin-bottom: 20px;
        }
        
        .modal-content h2 {
            color: #16a34a;
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        
        .modal-content p {
            color: #333;
            margin: 0 0 30px 0;
            font-size: 16px;
        }
        
        .modal-content button {
            background-color: #16a34a;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .modal-content button:hover {
            background-color: #10803a;
        }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 480px) {
            body {
                width: 100%;
                height: auto;
                min-height: 100vh;
            }

            header {
                position: absolute;
                left: 50%;
                transform: translateX(-50%);
                top: -95px;
                width: 100%;
                display: flex;
                justify-content: center;
            }

            .logo img {
                width: 350px;
            }

            .container {
                min-width: 90%;
                width: 90%;
                left: 50%;
                top: 55%;
                transform: translate(-50%, -50%);
                padding: 14px;
                min-height: auto;
                box-sizing: border-box;
            }
            
            .container h1 {
                font-size: 28px;
                margin-top: 10px;
            }


            .container textarea {
                font-size: 20px;
                margin-left: 0;
                margin-top: 10px;
                min-width: 100%;
                width: 100%;
                min-height: 270px;
                padding: 10px;
                box-sizing: border-box;
            }

            .icones-feedback {
                margin: 15px 10px 0 10px;
                justify-content: space-between;
            }

            .icones-feedback button i {
                font-size: 50px;
            }

            .icones-feedback i.fa-face-smile,
            .icones-feedback i.fa-face-frown {
                font-size: 50px;
            }
        }
    </style>
</head>

<body>

    <div id="toast-erro" class="custom-toast toast-erro">
        <i class="fa-solid fa-circle-exclamation"></i>
    </div>
    
    <div id="modal-sucesso" class="modal-overlay">
        <div class="modal-content">
            <i class="fa-solid fa-check-circle"></i>
            <h2>Sucesso!</h2>
            <p id="modal-sucesso-mensagem">Feedback editado com sucesso!</p>
            <button id="btn-ok-redirect">OK</button>
        </div>
    </div>
    
    <header>
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </header>

    <div class="container">
        <?php if ($erro || $sucesso || $feedback_id): ?>
            
            <form id="feedbackForm" method="POST" action="editar_feedback.php?id=<?php echo htmlspecialchars($feedback_id); ?>">
                
                <h1>EDITAR FEEDBACK</h1>
                
                <input type="hidden" name="feedback_id" value="<?php echo htmlspecialchars($feedback_id); ?>">

                <textarea name="feedback" placeholder="Digite seu Feedback" required><?php echo htmlspecialchars($feedback_texto); ?></textarea>

                <input type="hidden" name="emocao" id="campo-emocao" value="<?php echo htmlspecialchars($emocao_selecionada); ?>">

                <div class="icones-feedback">
                    <i id="icone-feliz" class="fa-solid fa-face-smile"></i>
                    <i id="icone-triste" class="fa-solid fa-face-frown"></i>
                    
                    <button type="submit">
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </div>
            </form>
            
        <?php else: ?>
            <h1 style="color: #ef4444; text-align: center; margin-top: 100px;">ERRO: <?php echo htmlspecialchars($erro); ?></h1>
            <p style="text-align: center; margin-left: 0; font-size: 16px; color: #4e4e4eff;">Verifique o link ou se você tem permissão para editar este item.</p>
        <?php endif; ?>
    </div>

    <script>
        const feliz = document.getElementById("icone-feliz");
        const triste = document.getElementById("icone-triste");
        const campoEmocao = document.getElementById("campo-emocao");
        const form = document.getElementById("feedbackForm");
        const toastErro = document.getElementById("toast-erro");
        
        // Novos elementos para o modal
        const modalSucesso = document.getElementById("modal-sucesso");
        const btnOkRedirect = document.getElementById("btn-ok-redirect");
        const modalSucessoMensagem = document.getElementById("modal-sucesso-mensagem");

        // URL para onde o botão OK deve redirecionar (vem do PHP)
        const returnUrl = "<?php echo htmlspecialchars($return_to_page); ?>";

        let selecionado = "<?php echo htmlspecialchars($emocao_selecionada); ?>"; 

        function updateIcons() {
            feliz.classList.remove("selecionado-feliz");
            triste.classList.remove("selecionado-triste");

            if (selecionado === "feliz") {
                feliz.classList.add("selecionado-feliz");
            } else if (selecionado === "triste") {
                triste.classList.add("selecionado-triste");
            }
        }
        
        // Inicializa o estado dos ícones
        updateIcons(); 

        // Lógica de Seleção de Emoção (Permanece igual)
        feliz.addEventListener("click", () => {
            if (selecionado === "feliz") {
                selecionado = null;
                campoEmocao.value = "";
            } else {
                selecionado = "feliz";
                campoEmocao.value = "feliz";
            }
            updateIcons();
        });

        triste.addEventListener("click", () => {
            if (selecionado === "triste") {
                selecionado = null;
                campoEmocao.value = "";
            } else {
                selecionado = "triste";
                campoEmocao.value = "triste";
            }
            updateIcons();
        });

        // Validação antes de enviar (Permanece igual)
        form.addEventListener("submit", function(event) {
            if (campoEmocao.value === "") {
                event.preventDefault(); 
                showToast("Selecione uma avaliação antes de enviar!", 'erro');
            }
        });

        // Função para mostrar o Toast de Erro
        function showToast(message, type) {
            if (type !== 'erro') return; // Apenas trata o erro

            toastErro.innerHTML = toastErro.querySelector('i').outerHTML + message;
            
            toastErro.classList.add("show");
            
            setTimeout(() => {
                toastErro.classList.remove("show");
            }, 3000);
        }

        // Função para mostrar o Modal de Sucesso
        function showSuccessModal(message) {
            modalSucessoMensagem.textContent = message;
            modalSucesso.style.display = 'flex';
            
            // Adiciona a classe 'show' após um pequeno delay para a transição
            setTimeout(() => {
                modalSucesso.classList.add('show');
            }, 10); 
        }

        // Ação do Botão OK
        btnOkRedirect.addEventListener("click", () => {
            window.location.href = returnUrl;
        });
        
        // Exibir Modal/Toast, se houver
        <?php if ($erro): ?>
            showToast("<?php echo htmlspecialchars($erro); ?>", 'erro');
        <?php elseif ($sucesso): ?>
            // Se houver sucesso, exibe o modal
            showSuccessModal("<?php echo htmlspecialchars($sucesso); ?>");
        <?php endif; ?>
        
    </script>

</body>

</html>