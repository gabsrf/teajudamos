<?php

date_default_timezone_set('America/Sao_Paulo');

define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');        

mysqli_report(MYSQLI_REPORT_OFF); 

$conexao = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conexao && !$conexao->connect_error) {
    
    try {

        @$conexao->query("SET time_zone = 'America/Sao_Paulo'");
        
        if ($conexao->error) {
            throw new Exception("Timezone name failed, using offset.");
        }

    } catch (Exception $e) {
        $conexao->query("SET time_zone = '-03:00'");
    }
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

?>