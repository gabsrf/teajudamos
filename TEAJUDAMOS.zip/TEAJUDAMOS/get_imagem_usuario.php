<?php
// Inclua a conexão SEM NENHUM ESPAÇO em branco antes de <?php
include 'conexao.php';

// ********** 1. Limpeza de Buffer **********
// Isso garante que nenhum dado ou espaço em branco anterior interfira no binário da imagem.
if (ob_get_level()) {
    ob_end_clean();
}
// ****************************************

header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
header("Pragma: no-cache");

if ($conexao->connect_error) { 
    exit; 
}

$usuario_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($usuario_id > 0) {
    $stmt = $conexao->prepare("SELECT FOTO_PERFIL FROM USUARIOS WHERE ID = ?");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        
        if (!empty($usuario['FOTO_PERFIL'])) {
            header("Content-Type: image/jpeg"); 
            
            // Imprime o binário
            echo $usuario['FOTO_PERFIL'];
            exit; 
        }
    }
    $stmt->close();
}

$conexao->close();
