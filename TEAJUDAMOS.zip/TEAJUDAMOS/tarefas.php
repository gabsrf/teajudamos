<?php
session_start();
include 'conexao.php';

$usuario_logado = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$nome_usuario = "";
$foto_perfil_existe = false;
$user_id = 0;

if ($usuario_logado) {
    $user_id = $_SESSION['user_id'];
    if ($conexao && !$conexao->connect_error) {
        $stmt_user = $conexao->prepare("SELECT NOME, FOTO_PERFIL, DATA_ATUALIZACAO FROM USUARIOS WHERE ID = ?");
        if ($stmt_user) {
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            if ($result_user->num_rows > 0) {
                $user_data = $result_user->fetch_assoc();
                $full_name = $user_data['NOME'] ?? 'Perfil';
                $first_name = explode(' ', $full_name)[0];
                $nome_usuario = htmlspecialchars($first_name);
                $foto_perfil_existe = !empty($user_data['FOTO_PERFIL']);
            }
            $stmt_user->close();
        }
    }
}

// 2. Lógica para busca e filtro de lições
$termo_pesquisa = isset($_GET['q']) ? trim($_GET['q']) : ''; // Pega o termo de pesquisa

if ($conexao && !$conexao->connect_error) {
    // Consulta base
    $sql_base = "SELECT l.ID, l.TITULO, l.MATERIA, l.DATA_PUBLICACAO, 
                         u.NOME AS PROFESSOR_NOME, u.ID AS PROFESSOR_ID,
                         u.DATA_ATUALIZACAO AS PROFESSOR_DATA_ATUALIZACAO, 
                         (CASE WHEN u.FOTO_PERFIL IS NOT NULL AND LENGTH(u.FOTO_PERFIL) > 0 THEN 1 ELSE 0 END) as TEM_FOTO,
                         (CASE WHEN l.CAPA IS NOT NULL AND LENGTH(l.CAPA) > 0 THEN 1 ELSE 0 END) as TEM_CAPA 
                   FROM LICAO l
                   JOIN USUARIOS u ON l.PROFESSOR_ID = u.ID";
    
    $clausula_where = '';

    if (!empty($termo_pesquisa)) {
        // Usamos prepared statements para segurança contra SQL Injection
        $termo_pesquisa_like = '%' . strtolower($termo_pesquisa) . '%';
        
        // Cláusula WHERE para filtrar pelo título, matéria, assunto OU nome do professor
        $clausula_where = " WHERE 
             LOWER(l.TITULO) LIKE ? OR 
             LOWER(l.MATERIA) LIKE ? OR 
             LOWER(l.ASSUNTO) LIKE ? OR 
             LOWER(u.NOME) LIKE ?";
        
        $sql = $sql_base . $clausula_where . " ORDER BY l.DATA_PUBLICACAO DESC";
        
        $stmt = $conexao->prepare($sql);
        if ($stmt) {
            // Bind dos parâmetros: 4 strings (s) com o termo de pesquisa
            $stmt->bind_param("ssss", $termo_pesquisa_like, $termo_pesquisa_like, $termo_pesquisa_like, $termo_pesquisa_like);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $stmt->close();
        } else {
            $resultado = false;
        }

    } else {
        // Se não houver termo de pesquisa, executa a consulta original
        $sql = $sql_base . " ORDER BY l.DATA_PUBLICACAO DESC";
        $resultado = $conexao->query($sql);
    }
} else {
    $resultado = false;
}

function tempoDecorrido($datetime) {
    // Função de tempoDecorrido permanece a mesma
    $agora = new DateTime();
    $dataPost = new DateTime($datetime);
    $diff = $agora->diff($dataPost);
    if ($diff->y > 0) return 'há ' . $diff->y . ' ano(s)';
    if ($diff->m > 0) return 'há ' . $diff->m . ' mes(es)';
    if ($diff->d > 0) {
        if ($diff->d == 1) return 'ontem';
        return 'há ' . $diff->d . ' dia(s)';
    }
    if ($diff->h > 0) return 'há ' . $diff->h . ' hora(s)';
    if ($diff->i > 0) return 'há ' . $diff->i . ' minuto(s)';
    return 'agora mesmo';
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Tarefas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">


    <style>
        /* --- GERAL --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: white;
            color: #333;
            height: 100vh;
            overflow-x: hidden;
        }

        main {
            width: 100%;
            justify-content: center;
            flex-wrap: wrap;
            padding-top: 60px;
            background: linear-gradient( 180deg, #7c24a1ff, #881288ff );
            min-height: 100%;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* --- HEADER --- */
        header {
            background-color: purple;
            width: 100%;
            padding: 10px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 80px;
            position: fixed;
            top: 0;
            z-index: 100;
        }

        .logo img {
            width: 200px;
            height: auto;
            margin-top: 10px;
            cursor: pointer;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.08);
        }

        /* --- BARRA DE PESQUISA --- */
        .search-container {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .search-container input {
            padding: 15px;
            margin-left: -65px;
            border-radius: 10px;
            border: none;
            width: 450px;
            font-size: 18px;
            font-weight: bold;
        }

        .search-container input:focus {
            outline: none;
        }

        .search-container button {
            background-color: #5e065eff;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            margin-left: -48px;
            padding: 10px;
            transition: all .3s;
        }

        .search-container button:hover {
            transform: scale(1.09);
            border-radius: 0;
            padding: 11px;
        }

        .search-container button i {
            font-size: 25px;
        }

        /* --- ÍCONE DE PERFIL --- */
         .profile-icon {
            position: relative;
            display: inline-block;
        }

        .profile-icon i {
            cursor: pointer;
            transition: transform 0.3s ease-in-out;
            border-radius: 100px;
            position: relative;
            z-index: 1;
            font-size: 50px;
            color: #000000ff;
            transition: color 0.35s ease-in-out, transform 0.3s ease-in-out;
        }
        

        .profile-icon:hover i {
            transform: scale(1.15);
            cursor: pointer;
            color: white;
        }

        .profile-icon img.profile-pic {
            font-size: 50px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #000000ff;
            cursor: pointer;
            transition: transform 0.3s ease-in-out, border-color 0.35s ease-in-out;
            position: relative;
            z-index: 1;
        }

        .profile-icon:hover img.profile-pic {
            transform: scale(1.15);
            border-color: white;
        }
        
        /* From Uiverse.io by reglobby */ 
.user-profile {
    width: 131px;
    height: 51px;
    border-radius: 15px;
    cursor: pointer;
    transition: 0.3s ease;
    background-color: rgb(76,0, 76);
    display: flex;
    align-items: center;
    justify-content: center;
}

.user-profile:hover,
.user-profile:focus {
    background-color: rgba(185, 0, 185);
    box-shadow: 0 0 10px rgba(185, 0, 185);
    outline: none;
}

.user-profile-inner {
    width: 127px;
    height: 47px;
    border-radius: 13px;
    background-color: rgb(76,0, 76);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    color: #fff;
    font-weight: 600;
}

.user-profile-inner svg {
    width: 27px;
    height: 27px;
    fill: #fff;
}


        /* --- FILTROS --- */
        .filter-container {
            position: relative;
            display: inline-block;
            margin: 100px 0 60px 40px;
        }

        .filter-button {
            background-color: #ccc;
            padding: 8px 15px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: transform .3s ease, box-shadow .3s linear;
        }

        .filter-button:hover {
            transform: scale(1.1);
            box-shadow: 0 0 15px rgb(255, 0, 255);
        }

        .filter-button i {
            font-size: 20px;
        }

        .filter-menu {
            position: absolute;
            top: 48px;
            left: 0;
            background: white;
            border: 2px solid purple;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            width: 180px;
            display: none;
            flex-direction: column;
            animation: slideDown 0.5s ease;
            z-index: 10;
        }

        .filter-menu.active {
            display: flex;
        }

        .filter-menu button {
            background: none;
            border: none;
            padding: 12px;
            font-size: 16px;
            text-align: left;
            cursor: pointer;
            color: #4b006e;
            transition: background 0.2s, color 0.2s;
            font-size: 18px;
            font-weight: bold;
        }

        .filter-menu button:hover {
            background: #f1e1ff;
            color: #7e22ce;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* --- GRID DE TAREFAS --- */
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(245px, 1fr));
            gap: 50px;
            padding: 0 50px 30px 50px;
        }

        .card {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            min-height: cover;
            min-width: 245px;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            cursor: pointer;
            transition: margin-top .3s ease-in-out, box-shadow .3s ease, background-color .25s ease;
            background: transparent;
        }
        
        .card:hover{
            margin-top: -15px;
        }

        .card::before {
            content: '';
            position: absolute;
            inset: 0;
            background: rgba(0,0,0,0);
            transition: background 1s ease;
            z-index: 0;
            border-radius: 10px;
        }

        .card img {
            min-height: cover;
            max-width: 100%;
            display: block;
            width: 100%;
            height: 180px;
            object-fit: cover;
            z-index: 1;
            transition: transform .25s ease;
        }
        
        .card img.logo-placeholder {
            object-fit: contain; 
            background-color: white; 
        }

        .card .author {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 5px 12px;
            width: 100%;
            box-sizing: border-box;
            z-index: 2;
            background: purple;
            color: #fff;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            transition: transform .25s ease, background .25s ease;
        }

        .card .author img.author-pic {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.9);
            flex-shrink: 0;
        }

        .card .author i.author-icon {
            font-size: 40px;
            color: white;
            flex-shrink: 0;
            margin-right: 5px;
        }

        .card .author .name {
            font-weight: 600;
            font-size: 14px;
            color: #fff;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .card .author .meta {
            font-size: 12px;
            color: rgba(255,255,255,0.85);
        }

        /* INÍCIO DA ALTERAÇÃO */
        .card .overlay-text {
            width: 100%; 
            left: 0; 
            z-index: 3;
            color: #fff;
            background-color: #C204DE; 
            padding: 8px 12px;
            border-radius: 0; 
            text-align: center;
            font-weight: 600;
            opacity: 1; 
            transform: translateY(0); 
            transition: background .3s ease; 
            pointer-events: none;
        }
        
        .card:hover::before {
            background: rgba(0, 0, 0, 0.8);
        }

        .card:hover img {
            transform: scale(1.03);
        }

   

        .card:hover .author {
            background: rgba(0,0,0,0.6);
        }

        .card .title {
            width: 100%;
            text-align: center;
            font-weight: bold;
            color: white;
            padding: 10px 0;
            border-radius: 8px 8px 0 0;
            position: relative;
            z-index: 2;
            transition: transform .25s ease;
        }


        .matematica .title {
            background-color: #2196f3;
        }

        .portugues .title {
            background-color: #e4261fe8;
        }

        /* --- ÍCONE DE ADICIONAR (NOVO) --- */
        .add-fab {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background-color: #5e065eff; /* Cor roxa forte */
            color: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            z-index: 1000; /* Garante que fique acima de outros elementos */
        }

        .add-fab:hover {
            background-color: #881288ff; /* Cor mais clara ao passar o mouse */
            transform: scale(1.1) rotate(90deg); /* Efeito de rotação e escala */
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /* --- FOOTER --- */
        footer {
            width: 100%;
            background: linear-gradient(90deg, rgb(76,0,76), purple);
            color: white;
            padding: 50px 0 20px;
            font-family: 'Poppins', sans-serif;
        }

        .footer-container {
            width: 90%;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .footer-logo img {
            position: absolute;
            margin-top: -100px;
            width: 400px;
            margin-left: -30px;
        }

        .footer-links,
        .footer-contact {
            min-width: 200px;
        }

        .footer-links h3,
        .footer-contact h3 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #fff;
            position: relative;
        }

        .footer-links h3::after,
        .footer-contact h3::after {
            content: "";
            position: absolute;
            width: 110px;
            height: 3px;
            background: #fff;
            left: 0;
            bottom: -4px;
            border-radius: 2px;
        }

        .footer-links ul,
        .footer-contact ul {
            list-style: none;
            padding: 0;
        }

        .footer-links ul li,
        .footer-contact ul li {
            margin: 10px 0;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-links ul li a {
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links ul li a:hover {
            color: #d63de4ff;
        }

        .footer-bottom {
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.2);
            margin-top: 50px;
            padding-top: 15px;
            font-size: 14px;
            color: #e0d6ff;
        }

        .footer-contact i,
        .footer-links i {
            color: #e0b3ff;
        }

        /* --- RESPONSIVIDADE (MÓVEL) --- */
        @media (max-width: 480px) {
            
            body{
                width: 550px;
            }
            
            header {
                height: 85px;
                gap: 15px;
                padding: 10px 15px;
            }

            /* Esconde a logo grande e o nav */
            .logo img, nav {
                display: none;
            }

            /* Ajusta a barra de pesquisa */
            .search-container {
                width: 100%;
                margin-left: -5px;
            }

            .search-container input {
                width: 100%;
                height: 52px;
                font-size: 20px;
                margin-left: 0; /* Reset margin */
            }

            .search-container button {
                padding: 10px;
                margin-left: -50px;
                margin-top: 1px;
            }

            .search-container button i {
                font-size: 30px;
            }


            /* Ajuste do ícone de perfil */
            .profile-icon i {
                font-size: 60px;
                margin-left: -40px;
            }
            
            .profile-icon img.profile-pic {
                width: 60px;
                height: 60px;
                margin-left: -40px;
            }

            /* Filtro */
            .filter-container {
                margin: 80px 0 40px 10px;
                font-size: 20px;
                padding: 10px 20px;
            }

            .filter-button i {
                font-size: 25px;
            }

            .filter-menu {
                top: 55px;
                left: 0;
                width: 170px;
            }

            .filter-menu button {
                font-size: 22px;
                padding: 15px;
            }

            /* Grid de Tarefas Mobile */
            .grid-container {
                gap: 30px;
                padding: 0 10px 10px 10px;
                min-height: auto;
                grid-template-columns: repeat(2, 1fr);
            }

            .card {
                min-width: 0; 
            }
            
            /* INÍCIO DA ALTERAÇÃO MOBILE */
.card .overlay-text {
    opacity: 1;
    transform: translateY(0); 
    width: 100%; 
    margin-bottom: 20px; /* Mantém a posição igual ao desktop */
    left: 0; 
    background-color: #C204DE; 
    color: #fff;
    font-size: 15px; 
    font-weight: 700; 
    border-radius: 1px;
    text-shadow: 1px 1px 3px rgba(255, 255, 255, 0.3); 
}
       .card img {
            height: 200px; 
            max-width: 100%;
        }
        
        .card .author {
            padding: 18px 10px;
        }

        .card .author img {
            width: 50px;
            height: 50px;
        }

        .card .author .name {
            font-size: 16px; 
        }

        .card .author .meta {
            font-size: 14px;
        }

        .card .title {
            font-size: 20px;
            padding: 10px;
            width: 100%;
        }

        .card:hover {
        transform: scale(1.0); 
    }

    .card::before {
    background: rgba(0,0,0,0); 
    }

    .card:hover::before {
    background: rgba(0,0,0,0); 
    }


    .card:hover img {
        transform: scale(1.0); 
    }

    .card:hover .overlay-text {
        transform: translateX(0);
        opacity: 1; 
    }

    .card:hover .title {
        transform: translateY(0);
    }


            /* Footer Mobile */
            footer {
                padding: 30px 0 10px;
            }

            .footer-container {
                flex-direction: column;
                align-items: center;
                gap: 30px;
                text-align: center;
            }

            .footer-logo img {
                display: none;
            }

            .footer-links h3,
            .footer-contact h3 {
                text-align: center;
                font-size: 24px;
                margin-bottom: 25px;
            }

            .footer-links h3::after,
            .footer-contact h3::after {
                left: 50%;
                transform: translateX(-50%);
            }

            .footer-links ul li,
            .footer-contact ul li {
                justify-content: center;
                font-size: 20px;
            }

            .footer-bottom {
                margin-top: 30px;
            }

            .footer-bottom p {
                font-size: 16px;
            }
            
            .add-fab {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
                font-size: 25px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
           <a href="index.php"> <img src="imagens/logo-teajudamos.png" alt="logo"> </a>
        </div>
        
<form method="GET" action="tarefas.php" class="search-container">
    <input type="text" name="q" placeholder="BUSCAR MATÉRIAS" 
               value="<?php echo htmlspecialchars($termo_pesquisa); ?>">
    
    <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
</form>
        
        <div class="profile-icon">

    <?php if ($usuario_logado): ?>

        <a href="perfil.php" style="text-decoration: none;">

            <?php
            echo $foto_perfil_existe
                ? '<img class="profile-pic" src="get_imagem_usuario.php?id='. $user_id .'&v='. urlencode($user_data['DATA_ATUALIZACAO'] ?? time()) .'" alt="'. $nome_usuario .'" />'
                : '<i class="fa-solid fa-user-circle"></i>';
            ?>

        </a>

    <?php else: ?>

        <a href="login.php" style="text-decoration: none;">
            <div aria-label="User Login Button" tabindex="0" role="button" class="user-profile">
                <div class="user-profile-inner">
                    <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                         viewBox="0 0 24 24">
                             <g id="Layer_2">
                                 <path d="m15.626 11.769a6 6 0 1 0 -7.252 0 9.008 9.008 0 0 0 -5.374 8.231 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 9.008 9.008 0 0 0 -5.374-8.231zm-7.626-4.769a4 4 0 1 1 4 4 4 4 0 0 1 -4-4zm10 14h-12a1 1 0 0 1 -1-1 7 7 0 0 1 14 0 1 1 0 0 1 -1 1z">
                                 </path>
                             </g>
                    </svg>
                    <p>Entrar</p>
                </div>
            </div>
        </a>

    <?php endif; ?>

</div>

    </header>

    <main>
        <div class="filter-container">
            <div class="filter-button" id="filterBtn">
                <i class="fa-solid fa-pen-to-square" ></i>
                FILTRAR
            </div>
            <div class="filter-menu" id="filterMenu">
                <button onclick="filterTasks('todas')">Todas</button>
                <button onclick="filterTasks('portugues')">Português</button>
                <button onclick="filterTasks('matematica')">Matemática</button>
            </div>
        </div>

        <div class="grid-container" id="taskGrid">

        <?php if ($resultado && $resultado->num_rows > 0): ?>
            <?php while($licao = $resultado->fetch_assoc()): ?>
                
                <?php
                $materia_class = strtolower(htmlspecialchars($licao['MATERIA']));
                
                $materia_formatada = htmlspecialchars($licao['MATERIA']);
                if ($materia_formatada === 'portugues') {
                    $materia_formatada = 'Português';
                } elseif ($materia_formatada === 'matematica') {
                    $materia_formatada = 'Matemática';
                } else {
                    $materia_formatada = ucfirst($materia_formatada);
                }
                ?>

                <a href="licao.php?id=<?php echo $licao['ID']; ?>">
                    <div class="card <?php echo $materia_class; ?>">
                        
                        <div class="title"><?php echo $materia_formatada; ?></div>
                        
                        <?php if ($licao['TEM_CAPA']): ?>
                            <img src="get_imagem_licao.php?id=<?php echo $licao['ID']; ?>&tipo=capa" alt="Capa da <?php echo htmlspecialchars($licao['TITULO']); ?>">
                        <?php else: ?>
                            <img class="logo-placeholder" src="imagens/logo-teajudamos.png" alt="Logo padrão - Sem capa para a lição">
                        <?php endif; ?>
                        
                        <div class="overlay-text"><?php echo htmlspecialchars($licao['TITULO']); ?></div>
                        
                        <div class="author">
                            <?php if ($licao['TEM_FOTO']): ?>
                                 <img class="author-pic" src="get_imagem_usuario.php?id=<?php echo $licao['PROFESSOR_ID']; ?>&v=<?php echo urlencode($licao['PROFESSOR_DATA_ATUALIZACAO'] ?? time()); ?>" alt="Autor">
                            <?php else: ?>
                                 <i class="fa-solid fa-user-circle author-icon"></i>
                            <?php endif; ?>
                            
                            <div>
                                <div class="name"><?php echo htmlspecialchars($licao['PROFESSOR_NOME']); ?></div>
                                <div class="meta">Postado <?php echo tempoDecorrido($licao['DATA_PUBLICACAO']); ?></div>
                            </div>
                        </div>
                    </div>
                </a>

            <?php endwhile; ?>
        <?php else: ?>
            <p style="color: white; font-size: 1.2rem; grid-column: 1 / -1; text-align: center;">Nenhuma lição encontrada.</p>
        <?php endif; ?>
        
        <?php
        if ($conexao && !$conexao->connect_error) {
            $conexao->close();
        }
        ?>
        </div>
    
    </main>

    <?php if ($usuario_logado): ?>
    <a href="adicionar_licao.php" class="add-fab" aria-label="Adicionar Nova Lição">
        <i class="fa-solid fa-plus"></i>
    </a>
    <?php endif; ?>
    <footer>
    <div class="footer-container">
        <div class="footer-logo">
            <img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS">
        </div>
        <?php 


$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
            <h3>Navegação</h3>
            <ul>

                <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
                <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
                <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
                <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
                
                <?php 
                // 3. Bloco Condicional para Administrador
                if ($is_admin) {
                    // Este link só será renderizado se o papel for 'admin'
                    // Utilize o ícone 'fa-user-cog' para o ícone de administrador
                    echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
                }
                ?>

                <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

                
            </ul>
        </div>
        <div class="footer-contact">
            <h3>Contato</h3>
            <ul>
                <li><i class="fa-solid fa-envelope"></i> teajudamos@gmail.com</li>
                <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
    </div>
</footer>

    <script>
        const filterBtn = document.getElementById('filterBtn');
        const filterMenu = document.getElementById('filterMenu');
        const cards = document.querySelectorAll('.card');

        filterBtn.addEventListener('click', () => {
            filterMenu.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
            if (!filterBtn.contains(e.target) && !filterMenu.contains(e.target)) {
                filterMenu.classList.remove('active');
            }
        });

        function filterTasks(tipo) {
            // Se a opção for 'todas', redireciona para a página de tarefas (sem parâmetros)
            if (tipo === 'todas') {
                window.location.href = 'tarefas.php'; // Redireciona para recarregar a página sem filtros
                return; 
            }

            // Lógica de filtro local para 'portugues' e 'matematica'
            cards.forEach(card => {
                const cardLink = card.parentElement;  
                if (card.classList.contains(tipo)) {
                    cardLink.style.display = 'block';
                } else {
                    cardLink.style.display = 'none';
                }
            });
            filterMenu.classList.remove('active');
        }
        
        // Verifica se existe um filtro na URL
        const params = new URLSearchParams(window.location.search);
        const filtroUrl = params.get('filtro');

        if (filtroUrl) {
            // Se houver filtro na URL, executa a função filterTasks automaticamente
            filterTasks(filtroUrl);
        }
    </script>
</body>
</html>