<?php
session_start();
include 'conexao.php'; // Necessário para buscar a foto do perfil no header

// Define o fuso horário
date_default_timezone_set('America/Sao_Paulo');

// Se não houver prévia, redireciona de volta
if (!isset($_SESSION['previa'])) {
    header('Location: adicionar_licao.php?erro=semprevia');
    exit;
}

// Verifica usuário para o Header
$usuario_logado = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$user_id = $_SESSION['user_id'] ?? 0;
$nome_usuario = "";
$foto_perfil_existe = false;
$data_atualizacao = time();


if ($usuario_logado) {
    if ($conexao && !$conexao->connect_error) {
        $stmt_user = $conexao->prepare("SELECT NOME, FOTO_PERFIL, DATA_ATUALIZACAO FROM USUARIOS WHERE ID = ?");
        if ($stmt_user) {
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            if ($result_user->num_rows > 0) {
                $user_data = $result_user->fetch_assoc();
                $nome_usuario = htmlspecialchars(explode(' ', $user_data['NOME'])[0]);
                $foto_perfil_existe = !empty($user_data['FOTO_PERFIL']);
            }
            $stmt_user->close();
        }
    }
}

// Pega os dados da sessão
$dados = $_SESSION['previa']['post'];
$arquivos = $_SESSION['previa']['files'];

$nome_professor = $dados['email_contato'] ? "Contato: " . $dados['email_contato'] : "Professor(a) Anônimo(a)";

// Data atual
$data_publicacao = date('d/m/Y H:i');

// Título
$titulo = htmlspecialchars($dados['titulo'] ?? 'Lição Sem Título');

// Arrays de dados
$observacoes = $dados['obs'] ?? [];
$objetivos = $dados['obj'] ?? [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">
    
    
    <title>Visualização da Lição</title>
    <style>
        /* --- GERAL --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fafb;
            min-height: 100vh;
            line-height: 1.6;
            /* Padding top apenas no desktop por causa do header fixo */
            padding-top: 80px;
        }

        /* --- HEADER (Desktop Fixo) --- */
        header {
            background-color: purple;
            width: 100%;
            padding: 10px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 80px;
            position: fixed;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        .logo img {
            width: 200px;
            height: auto;
            object-fit: cover;
            cursor: pointer;
            transition: 0.3s;
        }

        .logo img:hover {
            transform: scale(1.08);
        }

        .profile-icon {
            position: relative;
            display: inline-block;
        }

        .profile-icon i {
            font-size: 50px;
            color: #000;
            transition: 0.3s;
            border-radius: 50%;
        }

        .profile-icon:hover i {
            color: white;
            transform: scale(1.15);
        }

        .profile-icon img.profile-pic {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #000;
            transition: 0.3s;
        }

        .profile-icon:hover img.profile-pic {
            transform: scale(1.15);
            border-color: white;
        }

        /* --- CONTAINER PRINCIPAL --- */
        .container {
            max-width: 1024px;
            margin: 0 auto;
            padding: 0 16px;
        }

        .main {
            padding: 24px 0;
        }

        /* --- CABEÇALHO DA LIÇÃO --- */
        .lesson-header {
            background: purple;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .lesson-title h1 {
            font-size: 28px;
            font-weight: bold;
            color: #ffffffff;
            margin-bottom: 5px;
        }

        .lesson-title p {
            color: #c4b5fd;
            font-size: 14px;
        }

        .lesson-date {
            text-align: right;
            font-size: 14px;
            color: #c4b5fd;
        }

        .lesson-date strong {
            display: block;
            font-size: 16px;
            color: #ffffffff;
        }

        /* --- SEÇÕES DE CONTEÚDO --- */
        .section {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 32px;
            margin-bottom: 24px;
        }

        .section-title {
            font-size: 20px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-icon {
            width: 32px;
            height: 32px;
            background-color: purple;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: bold;
        }

        /* --- OBJETIVOS --- */
        .objectives-list li {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #4b5563;
        }

        .bullet {
            width: 8px;
            height: 8px;
            background: purple;
            border-radius: 50%;
        }

        /* --- MATERIAIS --- */
        .materials-grid {
            display: grid;
            gap: 24px;
            grid-template-columns: 1fr 1fr;
        }

        .materials-section h3 {
            font-size: 18px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 12px;
        }

        .material-item {
            border: 1px solid #e5e7eb;
            padding: 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
            background: #f9fafb;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .material-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.6);
        }

        /* Estilos específicos para PDF e Imagem para combinar com a versão mobile e desktop */
        .pdf-item {
            background-color: #f9fafb;
            border-color: #e5e7eb;
        }

        .image-item {
            background-color: #f9fafb;
            border-color: #e5e7eb;
        }

        .material-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
            flex-shrink: 0;
        }

        .pdf-icon {
            background-color: #ef4444;
        }

        .image-icon {
            background-color: #3b82f6;
        }

        .material-info h4 {
            font-weight: 600;
            color: #374151;
            font-size: 16px;
        }

        .material-btn {
            background-color: purple;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            padding: 8px 16px;
            text-decoration: none;
            font-weight: 600;
            margin-left: auto;
            transition: 0.2s;
        }

        .material-btn:hover {
            transform: scale(1.05);
            filter: brightness(1.2);
        }

        /* --- OBSERVAÇÕES --- */
        .observation-box {
            background: linear-gradient(135deg, #F3E8FF 0%, #EDE9FE 100%);
            border-left: 4px solid #8B5CF6;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .observation-title {
            font-weight: bold;
            color: #6b21a8;
            margin-bottom: 10px;
        }

        .observation-text {
            color: #374151;
            font-size: 14px;
            line-height: 1.6;
        }

        /* --- BOTÕES DE AÇÃO --- */
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }

        .edit-btn {
            background-color: #d8b4fe;
            color: #46004A;
        }

        .edit-btn:hover {
            background-color: #c084fc;
        }

        /* --- FOOTER --- */
        footer {
            width: 100%;
            background: linear-gradient(90deg, rgb(76, 0, 76), purple);
            color: white;
            padding: 50px 0 20px;
            margin-top: 50px;
            font-family: 'Poppins', sans-serif;
        }

        .footer-container {
            width: 90%;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .footer-logo img {
            position: absolute;
            margin-top: -100px;
            width: 400px;
            margin-left: -30px;
        }

        .footer-links ul,
        .footer-contact ul {
            list-style: none;
            padding: 0;
        }

        .footer-links ul li,
        .footer-contact ul li {
            margin: 10px 0;
            display: flex;
            gap: 8px;
        }

        .footer-links ul li a {
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links ul li a:hover {
            color: #d63de4ff;
        }

        .footer-bottom {
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            margin-top: 50px;
            padding-top: 15px;
            font-size: 14px;
            color: #e0d6ff;
        }

        .footer-contact i,
        .footer-links i {
            color: #e0b3ff;
        }

        /* --- MODAL --- */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            padding-top: 60px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.9);
        }

        .modal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 800px;
            animation-name: zoom;
            animation-duration: 0.6s;
        }

        @keyframes zoom {
            from {
                transform: scale(0)
            }

            to {
                transform: scale(1)
            }
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }

        .modal-close:hover {
            color: #bbb;
        }

        /* --- MEDIA QUERIES PARA CELULAR --- */
        @media (max-width: 768px) {
            body {
                padding-top: 0;
                /* Remove o padding do header fixo */
            }

            /* Ajuste do Header para ficar parecido com a versão mobile */
            header {
                position: relative;
                height: auto;
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .header-content {
                display: flex;
                flex-direction: column;
                width: 100%;
            }

            /* Aumentando fontes para mobile conforme solicitado */
            .lesson-title h1 {
                font-size: 40px;
                margin-bottom: 10px;
            }

            .lesson-title p {
                font-size: 20px;
            }

            .lesson-date {
                text-align: left;
                margin-top: 10px;
                width: 100%;
            }

            .lesson-date p {
                font-size: 18px;
            }

            .lesson-date strong {
                font-size: 24px;
            }

            /* Ajuste nas colunas dos materiais */
            .materials-grid {
                grid-template-columns: 1fr;
            }

            /* Estilos dos cards de materiais no mobile */
            .material-item {
                padding: 12px;
            }

            /* Estilos específicos que estavam no arquivo mobile */
            .pdf-item,
            .image-item {
                background-color: #8B5CF6;
                border-color: #8B5CF6;
                color: white;
            }

            .material-info h4 {
                color: white;
                font-size: 20px;
            }

            .material-icon {
                width: 55px;
                height: 55px;
                font-size: 20px;
            }

            .material-btn {
                font-size: 18px;
                padding: 10px 15px;
                border-radius: 15px;
            }

            /* Seções */
            .section-title {
                font-size: 30px;
            }

            .section-icon {
                width: 45px;
                height: 45px;
            }

            .section-icon i {
                font-size: 20px;
            }

            .objectives-list li {
                font-size: 20px;
            }

            .bullet {
                width: 12px;
                height: 12px;
                margin-top: 10px;
            }

            /* Observações */
            .observation-title {
                font-size: 22px;
            }

            .observation-text {
                font-size: 18px;
            }

            /* Footer Mobile */
            .footer-container {
                flex-direction: column;
                align-items: center;
                gap: 30px;
                text-align: center;
            }

            .footer-logo img {
                display: none;
            }

            .footer-links h3,
            .footer-contact h3 {
                text-align: center;
                font-size: 33px;
                margin-bottom: 45px;
            }

            .footer-links h3::after,
            .footer-contact h3::after {
                left: 50%;
                transform: translateX(-50%);
            }

            .footer-links ul li,
            .footer-contact ul li {
                justify-content: center;
                font-size: 25px;
            }

            .footer-bottom p {
                font-size: 20px;
            }
            
            /* Esconder ícone de perfil no mobile se necessário, ou adaptar */
            .profile-icon {
                position: absolute;
                top: 20px;
                right: 20px;
            }
        }
    </style>
</head>
<body>

    <header>
        <div class="logo">
            <a href="index.php"><img src="imagens/logo-teajudamos.png" alt="logo"></a>
        </div>
        <div class="profile-icon">
            <?php if ($usuario_logado): ?>
                <a href="perfil.php" style="text-decoration: none;">

        <?php
          echo $foto_perfil_existe
            ? '<img class="profile-pic" src="get_imagem_usuario.php?id='. $user_id .'&v='. $data_atualizacao .'" alt="'. $nome_usuario .'" />'
            : '<i class="fa-solid fa-user-circle"></i>';
        ?>

      </a>

            <?php else: ?>
                <a href="login.php"><i class="fa-solid fa-user-circle"></i></a>
            <?php endif; ?>
        </div>
    </header>

    <main class="main">
        <div class="container">

            <div class="lesson-header">
                <div class="lesson-title">
                    <h1><?php echo $titulo; ?></h1>
                    <p><?php echo htmlspecialchars($nome_professor); ?></p>
                </div>
                <div class="lesson-date">
                    <p>Pré-visualização</p>
                    <strong><?php echo $data_publicacao; ?></strong>
                </div>
            </div>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"><i class="fas fa-book icon"></i></span>Objetivos da Lição</h2>
                <ul class="objectives-list">
                    <?php if (!empty($objetivos)): ?>
                        <?php foreach ($objetivos as $obj): if (!empty($obj)): ?>
                                <li><span class="bullet"></span><?php echo htmlspecialchars($obj); ?></li>
                        <?php endif;
                        endforeach; ?>
                    <?php else: ?>
                        <li><span class="bullet"></span>Nenhum objetivo informado.</li>
                    <?php endif; ?>
                </ul>
            </section>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"><i class="fa-solid fa-folder-open"></i></span>Materiais da Lição</h2>
                <div class="materials-grid">

                    <div class="materials-section">
                        <h3><i class="fa-solid fa-file-lines"></i> Documentos PDF</h3>
                        <?php if (!empty($arquivos['anexo'][0]['conteudo'])): ?>
                            <div class="material-item pdf-item">
                                <div class="material-icon pdf-icon">PDF</div>
                                <div class="material-info">
                                    <h4 class="material-title"><?php echo htmlspecialchars($arquivos['anexo'][0]['nome']); ?></h4>
                                </div>
                                <a href="get_anexo_previa.php?index=0" class="material-btn" target="_blank">Baixar</a>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($arquivos['anexo'][1]['conteudo'])): ?>
                            <div class="material-item pdf-item">
                                <div class="material-icon pdf-icon">PDF</div>
                                <div class="material-info">
                                    <h4 class="material-title"><?php echo htmlspecialchars($arquivos['anexo'][1]['nome']); ?></h4>
                                </div>
                                <a href="get_anexo_previa.php?index=1" class="material-btn" target="_blank">Baixar</a>
                            </div>
                        <?php endif; ?>

                        <?php if (empty($arquivos['anexo'][0]['conteudo']) && empty($arquivos['anexo'][1]['conteudo'])): ?>
                            <p>Nenhum documento.</p>
                        <?php endif; ?>
                    </div>

                    <div class="materials-section">
                        <h3><i class="fas fa-image"></i> Imagens e Diagramas</h3>
                        <?php if (!empty($arquivos['img'][0]['conteudo'])): ?>
                            <div class="material-item image-item">
                                <div class="material-icon image-icon">IMG</div>
                                <div class="material-info">
                                    <h4 class="material-title">Imagem 1</h4>
                                </div>
                                <button class="material-btn" onclick="openImageModal('get_imagem_previa.php?tipo=img&index=0&t=<?php echo time(); ?>')">Ver</button>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($arquivos['img'][1]['conteudo'])): ?>
                            <div class="material-item image-item">
                                <div class="material-icon image-icon">IMG</div>
                                <div class="material-info">
                                    <h4 class="material-title">Imagem 2</h4>
                                </div>
                                <button class="material-btn" onclick="openImageModal('get_imagem_previa.php?tipo=img&index=1&t=<?php echo time(); ?>')">Ver</button>
                            </div>
                        <?php endif; ?>

                        <?php if (empty($arquivos['img'][0]['conteudo']) && empty($arquivos['img'][1]['conteudo'])): ?>
                            <p>Nenhuma imagem.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"><i class="fa-regular fa-newspaper"></i></span>Observações</h2>
                <?php if (!empty($observacoes)): foreach ($observacoes as $index => $obs): if (!empty($obs)): ?>
                            <div class="observation-box">
                                <h3 class="observation-title">Observação <?php echo $index + 1; ?></h3>
                                <p class="observation-text"><?php echo nl2br(htmlspecialchars($obs)); ?></p>
                            </div>
                    <?php endif;
                    endforeach;
                else: ?>
                    <p>Nenhuma observação informada.</p>
                <?php endif; ?>
            </section>

            <div class="action-buttons">
                <a href="adicionar_licao.php?edit=previa" class="material-btn edit-btn" style="display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-pen"></i> Editar
                </a>

                <form action="publicar_licao.php" method="POST" style="display:inline;">
                    <button type="submit" class="material-btn" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fa-solid fa-check"></i> Concluir e Publicar
                    </button>
                </form>
            </div>

        </div>
    </main>

    <footer id="footer">
        <div class="footer-container">
            <div class="footer-logo"><img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS"></div>
            <?php 
// 1. Verifica se a sessão está iniciada e se o usuário é administrador
// É crucial garantir que session_start(); foi chamado no topo da sua página.
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
          <h3>Navegação</h3>
          <ul>

        <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
        <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
        <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
        <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
        
        <?php 
        // 3. Bloco Condicional para Administrador
        if ($is_admin) {
            // Este link só será renderizado se o papel for 'admin'
            // Utilize o ícone 'fa-user-cog' para o ícone de administrador
            echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
        }
        ?>

        <!-- 4. Link de Entrar/Sair Dinâmico -->
        <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

            
          </ul>
        </div>
            <div class="footer-contact">
                <h3>Contato</h3>
                <ul>
                    <li><i class="fa-solid fa-envelope"></i> teajudamos@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
        </div>
    </footer>

    <div id="imageModal" class="modal">
        <span class="modal-close">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <script>
        var modal = document.getElementById("imageModal");
        var modalImg = document.getElementById("modalImage");
        var span = document.getElementsByClassName("modal-close")[0];

        function openImageModal(imgSrc) {
            modal.style.display = "block";
            modalImg.src = imgSrc;
        }

        span.onclick = function() {
            modal.style.display = "none";
        }
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>
</html>