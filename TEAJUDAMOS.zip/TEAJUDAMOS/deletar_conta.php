<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$conexao->begin_transaction();

try {

    $stmt_delete = $conexao->prepare("DELETE FROM USUARIOS WHERE ID = ?");
    $stmt_delete->bind_param("i", $user_id);
    $stmt_delete->execute();
    $stmt_delete->close();

    $conexao->commit();
    
    // 5. Destrói a sessão e redireciona
    session_destroy();
    header('Location: login.php?sucesso=contaexcluida');
    exit;

} catch (Exception $e) {
    // 6. Em caso de erro, desfaz a transação
    $conexao->rollback();
    error_log("Erro ao deletar conta: " . $e->getMessage());
    header('Location: perfil.php?erro=deletar');
    exit;
}
?>