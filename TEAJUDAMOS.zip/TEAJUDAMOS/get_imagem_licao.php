<?php
include 'conexao.php';
if ($conexao->connect_error) { die("Falha na conexão: ". $conexao->connect_error); }

$licao_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$tipo_img = isset($_GET['tipo']) ? $_GET['tipo'] : 'capa'; 
$coluna_img = 'CAPA';
if ($tipo_img == 'img1') { $coluna_img = 'IMAGEM_1'; } 
elseif ($tipo_img == 'img2') { $coluna_img = 'IMAGEM_2'; }

if ($licao_id > 0) {
    $stmt = $conexao->prepare("SELECT $coluna_img FROM LICAO WHERE ID = ?");
    $stmt->bind_param("i", $licao_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    if ($resultado->num_rows > 0) {
        $licao = $resultado->fetch_assoc();
        header("Content-Type: image/jpeg"); 
        echo $licao[$coluna_img];
    }
    $stmt->close();
}
$conexao->close();
?>