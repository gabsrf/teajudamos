<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Início do Bloco PHP
include 'conexao.php';
$mensagem_erro = "";
$mensagem_sucesso = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Pega os dados do formulário
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $cpf = $_POST['cpf'];
    $rg = $_POST['rg'];
    $ra = $_POST['ra'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $senha_confirm = $_POST['senha_confirm'];

    // Validação simples
    if (empty($nome) || empty($email) || empty($cpf) || empty($rg) || empty($ra) || empty($senha)) {
        $mensagem_erro = "Por favor, preencha todos os campos obrigatórios.";
    } elseif ($senha != $senha_confirm) {
        $mensagem_erro = "As senhas não conferem!";
    } else {
        // Criptografa a senha
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        if ($conexao->connect_error) {
            die("Falha na conexão: " . $conexao->connect_error);
        }

        // Prepara o INSERT para a tabela CADASTROS_PENDENTES
        $stmt = $conexao->prepare(
            "INSERT INTO CADASTROS_PENDENTES (NOME_PRIMEIRO, NOME_SOBRENOME, EMAIL, CPF, RG, RA, SENHA_HASH)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        
        // Sete parâmetros: Nome, Sobrenome, Email, CPF, RG, RA, Senha (hash)
        $stmt->bind_param("sssssss", $nome, $sobrenome, $email, $cpf, $rg, $ra, $senha_hash);

        try {
            if ($stmt->execute()) {
                // Mensagem de sucesso atualizada para aprovação pendente
                $mensagem_sucesso = "Cadastro realizado com sucesso! Sua conta está pendente de aprovação.";
            }
        } catch (mysqli_sql_exception $e) {
            // Erro (provavelmente email ou CPF duplicado)
            if ($e->getCode() == 1062) { // 1062 = Duplicate entry
                $mensagem_erro = "Erro: E-mail ou CPF já cadastrado.";
            } else {
                $mensagem_erro = "Erro ao cadastrar: " . $e->getMessage();
            }
        }
        $stmt->close();
        $conexao->close();
    }
}
// Fim do Bloco PHP
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">


    <title>CADASTRO</title>
    <style>
        /* --- GERAL (DESKTOP) --- */
        body {
            font-family: 'Poppins', sans-serif;
            margin-top: 22px;
            margin-bottom: 20px;
            padding: 0;
            background: linear-gradient(#46004A, #8B0091);
            min-height: cover;
            position: relative;
        }

        header {
            position: absolute;
            top: -95px;
            left: 20px;
        }

        .logo img {
            width: 300px;
            height: auto;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        /* --- FORMULÁRIO --- */
        .form {
            top: 50%;
            left: 50%;
            transform: translate(-50%, 0);
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 490px;
            min-height: 600px;
            padding: 20px;
            border-radius: 20px;
            position: relative;
            background-color: #1a1a1a;
            color: #fff;
            border: 1px solid #333;
        }

        .title {
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -1px;
            position: relative;
            display: flex;
            align-items: center;
            padding-left: 30px;
            color: white;
        }

        .title::before {
            width: 18px;
            height: 18px;
        }

        .title::after {
            width: 18px;
            height: 18px;
            animation: pulse 1s linear infinite;
        }

        .title::before,
        .title::after {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            border-radius: 50%;
            left: 0px;
            background-color: #ec03ecff;
        }

        .message,
        .signin {
            font-size: 16px;
            color: #ec03eccf;
        }

        /* Mensagens de feedback */
        .message.erro {
            color: #D8000C;
            background-color: #FFD2D2;
            border: 1px solid #D8000C;
            border-radius: 8px;
            text-align: center;
            padding: 10px;
            font-weight: 600;
        }

        .message.sucesso {
            color: #270;
            background-color: #DFF2BF;
            border: 1px solid #4F8A10;
            border-radius: 8px;
            text-align: center;
            padding: 10px;
            font-weight: 600;
        }

        .signin {
            text-align: center;
        }

        .signin a {
            color: white;
            text-decoration: none;
            position: relative;
        }

        .signin a::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            height: 2px;
            width: 0;
            background: white;
            transition: width 0.3s ease-in-out;
        }

        .signin a:hover::after {
            width: 100%;
        }

        .flex {
            display: flex;
            width: 100%;
            gap: 20px;
        }

        .flex :nth-child(1) {
            width: 50%;
        }

        .flex :nth-child(2) {
            width: 50%;
        }

        .form label {
            position: relative;
        }

        .form label .input {
            background-color: #333;
            color: #fff;
            margin-left: -8px;
            width: 100%;
            padding: 20px 05px 05px 10px;
            outline: 0;
            border: 1px solid rgba(105, 105, 105, 0.397);
            border-radius: 10px;
        }

        .form label .input + span {
            color: rgba(255, 255, 255, 0.5);
            position: absolute;
            left: 10px;
            top: 0px;
            font-size: 0.9em;
            cursor: text;
            transition: 0.3s ease;
        }

        .form label .input:placeholder-shown + span {
            top: 12.5px;
            font-size: 0.9em;
        }

        .form label .input:focus + span,
        .form label .input:valid + span {
            color: #ec03eccf;
            top: 0px;
            font-size: 0.7em;
            font-weight: 600;
        }

        .input {
            font-size: medium;
        }

        .submit {
            border: none;
            outline: none;
            padding: 10px;
            border-radius: 10px;
            color: black;
            font-size: 18px;
            font-weight: bold;
            transform: .3s ease;
            background-color: #ec03ecff;
            transition: background 0.5s ease-in-out, color 0.5s ease-in-out;
        }

        .submit:hover {
            background-color: #870087;
            color: white;
            cursor: pointer;
        }

        @keyframes pulse {
            from {
                transform: scale(0.9);
                opacity: 1;
            }
            to {
                transform: scale(1.8);
                opacity: 0;
            }
        }

        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            width: 300px;
        }

        .toggle-password {
            position: absolute;
            right: 0px;
            top: 55%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 25px;
            color: #ec03ecb0;
        }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 480px) {
            body {
                width: 100%;
                height: auto;
                min-height: 80vh;
            }
            
            header{
                display: none;
            }

            .form {
                max-width: 90%;
                min-height: auto;
                padding: 15px;
                justify-content: center;
                gap: 8px;
                top: 12%;
                margin-left: -5px;
            }

            .form label .input {
                padding: 15px 8px 8px 8px;
                width: 100%;
                box-sizing: border-box;
                margin-left: 0;
            }

            .form label .input + span {
                left: 8px;
            }

            .submit {
                font-size: 16px;
                padding: 8px;
                margin-top: 20px;
            }
            
            /* Ajuste para inputs de senha no mobile */
            .password-wrapper input {
                width: 100%;
            }
            
            .toggle-password {
                right: 10px;
            }
        }
    </style>
</head>

<body>
    <header>
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </header>

    <form class="form" method="POST" action="cadastro.php">
        <p class="title">CADASTRO </p>
        <p class="message">Faça o cadastro para aproveitar sua conta. </p>

        <?php if (!empty($mensagem_erro)): ?>
            <p class="message erro"><?php echo $mensagem_erro; ?></p>
        <?php endif; ?>
        <?php if (!empty($mensagem_sucesso)): ?>
            <p class="message sucesso"><?php echo $mensagem_sucesso; ?></p>
        <?php endif; ?>

        <div class="flex">
            <label>
                <input class="input" type="text" placeholder="" required="" name="nome">
                <span>Nome</span>
            </label>
            <label>
                <input class="input" type="text" placeholder="" required="" name="sobrenome">
                <span>Sobrenome</span>
            </label>
        </div>

        <label>
            <input class="input" type="text" placeholder="" required="" name="cpf" id="cpf" onkeyup="formatarCPF(this)">
            <span>CPF</span>
        </label>

        <label>
            <input class="input" type="text" placeholder="" required="" name="rg" id="rg" onkeyup="formatarRG(this)">
            <span>RG</span>
        </label>

        <label>
            <input class="input" type="text" placeholder="" required="" name="ra" id="ra" onkeyup="formatarRA(this)">
            <span>RA</span>
        </label>

        <label>
            <input class="input" type="email" placeholder="" required="" name="email">
            <span>E-mail</span>
        </label>

        <label>
            <div class="password-wrapper">
                <input class="input password" type="password" placeholder="" required name="senha">
                <span>Senha</span>
                <i class="fa-solid fa-eye toggle-password"></i>
            </div>
        </label>

        <label>
            <div class="password-wrapper">
                <input class="input password" type="password" placeholder="" required name="senha_confirm">
                <span>Confirme sua Senha</span>
                <i class="fa-solid fa-eye toggle-password"></i>
            </div>
        </label>

        <button class="submit">CADASTRAR</button>
        <p class="signin">Já tem uma conta ? <a href="login.php">Faça Login</a> </p>
    </form>

    <script>
        // Formata o campo CPF: 000.000.000-00
        function formatarCPF(campo) {
            let valor = campo.value.replace(/\D/g, "");
            if (valor.length > 11) {
                valor = valor.substring(0, 11);
            }
            if (valor.length > 9) {
                valor = valor.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
            } else if (valor.length > 6) {
                valor = valor.replace(/^(\d{3})(\d{3})(\d{3})$/, "$1.$2.$3");
            } else if (valor.length > 3) {
                valor = valor.replace(/^(\d{3})(\d{3})$/, "$1.$2");
            } else if (valor.length > 0) {
                valor = valor.replace(/^(\d{3})$/, "$1");
            }
            campo.value = valor;
            campo.maxLength = 14; 
        }

        // Formata o campo RG: 00.000.000-0
        function formatarRG(campo) {
            let valor = campo.value.replace(/\D/g, "");
            if (valor.length > 9) {
                valor = valor.substring(0, 9);
            }
            if (valor.length > 8) {
                valor = valor.replace(/^(\d{2})(\d{3})(\d{3})(\d{1})$/, "$1.$2.$3-$4");
            } else if (valor.length > 5) {
                valor = valor.replace(/^(\d{2})(\d{3})(\d{3})$/, "$1.$2.$3");
            } else if (valor.length > 2) {
                valor = valor.replace(/^(\d{2})(\d{3})$/, "$1.$2");
            } else if (valor.length > 0) {
                valor = valor.replace(/^(\d{2})$/, "$1");
            }
            campo.value = valor;
            campo.maxLength = 12;
        }

        // NOVO: Formata o campo RA de Professor: 000000-00 (Exemplo: 8 dígitos + 1 símbolo = 9 caracteres)
        function formatarRA(campo) {
            // Remove tudo que não for dígito
            let valor = campo.value.replace(/\D/g, "");

            // Limita a 8 dígitos (padrão assumido)
            if (valor.length > 8) {
                valor = valor.substring(0, 8);
            }

            // Aplica a formatação: 000000-00
            if (valor.length > 6) {
                valor = valor.replace(/^(\d{6})(\d{1,2})$/, "$1-$2");
            }

            campo.value = valor;

            // Define o limite máximo de caracteres com a formatação (9)
            campo.maxLength = 9; 
        }

        // Script para mostrar/esconder senha
        const toggleIcons = document.querySelectorAll('.toggle-password');

        toggleIcons.forEach(icon => {
            icon.addEventListener('click', () => {
                const passwordInput = icon.closest('.password-wrapper').querySelector('.password');
                const isPassword = passwordInput.type === 'password';

                passwordInput.type = isPassword ? 'text' : 'password';

                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
            });
        });
    </script>

</body>

</html>