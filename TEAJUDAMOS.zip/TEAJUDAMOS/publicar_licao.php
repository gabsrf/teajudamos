<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();
include 'conexao.php';

if (!isset($_SESSION['previa']) || !isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

$dados = $_SESSION['previa']['post'];
$arquivos = $_SESSION['previa']['files'];
$professor_id = (int)$_SESSION['user_id'];

$titulo = $dados['titulo'] ?? 'Sem Título';
$materia = $dados['materia'] ?? null;
$email_contato = $dados['email_contato'] ?? null;

$obs_1 = $dados['obs'][0] ?? null;
$obs_2 = $dados['obs'][1] ?? null;
$obs_3 = $dados['obs'][2] ?? null;

$obj_1 = $dados['obj'][0] ?? null;
$obj_2 = $dados['obj'][1] ?? null;
$obj_3 = $dados['obj'][2] ?? null;

$texto = null;

// Arquivos (BLOB)
$capa = $arquivos['capa']['conteudo'] ?? null;
$img_1 = $arquivos['img'][0]['conteudo'] ?? null;
$img_2 = $arquivos['img'][1]['conteudo'] ?? null;
$anexo_1 = $arquivos['anexo'][0]['conteudo'] ?? null;
$anexo_2 = $arquivos['anexo'][1]['conteudo'] ?? null;

// (NOVO) Nomes dos Arquivos
$nome_anexo_1 = $arquivos['anexo'][0]['nome'] ?? null;
$nome_anexo_2 = $arquivos['anexo'][1]['nome'] ?? null;

// Query Atualizada com NOME_ANEXO
$sql = "INSERT INTO LICAO 
        (TITULO, MATERIA, EMAIL_CONTATO, TEXTO,
         OBSERVACAO_1, OBSERVACAO_2, OBSERVACAO_3,
         OBJETIVOS_1, OBJETIVOS_2, OBJETIVOS_3,
         CAPA, IMAGEM_1, IMAGEM_2, ANEXO_1, ANEXO_2,
         NOME_ANEXO_1, NOME_ANEXO_2,
         PROFESSOR_ID, DATA_PUBLICACAO)
        VALUES 
        (?, ?, ?, ?, 
         ?, ?, ?, 
         ?, ?, ?, 
         ?, ?, ?, ?, ?, 
         ?, ?,
         ?, NOW())";

$stmt = $conexao->prepare($sql);

$null_blob = null;
// Tipos: 10 strings + 5 blobs + 2 strings (nomes anexo) + 1 int
$types = "ssssssssssbbbbbssi";

$stmt->bind_param($types, 
    $titulo, $materia, $email_contato, $texto,
    $obs_1, $obs_2, $obs_3,
    $obj_1, $obj_2, $obj_3,
    $null_blob, $null_blob, $null_blob, $null_blob, $null_blob, // Blobs placeholder
    $nome_anexo_1, $nome_anexo_2, // Novos campos de nome
    $professor_id
);

if ($capa) $stmt->send_long_data(10, $capa);
if ($img_1) $stmt->send_long_data(11, $img_1);
if ($img_2) $stmt->send_long_data(12, $img_2);
if ($anexo_1) $stmt->send_long_data(13, $anexo_1);
if ($anexo_2) $stmt->send_long_data(14, $anexo_2);

if ($stmt->execute()) {
    unset($_SESSION['previa']);
    header('Location: tarefas.php?publicado=sucesso');
} else {
    echo "Erro: " . $stmt->error;
}
$stmt->close();
$conexao->close();
?>