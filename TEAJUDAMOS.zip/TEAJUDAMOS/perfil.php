<?php
session_start();
include 'conexao.php';

// 1. VERIFICA AUTENTICAÇÃO
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php?erro=naologado');
    exit;
}

$user_id = $_SESSION['user_id'];
$user_data = [];
$user_lessons = [];
$user_feedbacks = []; // Array para feedbacks do usuário

// Função para calcular o tempo relativo
function tempoDecorrido($datetime)
{
    if (!$datetime) return "data inválida";
    try {
        $agora = new DateTime();
        $dataPost = new DateTime($datetime);
        $diff = $agora->diff($dataPost);

        if ($diff->y > 0) return 'há ' . $diff->y . ' ano(s)';
        if ($diff->m > 0) return 'há ' . $diff->m . ' mes(es)';
        if ($diff->d > 0) {
            if ($diff->d == 1) return 'ontem';
            return 'há ' . $diff->d . ' dia(s)';
        }
        if ($diff->h > 0) return 'há ' . $diff->h . ' hora(s)';
        if ($diff->i > 0) return 'há ' . $diff->i . ' minuto(s)';
        return 'agora mesmo';
    } catch (Exception $e) {
        return "data inválida";
    }
}

// Nova função para determinar a classe de sentimento (baseada na nota de 1 a 5)
function getSentimentClass($rating) {
    if ($rating >= 4) {
        return ['class' => 'happy', 'icon' => 'fa-face-smile-beam'];
    } elseif ($rating == 3) {
        return ['class' => 'neutral', 'icon' => 'fa-face-meh'];
    } else {
        return ['class' => 'sad', 'icon' => 'fa-face-frown'];
    }
}

// 2. BUSCA OS DADOS DO USUÁRIO
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

$stmt_user = $conexao->prepare(
    "SELECT NOME, EMAIL, RG, CPF, RA, FOTO_PERFIL, INSTITUICAO_ENSINO, EMAIL_CONTATO, DATA_ATUALIZACAO 
     FROM USUARIOS WHERE ID = ?"
);

$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();

if ($result_user->num_rows > 0) {
    $user_data = $result_user->fetch_assoc();
} else {
    session_destroy();
    header('Location: login.php?erro=usuarioinvalido');
    exit;
}
$stmt_user->close();


// 3. BUSCA AS LIÇÕES PUBLICADAS PELO USUÁRIO
// 3. BUSCA AS LIÇÕES PUBLICADAS PELO USUÁRIO
$stmt_lessons = $conexao->prepare(
    "SELECT 
        l.ID, l.TITULO, l.MATERIA, l.DATA_PUBLICACAO, l.CAPA,
        (SELECT COUNT(*) FROM FEEDBACK f WHERE f.LICAO_ID = l.ID AND f.AVALIACAO >= 4) AS LIKES,
        (SELECT COUNT(*) FROM FEEDBACK f WHERE f.LICAO_ID = l.ID AND f.AVALIACAO <= 2) AS DISLIKES,
        (SELECT COUNT(*) FROM FEEDBACK f WHERE f.LICAO_ID = l.ID) AS TOTAL_RESPOSTAS
    FROM LICAO l
    WHERE l.PROFESSOR_ID = ?
    ORDER BY l.DATA_PUBLICACAO DESC"
);

$stmt_lessons->bind_param("i", $user_id);
$stmt_lessons->execute();
$result_lessons = $stmt_lessons->get_result();
while ($row = $result_lessons->fetch_assoc()) {
    $user_lessons[] = $row;
}
$stmt_lessons->close();


// 4. BUSCA OS FEEDBACKS PUBLICADOS PELO USUÁRIO (NO SITE)
// *SUGESTÃO DE TABELA: FEEDBACKS_SITE (usada no outro arquivo PHP).
// *ASSUMINDO COLUNAS: ID, TEXTO, AVALIACAO (nota de 1 a 5), DATA_PUBLICACAO e USUARIO_ID (o usuário que deu o feedback).
$stmt_feedback = $conexao->prepare(
    "SELECT 
        ID, TEXTO, AVALIACAO as AVALIACAO_NOTA, DATA_PUBLICACAO 
    FROM FEEDBACKS_SITE 
    WHERE USUARIO_ID = ? 
    ORDER BY DATA_PUBLICACAO DESC"
);

if ($stmt_feedback) {
    $stmt_feedback->bind_param("i", $user_id);
    $stmt_feedback->execute();
    $result_feedback = $stmt_feedback->get_result();

    while ($row = $result_feedback->fetch_assoc()) {
        $user_feedbacks[] = $row;
    }
    $stmt_feedback->close();
}


// 5. FECHA A CONEXÃO
$conexao->close();
?>


<!DOCTYPE html>
<html lang="pt-BR" class="h-full">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    <title>Perfil do Professor</title>
    <head>
    <style>
  /* --- GERAL --- */
* {
    box-sizing: border-box;
}

body,
html {
    margin: 0;
    padding: 0;
    min-height: 100%;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(#46004A, #8B0091);
    position: relative;
    color: #fff;
}

.container {
    min-height: 100vh;
    padding: 2rem 1rem;
    max-width: 1024px;
    margin: 0 auto;
    margin-top: 40px;
}

/* --- LOGO --- */
.header_logo {
    position: absolute;
    top: -95px;
    left: 20px;
    z-index: 10;
}

.logo img {
    width: 300px;
    height: auto;
    object-fit: cover;
    transition: transform 0.3s ease-in-out;
}

.logo img:hover {
    transform: scale(1.1);
}

/* --- HEADER --- */
.header {
    text-align: center;
    margin-bottom: 2rem;
}

.header h1 {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    color: #ffffffff;
    text-shadow: 0 0 20px rgba(255, 255, 255, 0.64);
}

.header p {
    color: #bf99e7ff;
    font-weight: 400;
}

/* --- PERFIL CARD --- */
.profile-card {
    background: rgba(35, 0, 50, 0.65);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #f3e8ff;
    backdrop-filter: blur(10px);
    border-radius: 1rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    padding: 2rem;
    display: grid;
    grid-template-columns: 1fr;
    gap: 2rem;
}

@media(min-width: 1024px) {
    .profile-card {
        grid-template-columns: 1fr 2fr;
    }
}

/* --- FOTO --- */
.photo-section {
    text-align: center;
}

.profile-photo-container {
    width: 12rem;
    height: 12rem;
    margin: 0 auto;
    border-radius: 9999px;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
    border: 4px solid #c4b5fd;
    position: relative;
    overflow: visible;
}

.profile-photo-container img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    border-radius: 9999px;
}

.photo-btn-container {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translate(-50%, 50%);
    display: flex;
    gap: 10px;
    z-index: 10;
}

.upload-btn {
    background-color: #6b21a8;
    color: white;
    width: 36px;
    height: 36px;
    border-radius: 9999px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.2);
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(4px);
}

.upload-btn:hover {
    background-color: #5b189e;
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

.upload-btn.remove {
    background-color: #dc2626;
}

.upload-btn.remove:hover {
    background-color: #b91c1c;
}

.photo-instruction {
    margin-top: 2rem;
    font-size: 0.875rem;
    color: rgba(255, 255, 255, 0.8);
}

/* --- CAMPOS DE INFO --- */
.info-section {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1.5rem;
}

@media(min-width: 768px) {
    .info-section {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
}

.full-span {
    grid-column: span 2;
}

@media(max-width: 767px) {
    .full-span {
        grid-column: auto;
    }
}

label {
    display: block;
    color: #a855f7;
    font-weight: 600;
    font-size: 0.875rem;
    margin-bottom: 0.5rem;
}

.field-container {
    display: flex;
    align-items: center;
    position: relative;
}

input[type="text"],
select[type="select"],
input[type="email"] {
    width: 100%;
    padding: 0.75rem 1rem;
    border-radius: 0.5rem;
    border: 1px solid #5b21a8;
    background-color: rgba(255, 255, 255, 0.9);
    color: #374151;
    font-size: 1rem;
    font-family: inherit;
    transition: box-shadow 0.3s ease, border-color 0.3s ease;
}

input[type="text"]:focus,
input[type="email"]:focus {
    border-color: transparent;
    box-shadow: 0 0 0 2px #8b5cf6;
    outline: none;
}

input[type="text"]:disabled,
input[type="email"]:disabled {
    background-color: rgba(220, 200, 240, 0.8);
    color: #3e0a6b;
    font-weight: 600;
    border-color: #d8b4fe;
    cursor: not-allowed;
    opacity: 1;
}

.field-value {
    padding: 0.75rem 1rem;
    border-radius: 0.5rem;
    background-color: rgba(255, 255, 255, 0.9);
    border: 1px solid #d8b4fe;
    color: #6b21a8;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.edit-icon {
    background: transparent;
    border: none;
    color: #8b5cf6;
    font-size: 1.25rem;
    cursor: pointer;
    transition: transform 0.3s ease-in-out;
    margin-left: 10px;
    position: absolute;
    right: 10px;
}

.edit-icon:hover {
    transform: scale(1.25);
    filter: brightness(1.1);
}

/* --- INSTITUIÇÕES --- */
.institutions-list {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 0.75rem;
}

.institution-tag {
    background: linear-gradient(45deg, #8b5cf6, #a855f7);
    color: white;
    border-radius: 9999px;
    padding: 0.375rem 1rem;
    font-size: 0.875rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
}

.institution-tag button {
    background: transparent;
    border: none;
    color: white;
    margin-left: 0.5rem;
    font-weight: 700;
    cursor: pointer;
    opacity: 0.7;
    transition: opacity 0.2s ease;
    font-size: 1rem;
}

.institution-tag button:hover {
    opacity: 1;
}

.add-institution-container {
    display: flex;
    gap: 0.5rem;
}

.add-btn {
    background-color: #6b21a8;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 0.5rem;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.add-btn:hover {
    background-color: #5b189e;
}

/* --- BOTÕES DE AÇÃO --- */
.actions {
    grid-column: 1 / -1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 2rem;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(255, 255, 255, 0.3);
    flex-wrap: wrap;
    gap: 1rem;
}

.actions-left {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    align-items: center;
}

.edit-btn,
.cancel-btn,
.add-lesson-btn,
.logout-btn {
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    font-weight: bold;
    font-size: 15px;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    text-align: center;
    display: inline-block;
}

.edit-btn {
    background: linear-gradient(45deg, #6366f1, #8b5cf6);
    color: white;
    box-shadow: 0 4px 6px rgba(139, 92, 246, 0.3);
}

.edit-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(139, 92, 246, 0.3);
}

.cancel-btn {
    background-color: #6b7280;
    color: white;
}

.cancel-btn:hover {
    background-color: #4b5563;
}

.add-lesson-btn {
    background: linear-gradient(45deg, #ff7a18, #ff5a8f);
    color: white;
}

.add-lesson-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(255, 90, 140, 0.18);
}

.actions-right{
    margin-left:130px;
}

.logout-btn {
    background: linear-gradient(45deg, #ef4444, #dc2626);
    color: white;
}

.logout-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(239, 68, 68, 0.3);
}

.deletar-conta {
    background: #ef4444;
    color: white;
    border-radius:10px;
    border: 2px solid transparent;
    padding: 12px;
    font-size:16px;
    cursor:pointer;
    transition: background .3s ease-in-out, color .4s ease-in-out, border 24s ease-in-out;
    font-weight: bold;
}

.deletar-conta i {
    font-size: 16px;
}

.deletar-conta:hover {
    background: white;
    color: red;

}



/* --- CARROSSEL LIÇÕES --- */
.lessons-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin: 2rem 0 1rem 0;
}

.lessons-title {
    font-size: 1.5rem;
    font-weight: 800;
    margin: 0;
    color: transparent;
    background: linear-gradient(90deg, #ffd86b, #ff7aa2, #c084fc, #7c3aed);
    background-size: 300% 100%;
    -webkit-background-clip: text;
    background-clip: text;
    animation: shimmer 4.5s linear infinite;
    margin-left: 20px;
}

@keyframes shimmer {
    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

.lessons-carousel {
    position: relative;
    margin-top: 12px;
}

.lessons-track {
    display: flex;
    gap: 20px;
    padding: 12px;
    overflow-x: auto;
    scroll-snap-type: x mandatory;
    -webkit-overflow-scrolling: touch;
}

.lessons-track::-webkit-scrollbar {
    height: 8px;
}

.lessons-track::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.06);
    border-radius: 999px;
}

.lesson-card {
    flex: 0 0 auto;
    scroll-snap-align: center;
    max-width: 420px;
    min-width: 320px;
    border: 1px solid rgba(255, 255, 255, 0.04);
    border-radius: 14px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transition: transform .18s cubic-bezier(.2, .9, .2, 1), box-shadow .18s ease;
    min-height: 300px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    background: rgba(35, 0, 50, 0.4);
}

.lesson-thumb {
    width: 100%;
    height: 250px;
    object-fit: cover;
    background: #2b0260;
    display: block;
}

.lesson-body {
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    color: #fff;
    flex-grow: 1;
}

.lesson-title {
    font-weight: 800;
    font-size: 18px;
    line-height: 1.15;
    color: #fff;
}

.lesson-meta {
    font-size: 14px;
    color: #d8b4fe;
}

.lesson-actions {
    margin-top: auto;
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: center;
    flex-wrap: wrap;
}

.left-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.vote-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.03);
    color: #fff;
    font-weight: 800;
    cursor: pointer;
    font-size: 14px;
    transition: transform .16s ease;
}

.vote-btn:hover {
    transform: translateY(-4px);
    background: linear-gradient(90deg, rgba(255, 255, 255, 0.06), rgba(255, 255, 255, 0.02));
}

.controls {
    display: flex;
    gap: 8px;
    align-items: center;
}

.edit-lesson-btn,
.delete-lesson-btn,
.lesson-open-btn {
    color: #fff;
    border: none;
    padding: 8px 12px;
    border-radius: 10px;
    font-weight: 800;
    font-size: 13px;
    cursor: pointer;
    transition: transform .16s ease, box-shadow .16s ease;
}

.edit-lesson-btn {
    background: linear-gradient(90deg, #22c55e, #16a34a);
}

.delete-lesson-btn {
    background: linear-gradient(90deg, #ef4444, #dc2626);
}

.lesson-open-btn {
    background: linear-gradient(90deg, #ff7a18, #ff5a8f);
}

.edit-lesson-btn:hover,
.delete-lesson-btn:hover,
.lesson-open-btn:hover {
    transform: translateY(-3px);
}

.carousel-controls {
    display: flex;
    gap: 8px;
    align-items: center;
}

.carousel-btn {
    background: rgba(255, 255, 255, 0.06);
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.08);
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 20px;
}
 
 
.feedback-carousel {
    margin: 0 auto;
    text-align: center;
    max-width: 85%;
    position: relative;
    top: 100px;
}

.feedback-carousel h2 {
    font-size: 2rem;
    font-weight: 800;
    margin: 0;
    letter-spacing: .3px;
    color: transparent;
    background: linear-gradient(90deg,#ffd86b,#ff7aa2,#c084fc,#7c3aed);
    background-size: 300% 100%;
    -webkit-background-clip: text;
    background-clip: text;
    animation: shimmer 4.5s linear infinite;
    text-align: center;
    position: relative;
    width: 100%;
    text-transform: uppercase; 
    letter-spacing: 1.5px; 
    margin-bottom: 20px; 
}

@keyframes shimmer {
    0%   { background-position: 0% 50%; }
    50%  { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}


.feedback-container {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.feedback-track {
    display: flex;
    transition: transform 0.6s ease;
    margin-left: 280px;  
}

.feedback-card {
    background: linear-gradient(135deg, #a770ef, #cf8bf3, #fdb99b);
    color: white;
    border-radius: 20px;
    margin: 0 5px;
    padding: 20px;
    width: 280px;
    flex-shrink: 0;
    text-align: left;
    box-shadow: 0 5px 15px rgba(0,0,0,0.15);
    animation: floatCard 4s ease-in-out infinite alternate;
    position: relative; 
}

.feedback-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.feedback-info h4 {
    margin: 0;
    font-size: 1.1em;
    color: #fff;
}

.feedback-info p {
    font-size: 0.9em;
    margin: 8px 0;
}

.feedback-card i {
    font-size: 1.6em;
    transition: color .3s ease-in-out;
    margin-top: 15px;
}

.feedback_icons {
    display: flex;
    justify-content: initial;
    align-items: center;
    gap: 20px;
}

.feedback-card.happy i {
    color: #22c55e; 
}
.feedback-card.happy i:hover {
    color: #15803d; 
}

/* Rosto TRISTE: Vermelho */
.feedback-card.sad i {
    color: #ef4444; 
}
.feedback-card.sad i:hover {
    color: #b91c1c;
}

.fa-trash-can {
    color: #dc2626 !important; 

}

.fa-trash-can:hover {
    color: darkred !important; 
}

.fa-pen-to-square {
    color: #4A8DE8 !important;
    transition: all .3s ease !important;
}

.fa-pen-to-square:hover{
    color: #185BB9 !important;
    transform: scale(1.2) !important;

}


/* --- BOTÕES DE AÇÃO DO FEEDBACK (NOVO) --- */
.feedback-controls {
    position: absolute;
    top: 15px;
    right: 15px;
    display: flex;
    gap: 8px;
    z-index: 5;
}

.feedback-delete-btn,
.feedback-edit-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
}

.feedback-delete-btn {
    background-color: transparent; 
    font-size: 1.2em;
}

.feedback-delete-btn:hover {
    color: #b91c1c; /* Vermelho mais escuro no hover */
    transform: scale(1.2); /* Efeito de hover para destaque */
}


.feedback-edit-btn:hover {
    color: #6d28d9; /* Roxo mais escuro no hover */
    transform: scale(1.2); /* Efeito de hover para destaque */
}

.feedback-prev, .feedback-next {
    background: rgba(216, 82, 221, 0.79);
    border: none;
    color: white;
    font-size: 1.5em;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    cursor: pointer;
    z-index: 10;
    transition: 0.5s;
}

.feedback-prev:hover, .feedback-next:hover {
    background: rgba(131, 41, 134, 0.82);
}

.feedback-prev {
    position: absolute;
    left: 10px;
}

.feedback-next {
    position: absolute;
    right: 10px;
}



@keyframes floatCard {
    from { transform: translateY(0px); }
    to { transform: translateY(-8px); }
}


/* --- FOOTER --- */
footer {
    width: 100%;
    background: linear-gradient(90deg, rgb(76, 0, 76), purple);
    color: white;
    padding: 50px 0 20px;
    margin-top: 150px;
    font-family: 'Poppins', sans-serif;
}

.footer-container {
    width: 90%;
    margin: auto;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.footer-logo img {
    position: absolute;
    margin-top: -100px;
    width: 400px;
    margin-left: -30px;
}

.footer-links,
.footer-contact {
    min-width: 200px;
}

.footer-links h3,
.footer-contact h3 {
    font-size: 18px;
    margin-bottom: 15px;
    color: #fff;
    position: relative;
}

.footer-links h3::after,
.footer-contact h3::after {
    content: "";
    position: absolute;
    width: 110px;
    height: 3px;
    background: #fff;
    left: 0;
    bottom: -4px;
    border-radius: 2px;
}

.footer-links ul,
.footer-contact ul {
    list-style: none;
    padding: 0;
}

.footer-links ul li,
.footer-contact ul li {
    margin: 10px 0;
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.footer-links ul li a {
    color: white;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-links ul li a:hover {
    color: #d63de4ff;
}

.footer-bottom {
    text-align: center;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
    margin-top: 50px;
    padding-top: 15px;
    font-size: 14px;
    color: #e0d6ff;
}

.footer-contact i,
.footer-links i {
    color: #e0b3ff;
}

/* --- MODAL --- */
.confirm-modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    align-items: center;
    justify-content: center;
}

.confirm-modal-content {
    background: white;
    padding: 25px;
    border-radius: 12px;
    text-align: center;
    color: #333;
    width: 90%;
    max-width: 400px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
}

.confirm-actions {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-top: 20px;
}

.btn-confirm-yes {
    background: #dc2626;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
}

.btn-confirm-no {
    background: #9ca3af;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
}

.hidden {
    display: none;
}

/* --- MEDIA QUERIES (RESPONSIVIDADE) --- */
@media (max-width: 768px) {
    .actions {
        flex-direction: column;
        align-items: stretch;
    }

    .actions-left {
        flex-direction: column;
        width: 100%;
    }

    .actions-right {
        width: 100%;
        margin-top: 1rem;
    }

    .edit-btn,
    .cancel-btn,
    .add-lesson-btn,
    .logout-btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }

    .lessons-track .lesson-card {
        min-width: 280px;
        max-width: 320px;
    }
}

@media (max-width: 480px) {
    .logo img {
        width: 260px;
        margin-top: 10px;
        margin-left: -30px;
    }

    .header h1 {
        font-size: 2.25rem;
        margin-top: 90px;
    }

    .container {
        padding: 1rem 0.5rem;
    }

    .profile-photo-container {
        width: 10rem;
        height: 10rem;
    }
    
    .logout-btn {
    width: 100%;
}

.actions-right{
    margin-left: 0;
}


.deletar-conta {
    width:100%;
}

.deletar-conta i {
    font-size: 16px;
}

            
    .feedback-carousel {
        top: -100px;
        max-width: 95%; 
    }

    .feedback-carousel h2 {
        padding-top: 170px;
        font-size: 2.2rem;
        margin-bottom: 30px; 
    }

    .feedback-track {
        margin-left: 0; 
        justify-content: flex-start; 
        width: 100%;
        padding-bottom: 20px; 
    }
    
    .feedback-container {
        overflow-x: scroll; 

        justify-content: flex-start;
        padding: 0 10px; 
    }

    .feedback-card {
        width: 100%; 
        max-width: 280px; 
        margin: 0 10px;
        scroll-snap-align: center; 
    }
    
  


    .footer-container {
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 30px;
    }

    .footer-logo img {
        display: none;
    }

    .footer-links h3::after,
    .footer-contact h3::after {
        left: 50%;
        transform: translateX(-50%);
    }

    .footer-links ul li,
    .footer-contact ul li {
        justify-content: center;
    }
}

</style>
</head>
<body>
    <div class="header_logo">
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </div>
    <div class="container">

        <header class="header">
            <h1>PERFIL DO PROFESSOR</h1>
            <p>Gerencie suas informações </p>
        </header>


        <section class="profile-card">

            <div class="photo-section">
                <div class="profile-photo-container" id="profilePhotoContainer">
                    
                    <?php 
    $cache_buster = $user_data['DATA_ATUALIZACAO'] ?? time(); 
?>

                    <?php if (!empty($user_data['FOTO_PERFIL'])): ?>
                        <img 
        id="profilePhoto" 
        src="get_imagem_usuario.php?id=<?php echo $user_id; ?>&t=<?php echo urlencode($cache_buster); ?>" 
        alt="Foto do Professor" 
    />
                    <?php else: ?>
                        <img id="profilePhoto" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%238b5cf6;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%23a855f7;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='200' height='200' fill='url(%23grad)'/%3E%3Ccircle cx='100' cy='80' r='35' fill='white' opacity='0.9'/%3E%3Cpath d='M100 130 Q70 130 50 160 Q50 180 100 180 Q150 180 150 160 Q130 130 100 130' fill='white' opacity='0.9'/%3E%3C/svg%3E" alt="Foto do Professor" />
                    <?php endif; ?>

                    <div class="photo-btn-container">
                        <button onclick="triggerFileUpload()" class="upload-btn" aria-label="Alterar foto do perfil" title="Alterar foto">
                            <i class="fa-solid fa-camera"></i>
                        </button>
                        <button onclick="removeProfilePhoto()" class="upload-btn remove" aria-label="Remover foto do perfil" title="Remover foto">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>


                    <input type="file" id="photoUpload" name="foto_perfil" accept="image/*" class="hidden" onchange="handlePhotoUpload(event)" />
                    <input type="hidden" id="removePhotoFlag" value="0">

                </div>
                <p class="photo-instruction">Clique nos ícones para alterar ou remover a foto</p>
            </div>


            <div class="info-section">

                <div class="full-span">
                    <label for="fullName">Nome Completo</label>
                    <div class="field-container">
                        <input type="text" id="fullName" name="nome" value="<?php echo htmlspecialchars($user_data['NOME']); ?>" autocomplete="off" disabled />
                        <button class="edit-icon" id="editNameBtn" onclick="toggleEdit('fullName', this)">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                    </div>
                </div>


                <div>
                    <label for="rg">RG</label>
                    <div class="field-container">
                        <input type="text" id="rg" value="<?php echo htmlspecialchars($user_data['RG']); ?>" autocomplete="off" disabled />
                    </div>
                </div>
                <div>
                    <label for="cpf">CPF</label>
                    <div class="field-container">
                        <input type="text" id="cpf" value="<?php echo htmlspecialchars($user_data['CPF']); ?>" autocomplete="off" disabled />
                    </div>
                </div>
                <div>
                    <label for="ra">RA</label>
                    <div class="field-container">
                        <input type="text" id="ra" value="<?php echo htmlspecialchars($user_data['RA']); ?>" autocomplete="off" disabled />
                    </div>
                </div>
                <div>
                    <label for="email">E-mail</label>
                    <div class="field-container">
                        <input type="email" id="email" value="<?php echo htmlspecialchars($user_data['EMAIL']); ?>" autocomplete="off" disabled />
                    </div>
                </div>


                <div class="full-span">
                    <label for="newInstitution">Instituições de Ensino</label>
                    <div>
                        <div id="institutionsList" class="institutions-list">
                            <?php
                            if (!empty($user_data['INSTITUICAO_ENSINO'])) {
                                $insts = explode(',', $user_data['INSTITUICAO_ENSINO']);
                                foreach ($insts as $inst) {
                                    $inst = trim($inst);
                                    if (!empty($inst)) {
                                        echo '<span class="institution-tag">' . htmlspecialchars($inst) . ' <button onclick="removeInstitution(this)">×</button></span>';
                                    }
                                }
                            }
                            ?>
                        </div>
                        <div class="add-institution-container">
                            <input list="institutionsDatalist" id="newInstitution" placeholder="Adicione sua instituição" autocomplete="off" type="text" />
                            <datalist id="institutionsDatalist">
                                
                                <option value="ETEC POLIVALENTE DE AMERICANA"></option>
                                <option value="HEITOR PENTEADO"></option>
                                <option value="ARY MENEGATTO"></option>
                                <option value="INSTITUTO EDUCACIONAL DE AMERICANA (IEA)"></option>
                                <option value="DOM BOSCO"></option>
                                <option value="WILSON CAMARGO"></option>
                                <option value="COLÉGIO PILARES"></option>
                                <option value="COLÉGIO NOVO TEMPO"></option>
                                <option value="COLÉGIO PROPEI"></option>
                                <option value="COLÉGIO POLITEC"></option>
                                <option value="ESCOLA TÉCNICA ASTOR"></option>
                                <option value="COLÉGIO ANGLO AMERICANO"></option>
                                <option value="COLÉGIO ADVENTISTA DE AMERICANA"></option>
                                <option value="EE PROFESSOR MAURÍCIO NOEL"></option>
                                <option value="EE PROFESSOR SILAS PAULA SOUZA"></option>
                                <option value="EE PROFESSOR ODLON DE MORAES"></option>
                                <option value="EE PROFESSOR SINÉSIO DE FREITAS"></option>
                                <option value="EE PROFESSORA CLARICE COSTA CONDE"></option>
                                <option value="EE PROFESSOR JOAQUIM NASCIMENTO"></option>
                                <option value="EE DOROTHY DE OLIVEIRA GALEGO"></option>
                                <option value="EE CORONEL SALLES"></option>
                                <option value="EE ALCINDA DE ALCÂNTARA"></option>
                                <option value="EE MONSENHOR MAGALHÃES"></option>
                                <option value="EE GERALDO DE OLIVEIRA"></option>
                                <option value="EE ELVIRA RAMOS DE OLIVEIRA"></option>
                                <option value="EE RUTH EXEL"></option>
                                <option value="EE PROFESSORA FÁTIMA NAZARÉ"></option>
                                <option value="EE DR. JOÃO DE CASTRO COELHO"></option>
                                <option value="EE PROFESSORA ANNA LÚCIA DE OLIVEIRA"></option>
                                <option value="EE PROFESSORA DINAH R. DE SOUZA"></option>
                                <option value="EE DEPUTADO ROBERTO CHIESA"></option>
                                <option value="E M JURACY MARIN"></option>
                                <option value="E M DARCI APARECIDA P. H. CARNEIRO"></option>
                                <option value="E M PAULO FREIRE"></option>
                                <option value="E M ETELVINA P. DE LIMA"></option>
                                <option value="E M CIDADE JARDIM"></option>
                                <option value="E M VILMA APARECIDA DA SILVA"></option>
                                <option value="E M FAZENDA GRANDE"></option>
                                <option value="E M CLÉLIA T. REBOUÇAS"></option>
                                <option value="E M FLORA P. DE MORAES"></option>
                                <option value="E M MARIA MARCHESIN"></option>
                                <option value="E M ANNA R. DE SOUZA"></option>
                                <option value="E M PINGO DE GENTE"></option>
                                <option value="E M ZORAIDE ARTEZANATTO"></option>
                                <option value="E M CAIC"></option>
                                <option value="E M JARDIM DA PAZ"></option>
                                <option value="E M JOSÉ FINAMOR"></option>
                                <option value="E M CÍCERO CARRARA"></option>
                                <option value="E M PROFESSORA MARIA M. DA SILVA"></option>
                                <option value="E M PROFESSORA LUIZA G. ALMEIDA"></option>
                                <option value="COLÉGIO PENTAGONO AMERICANA"></option>
                            
                                ---
                            
                                <option value="ESCOLA TÉCNICA REZENDE"></option>
                                <option value="COLÉGIO BILAC"></option>
                                <option value="COLÉGIO GUARANI"></option>
                                <option value="ESCOLA TÉCNICA FLÁVIO DE CARVALHO (ETEC)"></option>
                                <option value="COLÉGIO ADVENTISTA DE SANTA BÁRBARA"></option>
                                <option value="COLÉGIO DOM BOSCO SBO"></option>
                                <option value="COLÉGIO SANTA BÁRBARA"></option>
                                <option value="EE PROFESSORA LUZIA LAZARINI"></option>
                                <option value="EE COMENDADOR ISRAEL DE ALMEIDA"></option>
                                <option value="EE PROFESSORA MARIA DE LOURDES"></option>
                                <option value="EE PROFESSORA DILETA CORTEZ"></option>
                                <option value="EE PROFESSOR INÁCIO DE ALMEIDA"></option>
                                <option value="EE JOSÉ DE ALMEIDA"></option>
                                <option value="EE ADÉLIA FERREIRA"></option>
                                <option value="EE JOSÉ BRUNO"></option>
                                <option value="EE PROFESSORA CLARICE L. DIAS"></option>
                                <option value="EE PROFESSOR ULISSES DE OLIVEIRA"></option>
                                <option value="EE PROFESSORA ELIETE DE SOUZA"></option>
                                <option value="EE PROFESSOR ANTÔNIO DE PÁDUA"></option>
                                <option value="EE PROFESSOR MARIO GRACIETTO"></option>
                                <option value="EE PROFESSORA RUTH P. M. SOUZA"></option>
                                <option value="EE PROFESSORA MARIA JOSÉ MARTHA"></option>
                                <option value="EE PROFESSOR WALTER DE ALMEIDA"></option>
                                <option value="EE PROFESSOR ANTÔNIO P. D. MELLO"></option>
                                <option value="EE PROFESSORA MARISA DE SOUZA"></option>
                                <option value="EE PROFESSOR CÍCERO SALLES"></option>
                                <option value="EE PROFA. DIRCE C. G. REZAGHI"></option>
                                <option value="EE PROFESSOR EZEQUIEL D. H."></option>
                                <option value="EE MONSENHOR HINGRID"></option>
                                <option value="E M CORONEL LUIZ ALVES"></option>
                                <option value="E M PROFESSOR ANTÔNIO B."></option>
                                <option value="E M PROFESSORA TEREZINHA S. PEREIRA"></option>
                                <option value="E M VEREADOR VILALVA"></option>
                                <option value="E M PROFESSORA IGNEZ L. C."></option>
                                <option value="E M PROFESSORA ETELVINA"></option>
                                <option value="E M HELOÍSA HELENA"></option>
                                <option value="E M PROFESSORA VILMA C. S."></option>
                                <option value="E M PROFESSORA ELENIR"></option>
                                <option value="E M PROFESSORA ELIANA A. J. L."></option>
                                <option value="E M PROFESSORA GERALDA L. G."></option>
                                <option value="E M PROFESSOR JOSÉ R. G."></option>
                                <option value="E M PROFESSORA CLEO B. G."></option>
                                <option value="E M PROFESSORA IVANILDE C. P."></option>
                                <option value="E M CAIC ARMANDO S."></option>
                                <option value="E M PROFESSORA LUZIA L. F."></option>
                                <option value="E M PROFESSORA LAURA C. F."></option>
                                <option value="E M PROFESSORA TÂNIA G."></option>
                                <option value="E M PROFESSORA IRACEMA"></option>
                                <option value="E M PROFESSORA ADÉLIA L. C."></option>
                                <option value="E M PROFESSORA VIVIANE B."></option>
                                <option value="E M PADRE CORNELIS"></option>
                            
                                ---
                            
                                <option value="ESCOLA OBJETIVO NOVA ODESSA"></option>
                                <option value="COLÉGIO PALLAZZO"></option>
                                <option value="COLÉGIO ADVENTISTA DE NOVA ODESSA"></option>
                                <option value="EE SILVANO ALMEIDA"></option>
                                <option value="EE PROFESSORA JOSEFINA DE ALMEIDA"></option>
                                <option value="EE DOUTOR JOÃO THIENGO"></option>
                                <option value="EE PROFESSOR JOÃO BATISTA DE ALMEIDA"></option>
                                <option value="EE PROFESSOR REGINALDO"></option>
                                <option value="EE PROFESSORA MARILENE M. P."></option>
                                <option value="EE PROFESSOR TOLEDO"></option>
                                <option value="EE PROFESSORA ALZIRA N. M."></option>
                                <option value="EE PROFESSOR SIMÃO"></option>
                                <option value="EE PROFESSOR LUIZ S. B."></option>
                                <option value="EE PROFESSORA MAFALDA"></option>
                                <option value="EE PROFESSOR ALCIDES"></option>
                                <option value="EE PROFESSORA LAURA"></option>
                                <option value="EE PROFESSORA ELZA B. M."></option>
                                <option value="EE PROFESSORA DINÁ B. F."></option>
                                <option value="EE PROFESSORA IVETE R. A."></option>
                                <option value="EE PROFESSORA NEUSA M. S."></option>
                                <option value="EE PROFESSORA ANA C. C."></option>
                                <option value="EE PROFESSORA VERA L."></option>
                                <option value="EE PROFESSORA JUSSARA"></option>
                                <option value="EE PROFESSOR ANTÔNIO G."></option>
                                <option value="EE PROFESSOR CARLOS S."></option>
                                <option value="EE PROFESSOR JOSÉ D."></option>
                                <option value="EE PROFESSOR LÁZARO"></option>
                                <option value="EE PROFESSOR MARCOS S."></option>
                                <option value="EE PROFESSORA AMÉLIA"></option>
                                <option value="EE PROFESSORA APARECIDA"></option>
                                <option value="EE PROFESSOR SÉRGIO"></option>
                                <option value="EE PROFESSOR VANDERLEI"></option>
                                <option value="EE PROFESSORA ZENAIDE"></option>
                                <option value="EE PROFESSOR MARIO S."></option>
                                <option value="E M VEREADOR ONDINA"></option>
                                <option value="E M PREFEITO SIMÃO"></option>
                                <option value="E M PROFESSORA DORA"></option>
                                <option value="E M PROFESSORA JACY"></option>
                                <option value="E M PROFESSORA CLOTILDE"></option>
                                <option value="E M PROFESSORA SALVINA"></option>
                                <option value="E M PROFESSOR HERCÍLIO"></option>
                                <option value="E M PROFESSOR WALTER"></option>
                                <option value="E M VEREADOR ARMANDO"></option>
                                <option value="E M PROFESSOR JOSÉ R."></option>
                                <option value="E M PROFESSOR JOSÉ M."></option>
                                <option value="E M PROFESSORA JÚLIA"></option>
                                <option value="E M PROFESSORA ALICE"></option>
                                <option value="E M PROFESSORA ELZA"></option>
                                <option value="E M PROFESSORA NEIDE"></option>
                                <option value="E M PROFESSORA NAIR"></option>
                                <option value="E M PROFESSORA ODILA"></option>
                            
                                ---
                            
                                <option value="COLÉGIO COTUCAI"></option>
                                <option value="COLÉGIO VISÃO"></option>
                                <option value="COLÉGIO ALFA SUMARÉ"></option>
                                <option value="ETEC ESTEVAM ARMELIN (SUMARÉ)"></option>
                                <option value="COLÉGIO OBJETIVO SUMARÉ"></option>
                                <option value="COLÉGIO ADVENTISTA DE SUMARÉ"></option>
                                <option value="EE PROFESSORA LUÍZA DE OLIVEIRA"></option>
                                <option value="EE DEPUTADO ULISSES GUIMARÃES"></option>
                                <option value="EE PROFESSOR JOÃO DE FREITAS"></option>
                                <option value="EE PROFESSOR JOSÉ C. S. DE A."></option>
                                <option value="EE PROFESSOR ALCIDES F. DE SOUZA"></option>
                                <option value="EE PROFESSOR VILSON JOSÉ ALVES"></option>
                                <option value="EE PROFESSOR HERMÍNIO SACCHETTA"></option>
                                <option value="EE PROFESSORA VILMA A. ALVES"></option>
                                <option value="EE PROFESSOR CLAUDIO DE GODOY"></option>
                                <option value="EE PROFESSOR MARCELINO"></option>
                                <option value="EE PROFESSORA TEREZINHA O."></option>
                                <option value="EE PROFESSOR ANTÔNIO M."></option>
                                <option value="EE PROFESSOR MARIO P."></option>
                                <option value="EE PROFESSORA APARECIDA C."></option>
                                <option value="EE PROFESSORA ELZA C."></option>
                                <option value="EE PROFESSORA LAURA C."></option>
                                <option value="EE PROFESSOR ALCINO G."></option>
                                <option value="EE PROFESSOR ALMEIDA P."></option>
                                <option value="EE PROFESSOR ARNALDO"></option>
                                <option value="EE PROFESSOR JÚLIO C."></option>
                                <option value="EE PROFESSOR JOSÉ L."></option>
                                <option value="EE PROFESSOR LUIZ C."></option>
                                <option value="EE PROFESSOR PEDRO R."></option>
                                <option value="EE PROFESSOR ZELINDO"></option>
                                <option value="EE PROFESSORA ANA B."></option>
                                <option value="EE PROFESSORA BENEDITA"></option>
                                <option value="EE PROFESSORA CLARICE"></option>
                                <option value="EE PROFESSORA ELIANA"></option>
                                <option value="EE PROFESSORA IRENE"></option>
                                <option value="E M ANÉSIA C. DE ALMEIDA"></option>
                                <option value="E M REGINA H. L. DE ANDRADE"></option>
                                <option value="E M ALBERTO DE OLIVEIRA"></option>
                                <option value="E M VEREADOR JOSÉ B. C."></option>
                                <option value="E M NESTOR DE S. CAMARGO"></option>
                                <option value="E M RUTH PROENÇA"></option>
                                <option value="E M JOÃO DE FREITAS"></option>
                                <option value="E M ELIETE J. D."></option>
                                <option value="E M LUCIANA M."></option>
                                <option value="E M MARIA M. S."></option>
                                <option value="E M PÉROLA"></option>
                                <option value="E M PROFESSORA IVANILDE"></option>
                                <option value="E M PROFESSORA MARIA M."></option>
                                <option value="E M PROFESSORA VILMA"></option>
                                <option value="E M PROFESSORA ELIANA G."></option>
                                <option value="E M PROFESSORA MARIA L."></option>
                            
                                ---
                            
                                <option value="COTIL (COLÉGIO TÉCNICO DE LIMEIRA)"></option>
                                <option value="COLÉGIO TÉCNICO DE CAMPINAS (COTUCA)"></option>
                                <option value="COLÉGIO ETAPA CAMPINAS"></option>
                                <option value="COLÉGIO INTEGRAL"></option>
                                <option value="COLÉGIO VISCONDE DE PORTO SEGURO CAMPINAS"></option>
                                <option value="COLÉGIO OBJETIVO CAMPINAS"></option>
                                <option value="COLÉGIO RENOVAÇÃO"></option>
                                <option value="ESCOLA ALEF"></option>
                                <option value="COLÉGIO DANTE ALIGHIERI CAMPINAS"></option>
                                <option value="COLÉGIO VILLA-LOBOS"></option>
                                <option value="COLÉGIO DE SÃO JOSÉ"></option>
                                <option value="COLÉGIO MADRE TEODORA"></option>
                                <option value="COLÉGIO NOTREDAME"></option>
                                <option value="COLÉGIO BENEDITINO"></option>
                                <option value="COLÉGIO SAGRADO CORAÇÃO DE JESUS"></option>
                                <option value="COLÉGIO PROJETO VIDA"></option>
                                <option value="COLÉGIO LYCEU"></option>
                                <option value="ETEC MONSENHOR ANTÔNIO DE GODOY (CAMPINAS)"></option>
                                <option value="ETEC PROFESSOR GERALDO JOSE"></option>
                                <option value="EE CULINÁRIA DE CAMPINAS"></option>
                                <option value="EE PROFESSOR OROSIMBO MAIA"></option>
                                <option value="EE ADALGISA DE CAMPOS"></option>
                                <option value="EE PROFESSORA ELVIRA"></option>
                                <option value="EE PROFESSOR CARLOS S."></option>
                                <option value="EE PROFESSORA BENEDITA"></option>
                                <option value="EE PROFESSOR NEWTON"></option>
                                <option value="EE PROFESSORA LÍDIA"></option>
                                <option value="EE PROFESSORA ZENAIDE"></option>
                                <option value="EE PROFESSOR EDMUNDO"></option>
                                <option value="EE PROFESSOR JOÃO P."></option>
                                <option value="EE PROFESSORA LUIZA G."></option>
                                <option value="EE PROFESSOR JOÃO B. S."></option>
                                <option value="EE PROFESSOR RUI RODRIGUES"></option>
                                <option value="EE PROFESSORA HORTÊNCIA"></option>
                                <option value="EE PROFESSOR ORIVALDO"></option>
                                <option value="EE PROFESSORA JANDIRA"></option>
                                <option value="EE PROFESSORA ALCINA"></option>
                                <option value="EE PROFESSOR ELZO"></option>
                                <option value="EE PROFESSOR GABRIEL"></option>
                                <option value="EE PROFESSOR GASPAR"></option>
                                <option value="EE PROFESSOR JOSÉ V."></option>
                                <option value="EE PROFESSOR JOSÉ F."></option>
                                <option value="E M CORA CORALINA"></option>
                                <option value="E M VEREADOR JOSÉ"></option>
                                <option value="E M PROFESSORA ZILDA"></option>
                                <option value="E M PROFESSOR JOSÉ L. F."></option>
                                <option value="E M PROFESSORA SYLVIA"></option>
                                <option value="E M PROFESSORA VERA"></option>
                                <option value="E M PROFESSOR CARLOS L."></option>
                                <option value="E M PROFESSORA EULALIA"></option>
                            </datalist>
                            <button onclick="addInstitution()" class="add-btn">Adicionar</button>
                        </div>
                    </div>
                </div>
            </div>


            <div class="actions">
                <div class="actions-left">
                    <button onclick="saveProfileAJAX(this)" class="edit-btn">Salvar Alterações</button>
                    <button onclick="cancelEdit()" class="cancel-btn">Cancelar</button>
                    <a href="adicionar_licao.php"> <button class="add-lesson-btn">Adicionar Lição </button> </a>
                </div>
                <div class="actions-right">
                    <a href="logout.php" class="logout-btn">Deslogar</a>
                </div>
                
                <button class="deletar-conta" onclick="openDeleteAccountModal()"><i class="fa-solid fa-trash"></i> Deletar Conta</button>
                
            </div>
        </section>
    </div>

    <div class="lessons-header" aria-hidden="false">
        <h2 class="lessons-title">Minhas Lições Publicadas</h2>
        <div class="carousel-controls" aria-hidden="false">
            <button id="prevBtn" class="carousel-btn" aria-label="Anterior">‹</button>
            <button id="nextBtn" class="carousel-btn" aria-label="Próximo">›</button>
        </div>
    </div>

    <div class="lessons-carousel" aria-label="Carrossel de lições">
        <div class="lessons-track" id="lessonsTrack">

            <?php if (empty($user_lessons)): ?>
                <p style="color: white; font-size: 1rem; padding: 20px; text-align: center; width: 100%;">
                    Você ainda não publicou nenhuma lição.
                </p>
            <?php else: ?>
                <?php foreach ($user_lessons as $lesson): ?>
                    <article class="lesson-card" tabindex="0" data-lesson-id="<?php echo $lesson['ID']; ?>">
<?php if (!empty($lesson['CAPA'])): ?>
            <img class="lesson-thumb" src="get_imagem_licao.php?id=<?php echo $lesson['ID']; ?>&tipo=capa" alt="<?php echo htmlspecialchars($lesson['TITULO']); ?>">
        <?php else: ?>
            <img class="lesson-thumb logo-fallback" style="background-color:white;" src="imagens/logo-teajudamos.png" alt="Logo padrão - Sem capa">
        <?php endif; ?>
                        <div class="lesson-body">
                            <?php
                            $materia_formatada = htmlspecialchars($lesson['MATERIA']);
                            if ($materia_formatada === 'portugues') {
                                $materia_formatada = 'Português';
                            } elseif ($materia_formatada === 'matematica') {
                                $materia_formatada = 'Matemática';
                            } else {
                                $materia_formatada = ucfirst($materia_formatada);
                            }
                            ?>
                            <div class="lesson-title"><?php echo $materia_formatada; ?> — <?php echo htmlspecialchars($lesson['TITULO']); ?></div>
                            <div class="lesson-meta">
                                Publicado <?php echo tempoDecorrido($lesson['DATA_PUBLICACAO']); ?> · <?php echo $lesson['TOTAL_RESPOSTAS']; ?> respostas
                            </div>

                            <div class="lesson-actions">
                                <div class="left-actions">
                                    <button class="vote-btn">
                                        <i class="fa-solid fa-thumbs-up" style="color: #23f570ff;"></i>
                                        <span class="vote-count"><?php echo $lesson['LIKES']; ?></span>
                                    </button>

                                    <button class="vote-btn">
                                        <i class="fa-solid fa-thumbs-down" style="color: #ff2626ff;"></i>
                                        <span class="vote-count"><?php echo $lesson['DISLIKES']; ?></span>
                                    </button>
                                </div>

                                <div class="controls">
                                    <a href="editar_licao.php?id=<?php echo $lesson['ID']; ?>"> <button class="edit-lesson-btn">Editar</button> </a>
                                    <button class="delete-lesson-btn" onclick="openDeleteModal(<?php echo $lesson['ID']; ?>, this)">Excluir</button>
                                    <a href="licao.php?id=<?php echo $lesson['ID']; ?>"> <button class="lesson-open-btn">Abrir</button> </a>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>


    <section class="feedback-carousel">
        <h2>Meus Feedbacks <i class="fa-solid fa-comments"></i></h2>

        <div class="feedback-container">
            <?php if (count($user_feedbacks) > 1): ?>
                <button class="feedback-prev"><i class="fa-solid fa-chevron-left"></i></button>
            <?php endif; ?>

            <div style="flex-grow: 1; overflow: hidden; padding: 0 10px;"> 
                <div class="feedback-track" id="feedbackTrack">
                    
                    <?php if (empty($user_feedbacks)): ?>
                        <div class="feedback-card empty-message" style="width: 100%; text-align: center; padding: 20px;">
                            <p style="color: #6366f1; margin: 0;">Você ainda não publicou nenhum feedback sobre o site.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($user_feedbacks as $feedback): 
                            $sentiment = getSentimentClass((int)$feedback['AVALIACAO_NOTA']);
                            $feedback_text = htmlspecialchars($feedback['TEXTO']);
                            $data_pub = tempoDecorrido($feedback['DATA_PUBLICACAO']);
                        ?>
                            <div class="feedback-card <?php echo $sentiment['class']; ?>">
                                
                                <div class="profile-photo-container small-photo" style="display: flex; justify-content: center; align-items: center;">
                                    <?php if (!empty($user_data['FOTO_PERFIL'])): ?>
                                        <img src="get_imagem_usuario.php?id=<?php echo $user_id; ?>&t=<?php echo urlencode($cache_buster); ?>" alt="Sua foto de perfil">
                                    <?php else: ?>
                                        <i class="fa-solid fa-user-circle" style="font-size: 50px; color: #ccc;"></i>
                                    <?php endif; ?>
                                </div>

                                <div class="feedback-info">
                                    <h4>
                                        Você 
                                        <span style="font-size: 0.8em; font-weight: normal; color: #777;">
                                            (<?php echo $data_pub; ?>)
                                        </span>
                                    </h4>
                                    
                                    <p>"<?php echo $feedback_text; ?>"</p>
                                    
                                    <?php
                $card_class = 'neutral';
                $icon_class = 'fa-solid fa-face-meh';

                if ($feedback['AVALIACAO_NOTA'] == 5) {
                  $card_class = 'happy';
                  $icon_class = 'fa-solid fa-face-smile-beam';
                } elseif ($feedback['AVALIACAO_NOTA'] == 1) {
                  $card_class = 'sad';
                  $icon_class = 'fa-solid fa-face-frown';
                }
                ?>
                                    
                                    <div class=feedback_icons>
                                
                                    <a href="excluir_feedback.php?id=<?php echo $feedback['ID']; ?>" 
                                        class="feedback-delete-btn"
                                        onclick="return confirm('Tem certeza que deseja excluir seu feedback? Esta ação é irreversível.');"
                                        title="Excluir Feedback">
                                        <i class="fa-solid fa-trash-can" ></i>
                                    </a>
                                    
                                    <a href="editar_feedback.php?id=<?php echo $feedback['ID']; ?>" title="Editar Feedback"><i class="fa-solid fa-pen-to-square"></i> </a>                                    
                                    <i class="<?php echo $icon_class; ?>"></i>
                                </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (count($user_feedbacks) > 1): ?>
                <button class="feedback-next"><i class="fa-solid fa-chevron-right"></i></button>
            <?php endif; ?>
        </div>
    </section>

</div>


    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS">
            </div>

            <?php 
// 1. Verifica se a sessão está iniciada e se o usuário é administrador
// É crucial garantir que session_start(); foi chamado no topo da sua página.
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
          <h3>Navegação</h3>
          <ul>

        <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
        <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
        <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
        <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
        
        <?php 
        // 3. Bloco Condicional para Administrador
        if ($is_admin) {
            // Este link só será renderizado se o papel for 'admin'
            // Utilize o ícone 'fa-user-cog' para o ícone de administrador
            echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
        }
        ?>

        <!-- 4. Link de Entrar/Sair Dinâmico -->
        <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

            
          </ul>
        </div>

            <div class="footer-contact">
                <h3>Contato</h3>
                <ul>
                    <li><i class="fa-solid fa-envelope"></i> suporteteajudamos@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
        </div>
    </footer>

    <div id="deleteModal" class="confirm-modal">
        <div class="confirm-modal-content">
            <h3><i class="fa-solid fa-triangle-exclamation" style="color: #dc2626;"></i> Excluir Lição</h3>
            <p>Tem certeza que deseja excluir esta lição permanentemente? <br> Essa ação não pode ser desfeita.</p>
            <div class="confirm-actions">
                <button class="btn-confirm-yes" onclick="confirmDelete()">Sim, Excluir</button>
                <button class="btn-confirm-no" onclick="closeDeleteModal()">Cancelar</button>
            </div>
        </div>
    </div>
    
    
    <div id="deleteAccountModal" class="confirm-modal">
        <div class="confirm-modal-content" style="border: 3px solid #dc2626;">
            <h3><i class="fa-solid fa-triangle-exclamation" style="color: #dc2626;"></i> Excluir Conta</h3>
            <p style="color: #dc2626; font-weight: bold; font-size: 1.1em;">
                Você tem certeza que deseja excluir sua conta permanentemente?
                <br>
                <span style="font-size: 0.9em; font-weight: normal;">Essa ação é <b>IRREVERSÍVEL</b> e todos os seus dados e lições serão perdidos.</span>
            </p>
            <div class="confirm-actions">
                <button class="btn-confirm-yes" onclick="confirmDeleteAccount()">Sim, Excluir Minha Conta</button>
                <button class="btn-confirm-no" onclick="closeDeleteAccountModal()">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        // Lógica de Foto
        function triggerFileUpload() {
            document.getElementById('photoUpload').click();
        }

        function handlePhotoUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profilePhoto').src = e.target.result;
                    document.getElementById('removePhotoFlag').value = '0';
                };
                reader.readAsDataURL(file);
            }
        }

        function removeProfilePhoto() {
            if (!confirm("Tem certeza que deseja remover sua foto de perfil?")) {
                return;
            }
            document.getElementById('removePhotoFlag').value = '1';
            document.getElementById('photoUpload').value = '';
            const placeholder = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%238b5cf6;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%23a855f7;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='200' height='200' fill='url(%23grad)'/%3E%3Ccircle cx='100' cy='80' r='35' fill='white' opacity='0.9'/%3E%3Cpath d='M100 130 Q70 130 50 160 Q50 180 100 180 Q150 180 150 160 Q130 130 100 130' fill='white' opacity='0.9'/%3E%3C/svg%3E";
            document.getElementById('profilePhoto').src = placeholder;
        }

        // Lógica do Modal de Exclusão
        let pendingDeleteId = null;
        let pendingDeleteBtn = null;

        function openDeleteModal(id, btn) {
            pendingDeleteId = id;
            pendingDeleteBtn = btn;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
            pendingDeleteId = null;
            pendingDeleteBtn = null;
        }

        async function confirmDelete() {
            if (!pendingDeleteId) return;

            const formData = new FormData();
            formData.append('licao_id', pendingDeleteId);

            try {
                const response = await fetch('deletar_licao.php', {
                    method: 'POST',
                    body: formData
                });
                const text = await response.text();
                let result;
                try {
                    result = JSON.parse(text);
                } catch (e) {
                    console.error("Resposta não é JSON:", text);
                    alert("Erro no servidor. Verifique o console.");
                    closeDeleteModal();
                    return;
                }

                if (result.status === 'success') {
                    if (pendingDeleteBtn) {
                        const card = pendingDeleteBtn.closest('.lesson-card');
                        card.remove();
                    }
                    const track = document.getElementById('lessonsTrack');
                    // Verifica se a lista de lições ficou vazia após a exclusão
                    if (track && track.querySelectorAll('.lesson-card').length === 0) {
                        track.innerHTML = '<p style="color: white; font-size: 1rem; padding: 20px; text-align: center; width: 100%;">Você ainda não publicou nenhuma lição.</p>';
                    }
                } else {
                    alert('Erro ao excluir: ' + result.message);
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro de conexão ao tentar excluir.');
            }
            closeDeleteModal();
        }
        
        function openDeleteAccountModal() {
            document.getElementById('deleteAccountModal').style.display = 'flex';
        }

        function closeDeleteAccountModal() {
            document.getElementById('deleteAccountModal').style.display = 'none';
        }

        function confirmDeleteAccount() {
            // Ação: Redirecionar para o script PHP que irá deletar a conta
            // OBS: Você deve criar o arquivo 'deletar_conta.php' para processar a exclusão no banco de dados
            window.location.href = 'deletar_conta.php'; 
        }

        // Salvar Perfil
        async function saveProfileAJAX(button) {
            const originalText = button.textContent;
            button.textContent = 'Salvando...';
            button.disabled = true;

            const fileInput = document.getElementById('photoUpload');
            const nameInput = document.getElementById('fullName');
            const institutionsList = document.getElementById('institutionsList');
            const tags = institutionsList.querySelectorAll('.institution-tag');
            let institutionNames = [];
            tags.forEach(tag => {
                institutionNames.push(tag.textContent.replace('×', '').trim());
            });

            const formData = new FormData();
            formData.append('nome', nameInput.value);
            formData.append('instituicao', institutionNames.join(', '));
            const removeFlag = document.getElementById('removePhotoFlag').value;
            formData.append('remove_foto', removeFlag);

            if (fileInput.files[0] && removeFlag === '0') {
                formData.append('foto_perfil', fileInput.files[0]);
            }

            try {
                const response = await fetch('atualizar_perfil.php', {
                    method: 'POST',
                    body: formData
                });
                if (!response.ok) throw new Error(`Erro: ${response.status}`);
                const result = await response.json();

                if (result.status === 'success') {
                    button.textContent = 'Salvo!';
                    button.style.background = 'linear-gradient(45deg, #10b981, #059669)';
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    alert('Erro ao salvar: ' + result.message);
                    button.textContent = originalText;
                    button.style.background = 'linear-gradient(45deg, #6366f1, #8b5cf6)';
                    button.disabled = false;
                }
            } catch (error) {
                console.error(error);
                alert('Erro de conexão.');
                button.textContent = originalText;
                button.style.background = 'linear-gradient(45deg, #6366f1, #8b5cf6)';
                button.disabled = false;
            }
        }

        function cancelEdit() {
            if (confirm('Deseja realmente cancelar as alterações?')) {
                location.reload();
            }
        }

        // Formatação de inputs
        document.getElementById('cpf').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = value;
        });

        document.getElementById('rg').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{2})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1})$/, '$1-$2');
            e.target.value = value;
        });

        function toggleEdit(fieldId, button) {
            const field = document.getElementById(fieldId);
            const isDisabled = field.disabled;
            field.disabled = !isDisabled;
            const icon = button.querySelector('i');
            if (isDisabled) {
                icon.classList.remove('fa-pen');
                icon.classList.add('fa-check');
                icon.style.color = '#10b981';
                field.focus();
            } else {
                icon.classList.remove('fa-check');
                icon.classList.add('fa-pen');
                icon.style.color = '#8b5cf6';
            }
        }

        // Instituições
        function removeInstitution(button) {
            button.parentElement.remove();
        }

        function addInstitution() {
            const input = document.getElementById('newInstitution');
            const name = input.value.trim();
            if (!name) return;

            const datalist = document.getElementById('institutionsDatalist');
            const allowed = Array.from(datalist.options).map(o => o.value.toLowerCase());

            if (!allowed.includes(name.toLowerCase())) {
                input.style.borderColor = '#ff4d6d';
                setTimeout(() => input.style.borderColor = '', 1000);
                return;
            }

            const institutionsList = document.getElementById('institutionsList');
            const existingTags = Array.from(institutionsList.querySelectorAll('.institution-tag'))
                .map(t => t.textContent.replace('×', '').trim().toLowerCase());

            if (existingTags.includes(name.toLowerCase())) {
                input.value = '';
                return;
            }

            const newTag = document.createElement('span');
            newTag.className = 'institution-tag';
            newTag.innerHTML = `${name} <button onclick="removeInstitution(this)">×</button>`;
            institutionsList.appendChild(newTag);
            input.value = '';
        }

        document.getElementById('newInstitution').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                addInstitution();
            }
        });

        // Carrossel de Lições
        (function() {
            const track = document.getElementById('lessonsTrack');
            const prev = document.getElementById('prevBtn');
            const next = document.getElementById('nextBtn');
            if (!track || !prev || !next) return;

            function getStep() {
                const first = track.querySelector('.lesson-card');
                if (!first) return Math.round(track.clientWidth * 0.8);
                const style = window.getComputedStyle(track);
                const gap = parseInt(style.gap || 20, 10) || 20;
                return first.offsetWidth + gap;
            }
            prev.addEventListener('click', (e) => {
                e.preventDefault();
                track.scrollBy({
                    left: -getStep(),
                    behavior: 'smooth'
                });
            });
            next.addEventListener('click', (e) => {
                e.preventDefault();
                track.scrollBy({
                    left: getStep(),
                    behavior: 'smooth'
                });
            });
        })();

        // Carrossel de Feedbacks (Atualizado para conteúdo dinâmico)
        (function() {
            const viewport = document.querySelector('.feedback-container > div[style*="padding: 0 10px;"]'); // Seleciona o novo wrapper
            const track = document.getElementById('feedbackTrack');
            const next = document.querySelector('.feedback-container .feedback-next');
            const prev = document.querySelector('.feedback-container .feedback-prev');

            if (!track || !viewport) return;

            let index = 0;
            const cards = track.querySelectorAll('.feedback-card:not(.empty-message)').length;
            
            // Não configura o carrossel se houver 0 ou 1 card
            if (cards <= 1) return; 

            function getCardStep() {
                const firstCard = track.querySelector('.feedback-card');
                if (!firstCard) return 0;
                
                // Calcula a largura da primeira carta (assumindo que todas têm a mesma largura)
                const cardWidth = firstCard.offsetWidth;
                
                // Obtém o gap/margin lateral (Ajuste o valor 20 se o seu CSS for diferente)
                const gap = 20; 
                
                return cardWidth + gap; 
            }

            function moveCarousel() {
                const step = getCardStep();
                // A tradução é aplicada ao track, que está dentro do novo viewport
                track.style.transform = `translateX(-${index * step}px)`;
            }

            if (next) {
                next.addEventListener('click', () => {
                    index = (index + 1) % cards;
                    moveCarousel();
                });
            }

            if (prev) {
                prev.addEventListener('click', () => {
                    index = (index - 1 + cards) % cards;
                    moveCarousel();
                });
            }
            
            window.addEventListener('resize', () => {
                index = 0; // Volta para o início ao redimensionar
                moveCarousel();
            });
            moveCarousel(); 
        })();

    </script>
    
</body>

</html>