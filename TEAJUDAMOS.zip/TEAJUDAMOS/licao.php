<?php
session_start();
include 'conexao.php';

$usuario_logado = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$user_id = $_SESSION['user_id'] ?? 0;
$nome_usuario = "";
$foto_perfil_existe = false;
$data_atualizacao = time();

if ($usuario_logado) {
    if ($conexao && !$conexao->connect_error) {
        $stmt_user = $conexao->prepare("SELECT NOME, FOTO_PERFIL, DATA_ATUALIZACAO FROM USUARIOS WHERE ID = ?");
        if ($stmt_user) {
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $res_u = $stmt_user->get_result();
            if ($res_u->num_rows > 0) {
                $u_data = $res_u->fetch_assoc();
                $nome_usuario = htmlspecialchars(explode(' ', $u_data['NOME'])[0]);
                $foto_perfil_existe = !empty($u_data['FOTO_PERFIL']);
                // [CORREÇÃO 2] Capturar e formatar a data de atualização
                $data_atualizacao = urlencode($u_data['DATA_ATUALIZACAO'] ?? time()); 
            }
            $stmt_user->close();
        }
    }
}

$licao_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($licao_id == 0) die("Lição não encontrada.");

// Busca Lição
$stmt = $conexao->prepare("SELECT l.*, u.NOME AS PROFESSOR_NOME FROM LICAO l JOIN USUARIOS u ON l.PROFESSOR_ID = u.ID WHERE l.ID = ?");
$stmt->bind_param("i", $licao_id);
$stmt->execute();
$licao = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$licao) die("Lição não encontrada.");

// Avaliação
$avaliacao_usuario = 0;
if ($usuario_logado) {
    $stmt_l = $conexao->prepare("SELECT AVALIACAO FROM FEEDBACK WHERE LICAO_ID = ? AND PROFESSOR_AVALIADOR = ?");
    $stmt_l->bind_param("ii", $licao_id, $user_id);
    $stmt_l->execute();
    $res_l = $stmt_l->get_result();
    if ($res_l->num_rows > 0) {
        $av = $res_l->fetch_assoc()['AVALIACAO'];
        if ($av >= 4) $avaliacao_usuario = 5;
        elseif ($av <= 2 && $av > 0) $avaliacao_usuario = 1;
    }
    $stmt_l->close();
}

// Contagens
$stmt_c = $conexao->prepare("SELECT COUNT(*) as total FROM FEEDBACK WHERE LICAO_ID = ? AND AVALIACAO >= 3");
$stmt_c->bind_param("i", $licao_id);
$stmt_c->execute();
$like_count = $stmt_c->get_result()->fetch_assoc()['total'];

$stmt_d = $conexao->prepare("SELECT COUNT(*) as total FROM FEEDBACK WHERE LICAO_ID = ? AND AVALIACAO <= 2 AND AVALIACAO > 0");
$stmt_d->bind_param("i", $licao_id);
$stmt_d->execute();
$dislike_count = $stmt_d->get_result()->fetch_assoc()['total'];

$conexao->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title><?php echo htmlspecialchars($licao['TITULO']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">

    <style>
        /* --- GERAL --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fafb;
            min-height: 100vh;
            line-height: 1.6;
            padding-top: 80px;
        }

        /* --- HEADER (Desktop Fixo) --- */
        header {
            background-color: purple;
            width: 100%;
            padding: 10px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 80px;
            position: fixed;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo img {
            width: 200px;
            height: auto;
            margin-top: 10px;
            object-fit: cover;
            cursor: pointer;
            transition: 0.3s;
        }

        .logo img:hover {
            transform: scale(1.08);
        }

         .profile-icon {
        position: relative;
        display: inline-block;
    }

    .profile-icon i {
        cursor: pointer;
        transition: transform 0.3s ease-in-out;
        border-radius: 100px;
        position: relative;
        z-index: 1;
        font-size: 50px;
        color: #000000ff;
        transition: color 0.35s ease-in-out, transform 0.3s ease-in-out;
    }
    

    .profile-icon:hover i {
        transform: scale(1.15);
        cursor: pointer;
        color: white;
    }

    .profile-icon img.profile-pic {
        font-size: 50px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #000000ff;
        cursor: pointer;
        transition: transform 0.3s ease-in-out, border-color 0.35s ease-in-out;
        position: relative;
        z-index: 1;
    }

    .profile-icon:hover img.profile-pic {
        transform: scale(1.15);
        border-color: white;
    }
    
    /* From Uiverse.io by reglobby */ 
.user-profile {
  width: 131px;
  height: 51px;
  border-radius: 15px;
  cursor: pointer;
  transition: 0.3s ease;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
}

.user-profile:hover,
.user-profile:focus {
  background-color: rgba(185, 0, 185);
  box-shadow: 0 0 10px rgba(185, 0, 185);
  outline: none;
}

.user-profile-inner {
  width: 127px;
  height: 47px;
  border-radius: 13px;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  color: #fff;
  font-weight: 600;
}

.user-profile-inner svg {
  width: 27px;
  height: 27px;
  fill: #fff;
}



        /* --- CONTAINER --- */
        .container {
            max-width: 1024px;
            margin: 0 auto;
            padding: 0 16px;
        }

        .main {
            padding: 24px 0;
        }

        /* --- CABEÇALHO DA LIÇÃO --- */
        .lesson-header-block {
            background-color: purple;
            color: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 32px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .lesson-header-block h1 {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .lesson-header-block .subtitle {
            color: #c4b5fd;
            font-size: 16px;
        }

        .lesson-header-block .date {
            font-size: 14px;
            color: #c4b5fd;
            margin-top: 5px;
        }

        .lesson-header-block .date strong {
            font-size: 16px;
            color: white;
            font-weight: 600;
            display: block;
        }

        @media (min-width: 640px) {
            .lesson-header-block {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
            }

            .lesson-header-block .date {
                text-align: right;
            }
        }

        /* --- SEÇÕES DE CONTEÚDO --- */
        .section {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 32px;
            margin-bottom: 32px;
        }

        .section-title {
            font-size: 20px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
        }

        .section-icon {
            width: 32px;
            height: 32px;
            background-color: purple;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: bold;
            margin-right: 12px;
        }

        /* --- OBJETIVOS --- */
        .objectives-list li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 12px;
            color: #374151;
        }

        .bullet {
            width: 8px;
            height: 8px;
            background-color: purple;
            border-radius: 50%;
            margin-top: 8px;
            margin-right: 12px;
            flex-shrink: 0;
        }

        /* --- MATERIAIS --- */
        .materials-grid {
            display: grid;
            gap: 24px;
            grid-template-columns: 1fr;
        }

        @media (min-width: 640px) {
            .materials-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        .materials-section h3 {
            font-size: 18px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 12px;
        }

        .material-item {
            border: 1px solid;
            border-radius: 8px;
            padding: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
        }

        .pdf-item {
            background-color: #8B5CF6;
            border-color: #8B5CF6;
        }

        .image-item {
            background-color: #8B5CF6;
            border-color: #8B5CF6;
        }

        .material-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
            flex-shrink: 0;
        }

        .pdf-icon {
            background-color: #ef4444;
        }

        .image-icon {
            background-color: #3b82f6;
        }

        .material-info {
            flex: 1;
            min-width: 0;
        }

        .material-title {
            font-weight: 600;
            color: white;
            font-size: 14px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .material-btn {
            background-color: purple;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            cursor: pointer;
            padding: 8px 16px;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }

        .material-btn:hover {
            transform: scale(1.05);
            filter: brightness(1.2);
        }

        /* --- OBSERVAÇÕES --- */
        .observation-box {
            background: linear-gradient(135deg, #F3E8FF 0%, #EDE9FE 100%);
            border-left: 4px solid #8B5CF6;
            padding: 24px;
            border-radius: 8px;
            margin-bottom: 16px;
        }

        .observation-title {
            font-weight: bold;
            color: #6b21a8;
            margin-bottom: 10px;
        }

        .observation-text {
            color: #374151;
            font-size: 14px;
        }

        /* --- AVALIAÇÃO --- */
        .rating-section {
            text-align: center;
        }

        .rating-title {
            font-size: 22px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 16px;
        }

        .rating-buttons {
            display: flex;
            flex-direction: row;
            gap: 16px;
            justify-content: center;
        }

        .rating-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            color: white;
            cursor: pointer;
            transition: 0.3s;
            width: auto;
            min-width: 140px;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
        }

        .rating-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .rating-btn:disabled {
            background: #9ca3af;
            cursor: not-allowed;
            transform: none;
        }

        .like-btn {
            background: #22c55e;
        }

        .dislike-btn {
            background: #ef4444;
        }

        .rating-btn.active {
            transform: translateY(-2px);
            filter: brightness(0.8);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .rating-emoji {
            font-size: 20px;
        }

        .rating-help {
            color: #6b7280;
            margin-top: 15px;
        }

        .rating-help a {
            color: purple;
            font-weight: bold;
            text-decoration: none;
        }

        /* --- FOOTER --- */
        footer {
            width: 100%;
            background: linear-gradient(90deg, rgb(76, 0, 76), purple);
            color: white;
            padding: 50px 0 20px;
            margin-top: 50px;
            font-family: 'Poppins', sans-serif;
        }

        .footer-container {
            width: 90%;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .footer-logo img {
            position: absolute;
            margin-top: -100px;
            width: 400px;
            margin-left: -30px;
        }

        .footer-links ul,
        .footer-contact ul {
            list-style: none;
            padding: 0;
        }

        .footer-links ul li,
        .footer-contact ul li {
            margin: 10px 0;
            display: flex;
            gap: 8px;
        }

        .footer-links ul li a {
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links ul li a:hover {
            color: #d63de4ff;
        }

        .footer-bottom {
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            margin-top: 50px;
            padding-top: 15px;
            font-size: 14px;
            color: #e0d6ff;
        }

        /* --- MODAL --- */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            padding-top: 60px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.9);
        }

        .modal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 800px;
            animation-name: zoom;
            animation-duration: 0.6s;
        }

        @keyframes zoom {
            from {
                transform: scale(0)
            }

            to {
                transform: scale(1)
            }
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 768px) {
         body{
            width: 780px;
            height: 851px;
          }

          .header h1 {
            font-size: 40px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .header-subtitle {
            color: #c4b5fd;
            font-size: 27px;
        }

        .header-date {
            text-align: right;
        }

        .header-date p:first-child {
            font-size: 20px;
            color: #c4b5fd;
        }

        .header-date p:last-child {
            font-size: 30px;
            font-weight: 600;
        }


        .section-title {
            font-size: 30px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
        }

        .section-icon {
            width: 45px;
            height: 45px;
        }

        .section-icon i {
            font-size: 20px;
        }


        .objectives-list li {
            font-size: 20px;
        }

        .bullet {
            width: 12px;
            height: 12px;
            margin-top: 10px;
        }

        .materials-section h3 {
            font-size: 25px;
        }


        .pdf-item {
            background-color: #8B5CF6;
            border-color: #8B5CF6;
            margin-bottom: 10px;
        }

        .image-item {
            background-color: #8B5CF6;
            border-color: #8B5CF6;
            margin-bottom: 10px;
        }

        .material-icon {
            width: 55px;
            height: 55px;
            font-size: 20px;
        }

        .pdf-icon {
            background-color: #ef4444;
        }


        .material-title {
            font-size: 20px;
        }

        .material-meta {
            font-size: 17px;
        }

        .material-btn {
            font-size: 20px;
            padding: 10px 15px;
        }

        .observation-box {
            background: linear-gradient(135deg, #F3E8FF 0%, #EDE9FE 100%);
            border-left: 4px solid #8B5CF6;
            padding: 24px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .observation-title {
            font-weight: bold;
            color: #6b21a8;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            font-size: 22px;
        }

        .observation-text {
    color: #374151;
    line-height: 1.6;
    font-size: 18px;
    word-wrap: break-word; 
    overflow-wrap: break-word;
}

    .rating-title {
            font-size: 30px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 16px;
        }

        .rating-help {
            color: #6b7280;
            font-size: 25px;
            margin-top: 15px;
        }
        
    .rating-btn {
            padding: 12px 24px;
            width: 100%;
            font-size: 25px;
            margin-bottom: 20px;
            height: 60px;
        }

    .rating-btn i{
        font-size: 35px;
    }


    footer {
        padding: 30px 0 10px;
    }

    .footer-container {
        flex-direction: column; 
        align-items: center;
        gap: 30px;
        text-align: center;
    }

    .footer-logo img {
        display: none;
    }
    
    .footer-links h3, .footer-contact h3 {
        text-align: center;
        font-size: 33px;
        margin-bottom: 45px;
    }

    .footer-links h3::after, .footer-contact h3::after {
        left: 50%;
        transform: translateX(-50%);
    }

    .footer-links ul li, .footer-contact ul li {
        justify-content: center; 
        font-size: 25px;
    }

    .footer-bottom {
        margin-top: 30px;
    }

    .footer-bottom p {
        font-size: 20px;
    }

        }
        
        }

    </style>
</head>

<body>

    <header>
        <div class="logo">
            <a href="index.php"><img src="imagens/logo-teajudamos.png" alt="logo"></a>
        </div>
        <div class="profile-icon">

  <?php if ($usuario_logado): ?>

      <a href="perfil.php" style="text-decoration: none;">

        <?php
          echo $foto_perfil_existe
            ? '<img class="profile-pic" src="get_imagem_usuario.php?id='. $user_id .'&v='. $data_atualizacao .'" alt="'. $nome_usuario .'" />'
            : '<i class="fa-solid fa-user-circle"></i>';
        ?>

      </a>

  <?php else: ?>

      <a href="login.php" style="text-decoration: none;">
        <div aria-label="User Login Button" tabindex="0" role="button" class="user-profile">
          <div class="user-profile-inner">
            <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                 viewBox="0 0 24 24">
                <g id="Layer_2">
                  <path d="m15.626 11.769a6 6 0 1 0 -7.252 0 9.008 9.008 0 0 0 -5.374 8.231 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 9.008 9.008 0 0 0 -5.374-8.231zm-7.626-4.769a4 4 0 1 1 4 4 4 4 0 0 1 -4-4zm10 14h-12a1 1 0 0 1 -1-1 7 7 0 0 1 14 0 1 1 0 0 1 -1 1z">
                  </path>
                </g>
            </svg>
            <p>Entrar</p>
          </div>
        </div>
      </a>

  <?php endif; ?>

</div>
    </header>

    <main class="main">
        <div class="container">

            <div class="lesson-header-block">
                <div>
                    <h1><?php echo htmlspecialchars($licao['TITULO']); ?></h1>
                    <p class="subtitle">Lição por <?php echo htmlspecialchars($licao['PROFESSOR_NOME']); ?></p>
                </div>
                <div class="date">
                    <p>Publicado em</p>
                    <strong><?php echo date('d/m/Y H:i', strtotime($licao['DATA_PUBLICACAO'])); ?></strong>
                </div>
            </div>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"><i class="fas fa-book icon"></i></span>Objetivos da Lição</h2>
                <ul class="objectives-list">
                    <?php
                    $objs = array_filter([$licao['OBJETIVOS_1'], $licao['OBJETIVOS_2'], $licao['OBJETIVOS_3']]);
                    if (!empty($objs)):
                        foreach ($objs as $obj): ?>
                            <li><span class="bullet"></span><?php echo htmlspecialchars($obj); ?></li>
                        <?php endforeach;
                    else: ?>
                        <li><span class="bullet"></span>Nenhum objetivo informado.</li>
                    <?php endif; ?>
                </ul>
            </section>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"> <i class="fa-solid fa-folder-open"></i> </span>Materiais da Lição</h2>
                <div class="materials-grid">
                    <div class="materials-section">
                        <h3><i class="fa-solid fa-file-lines"></i> Documentos PDF</h3>
                        <?php
                        $has_anexo = false;
                        if (!empty($licao['ANEXO_1'])) {
                            $has_anexo = true;
                            $nome1 = $licao['NOME_ANEXO_1'] ?? 'Documento 1';
                            echo '<div class="material-item pdf-item">
                                    <div class="material-icon pdf-icon">PDF</div>
                                    <div class="material-info"><h4 class="material-title">' . htmlspecialchars($nome1) . '</h4></div>
                                    <a href="get_anexo_licao.php?id=' . $licao_id . '&tipo=anexo1" class="material-btn">Baixar</a>
                                  </div>';
                        }
                        if (!empty($licao['ANEXO_2'])) {
                            $has_anexo = true;
                            $nome2 = $licao['NOME_ANEXO_2'] ?? 'Documento 2';
                            echo '<div class="material-item pdf-item">
                                    <div class="material-icon pdf-icon">PDF</div>
                                    <div class="material-info"><h4 class="material-title">' . htmlspecialchars($nome2) . '</h4></div>
                                    <a href="get_anexo_licao.php?id=' . $licao_id . '&tipo=anexo2" class="material-btn">Baixar</a>
                                  </div>';
                        }
                        if (!$has_anexo) echo '<p>Nenhum documento anexado.</p>';
                        ?>
                    </div>

                    <div class="materials-section">
                        <h3><i class="fas fa-image"></i> Imagens e Diagramas</h3>
                        <?php
                        $has_img = false;
                        if (!empty($licao['IMAGEM_1'])) {
                            $has_img = true;
                            echo '<div class="material-item image-item">
                                    <div class="material-icon image-icon">IMG</div>
                                    <div class="material-info"><h4 class="material-title">Imagem 1</h4></div>
                                    <button class="material-btn" onclick="openModal(\'get_imagem_licao.php?id=' . $licao_id . '&tipo=img1\')">Ver</button>
                                  </div>';
                        }
                        if (!empty($licao['IMAGEM_2'])) {
                            $has_img = true;
                            echo '<div class="material-item image-item">
                                    <div class="material-icon image-icon">IMG</div>
                                    <div class="material-info"><h4 class="material-title">Imagem 2</h4></div>
                                    <button class="material-btn" onclick="openModal(\'get_imagem_licao.php?id=' . $licao_id . '&tipo=img2\')">Ver</button>
                                  </div>';
                        }
                        if (!$has_img) echo '<p>Nenhuma imagem anexada.</p>';
                        ?>
                    </div>
                </div>
            </section>

            <section class="section">
                <h2 class="section-title"><span class="section-icon"><i class="fa-regular fa-newspaper"></i></span>Métodos</h2>
                <?php
                $obs_list = array_filter([$licao['OBSERVACAO_1'], $licao['OBSERVACAO_2'], $licao['OBSERVACAO_3']]);
                if (!empty($obs_list)):
                    $i = 1;
                    foreach ($obs_list as $obs): ?>
                        <div class="observation-box">
                            <h3 class="observation-title">Método <?php echo $i++; ?></h3>
                            <p class="observation-text"><?php echo nl2br(htmlspecialchars($obs)); ?></p>
                        </div>
                    <?php endforeach;
                else: ?>
                    <p>Nenhum método informado.</p>
                <?php endif; ?>
            </section>

            <section class="section rating-section">
                <h3 class="rating-title">Avalie esta lição</h3>
                <?php if ($usuario_logado): ?>
                    <?php $is_autor = ($licao['PROFESSOR_ID'] == $user_id); ?>
                    <div class="rating-buttons">
                        <button type="button" id="likeBtn" class="rating-btn like-btn <?php if ($avaliacao_usuario == 5) echo 'active'; ?>"
                            onclick="submitFeedback(this, 5, <?php echo $licao_id; ?>)" <?php if ($is_autor) echo 'disabled'; ?>>
                            <span class="rating-emoji"><i class="fa-solid fa-thumbs-up"></i></span>
                            <span class="rating-count" id="likeCount"><?php echo $like_count; ?></span>
                        </button>
                        <button type="button" id="dislikeBtn" class="rating-btn dislike-btn <?php if ($avaliacao_usuario == 1) echo 'active'; ?>"
                            onclick="submitFeedback(this, 1, <?php echo $licao_id; ?>)" <?php if ($is_autor) echo 'disabled'; ?>>
                            <span class="rating-emoji"><i class="fa-solid fa-thumbs-down"></i></span>
                            <span class="rating-count" id="dislikeCount"><?php echo $dislike_count; ?></span>
                        </button>
                    </div>
                    <?php if ($is_autor): ?>
                        <p class="rating-help">Você não pode avaliar sua própria lição.</p>
                    <?php else: ?>
                        <p class="rating-help">Sua avaliação nos ajuda a melhorar o conteúdo</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="rating-help">Você precisa <a href="login.php">fazer login</a> para avaliar esta lição.</p>
                <?php endif; ?>
            </section>

        </div>
    </main>

    <footer id="footer">
        <div class="footer-container">
            <div class="footer-logo"><img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS"></div>
            <?php 
// 1. Verifica se a sessão está iniciada e se o usuário é administrador
// É crucial garantir que session_start(); foi chamado no topo da sua página.
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
          <h3>Navegação</h3>
          <ul>

        <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
        <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
        <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
        <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
        
        <?php 
        // 3. Bloco Condicional para Administrador
        if ($is_admin) {
            // Este link só será renderizado se o papel for 'admin'
            // Utilize o ícone 'fa-user-cog' para o ícone de administrador
            echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
        }
        ?>

        <!-- 4. Link de Entrar/Sair Dinâmico -->
        <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

            
          </ul>
        </div>
            <div class="footer-contact">
                <h3>Contato</h3>
                <ul>
                    <li><i class="fa-solid fa-envelope"></i> teajudamos@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
        </div>
    </footer>

    <div id="imageModal" class="modal">
        <span class="modal-close">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <script>
        var modal = document.getElementById("imageModal");
        var modalImg = document.getElementById("modalImage");
        var span = document.getElementsByClassName("modal-close")[0];

        function openModal(src) {
            modal.style.display = "block";
            modalImg.src = src;
        }

        span.onclick = function() {
            modal.style.display = "none";
        }
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        async function submitFeedback(button, avaliacao, licaoId) {
            const likeBtn = document.getElementById('likeBtn');
            const dislikeBtn = document.getElementById('dislikeBtn');
            likeBtn.disabled = true;
            dislikeBtn.disabled = true;

            const formData = new FormData();
            formData.append('licao_id', licaoId);
            formData.append('avaliacao', avaliacao);

            try {
                const response = await fetch('processar_feedback.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                if (result.status === 'success') {
                    document.getElementById('likeCount').textContent = result.like_count;
                    document.getElementById('dislikeCount').textContent = result.dislike_count;
                    likeBtn.classList.remove('active');
                    dislikeBtn.classList.remove('active');
                    if (result.voto_atual == 5) likeBtn.classList.add('active');
                    else if (result.voto_atual == 1) dislikeBtn.classList.add('active');
                } else {
                    alert(result.message);
                }
            } catch (e) {
                console.error(e);
            } finally {
                likeBtn.disabled = false;
                dislikeBtn.disabled = false;
            }
        }
    </script>
</body>

</html>