<?php
session_start(); 

// Lógica para buscar foto de perfil do usuário logado
$usuario_logado = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$nome_usuario = "";
$foto_perfil_existe = false;
$user_id = 0;

include 'conexao.php'; 

if ($usuario_logado) {
    $user_id = $_SESSION['user_id'];
    
    if ($conexao && !$conexao->connect_error) {
        $stmt_user = $conexao->prepare("SELECT NOME, FOTO_PERFIL, DATA_ATUALIZACAO FROM USUARIOS WHERE ID = ?");
        if ($stmt_user) {
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            
                    // Dentro do if ($result_user->num_rows > 0) { ... }
        if ($result_user->num_rows > 0) {
            $user_data = $result_user->fetch_assoc();
            $full_name = $user_data['NOME'] ?? 'Perfil';
            $first_name = explode(' ', $full_name)[0];
            $nome_usuario = htmlspecialchars($first_name);
            $foto_perfil_existe = !empty($user_data['FOTO_PERFIL']);
            
            // ********** Adicione esta linha **********
            $cache_buster = urlencode($user_data['DATA_ATUALIZACAO'] ?? time());
            // Se a data de atualização for nula (usuário muito antigo), use o timestamp atual
        }
            $stmt_user->close();
        }
    }
}

// Busca as Lições Destacadas
$licoes_resultado = false;
if ($conexao && !$conexao->connect_error) {
    // ALTERAÇÃO AQUI: Incluindo MATERIA, PROFESSOR_ID e a lógica para verificar a capa (TEM_CAPA)
    $licoes_resultado = $conexao->query("
        SELECT 
            ID, TITULO, MATERIA, PROFESSOR_ID, 
            (CASE WHEN CAPA IS NOT NULL AND LENGTH(CAPA) > 0 THEN 1 ELSE 0 END) as TEM_CAPA 
        FROM LICAO 
        ORDER BY DATA_PUBLICACAO DESC 
        LIMIT 7
    ");
}


$feedbacks_resultado = false;
if ($conexao && !$conexao->connect_error) {

    $feedbacks_resultado = $conexao->query(
        "SELECT f.AVALIACAO, f.TEXTO, u.ID as USUARIO_ID, u.NOME, 
         (CASE WHEN u.FOTO_PERFIL IS NOT NULL AND LENGTH(u.FOTO_PERFIL) > 0 THEN 1 ELSE 0 END) as TEM_FOTO
         FROM FEEDBACKS_SITE f 
         JOIN USUARIOS u ON f.USUARIO_ID = u.ID 
         WHERE f.AVALIACAO = 5 
         ORDER BY f.ID DESC 
         LIMIT 5"
    );
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width">
  <title>TEAJUDAMOS</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">


  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: white;
        color: #333;
        height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    header {
        background-color: purple;
        width: 100%;
        padding: 10px 30px;
        border-radius: 4.3px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        z-index: 1;
        height: 80px;
        position: fixed;
    }

    .hero-section {
        background: linear-gradient(180deg, #5e005e, purple);
        padding-top: 100px;
        position: relative;
        width: 100%;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: white;
        text-align: center;
        overflow: hidden;
    }

    .hero-content {
        max-width: 900px;
        padding: 20px;
        z-index: 0;
    }

    .hero-content h1 {
        font-size: 3.5rem;
        margin-bottom: 20px;
        font-weight: 800;
        line-height: 1.2;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
    }

    .hero-content p {
        font-size: 1.4rem;
        margin-bottom: 30px;
        font-weight: 400;
        opacity: 0.9;
    }

    .cta-button {
        background-color: #ffc400;
        color: #5e005e;
        padding: 15px 35px;
        border: none;
        border-radius: 50px;
        font-size: 1.25rem;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.5s ease, color 0.6s ease;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        text-decoration: none;
        display: inline-block;
    }

    .cta-button:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        background-color: #ffffffff;
        color: #ffc400;
    }

    .cta-button i {
        transition: margin-left 0.3s ease;
    }

    .cta-button:hover i {
        margin-left: 25px;
    }

    .idea-board {
        margin-top: 40px;
        width: 300px;
        height: 180px;
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 15px;
        border: 2px solid rgba(255, 255, 255, 0.4);
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: 32%;
        z-index: 2;
        cursor: pointer;
        backdrop-filter: blur(5px);
    }

    .idea-text-wrapper {
        position: absolute;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        overflow: hidden;
    }

    .idea-text {
        position: absolute;
        font-size: 1.5rem;
        font-weight: 600;
        color: #fff;
        opacity: 0;
        transform: translateY(100%);
        transition: opacity 0.5s ease-in-out, transform 0.5s ease-in-out;
        padding: 0 15px;
    }

    .idea-board i {
        font-size: 4rem;
        color: #ffc400;
        opacity: 0.8;
        position: absolute;
    }

    .idea-text.active {
        opacity: 1;
        transform: translateY(0);
    }

    .blackboard-text {
        margin-top: 45px;
        color: rgba(255, 255, 255, 0.8);
    }

    .idea-particle {
        position: absolute;
        background-color: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        pointer-events: none;
        animation: ideaFloat 20s infinite ease-in-out;
    }

    @keyframes ideaFloat {
        0% {
            transform: translate(0, 0) scale(1);
            opacity: 0.3;
        }
        50% {
            transform: translate(100px, 100px) scale(1.2);
            opacity: 0.6;
        }
        100% {
            transform: translate(0, 0) scale(1);
            opacity: 0.3;
        }
    }

    .section1 {
        background: linear-gradient(180deg, purple, #7c24a1ff);
        padding: none;
        position: relative;
        height: 100%;
    }

    .section2 {
        background: linear-gradient(180deg, #7c24a1ff, #881288ff);
        padding: none;
        position: relative;
        height: 115%;
    }

    .logo img {
        margin-top: 15px;
        width: 250px;
        height: auto;
        object-fit: cover;
        cursor: pointer;
    }

    nav {
        display: flex;
        gap: 5px;
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
    }

    .menu {
        font-size: 16px;
        line-height: 1.6;
        color: white;
        width: fit-content;
        display: flex;
        background-color: rgb(76, 0, 76);
        width: 80%;
        list-style: none;
        font-weight: 600;
    }

    .menu a {
        text-decoration: none;
        color: white;
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }

    .menu .link {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px 36px;
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .menu .link::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 85%;
        height: 80%;
        background-color: purple;
        z-index: -1;
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .menu .link svg {
        width: 14px;
        height: 14px;
        margin-right: -10px;
        fill: white;
        transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .menu .item {
        position: relative;
    }

    .menu .item .submenu {
        display: flex;
        flex-direction: column;
        align-items: center;
        position: absolute;
        top: 100%;
        border-radius: 0 0 16px 16px;
        left: 0;
        width: 100%;
        overflow: hidden;
        border: 1px solid #cccccc;
        opacity: 0;
        visibility: hidden;
        transform: translateY(-12px);
        transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
        z-index: 1;
        pointer-events: none;
        list-style: none;
        background-color: purple;
    }

    .menu .item:hover .submenu {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
        pointer-events: auto;
        border-top: transparent;
        border-color: purple;
        filter: brightness(1.2);
    }

    .menu .item:hover .link {
        color: #ffffff;
        border-radius: 16px 16px 0 0;
    }

    .menu .item:hover .link::after {
        transform: scaleX(1);
        transform-origin: right;
    }

    .menu .item:hover .link svg {
        fill: #ffffff;
        transform: rotate(-180deg);
    }

    .submenu .submenu-item {
        width: 100%;
        transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .submenu .submenu-link {
        display: block;
        padding: 12px 24px;
        width: 100%;
        position: relative;
        text-align: center;
        transition: all 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .submenu .submenu-item:last-child .submenu-link {
        border-bottom: none;
    }

    .submenu .submenu-link::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        transform: scaleX(0);
        width: 100%;
        height: 100%;
        background-color: purple;
        filter: brightness(1.2);
        z-index: -1;
        transform-origin: left;
        transition: transform 0.48s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .submenu .submenu-link:hover:before {
        transform: scaleX(1);
        transform-origin: right;
    }

    .submenu .submenu-link:hover {
        color: #ffffff;
    }

    .profile-icon {
        position: relative;
        display: inline-block;
    }

    .profile-icon i {
        cursor: pointer;
        transition: transform 0.3s ease-in-out;
        border-radius: 100px;
        position: relative;
        z-index: 1;
        font-size: 50px;
        color: #000000ff;
        transition: color 0.35s ease-in-out, transform 0.3s ease-in-out;
    }
    

    .profile-icon:hover i {
        transform: scale(1.15);
        cursor: pointer;
        color: white;
    }

    .profile-icon img.profile-pic {
        font-size: 50px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #000000ff;
        cursor: pointer;
        transition: transform 0.3s ease-in-out, border-color 0.35s ease-in-out;
        position: relative;
        z-index: 1;
    }

    .profile-icon:hover img.profile-pic {
        transform: scale(1.15);
        border-color: white;
    }
    
    /* From Uiverse.io by reglobby */ 
.user-profile {
  width: 131px;
  height: 51px;
  border-radius: 15px;
  cursor: pointer;
  transition: 0.3s ease;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
}

.user-profile:hover,
.user-profile:focus {
  background-color: rgba(185, 0, 185);
  box-shadow: 0 0 10px rgba(185, 0, 185);
  outline: none;
}

.user-profile-inner {
  width: 127px;
  height: 47px;
  border-radius: 13px;
  background-color: rgb(76,0, 76);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  color: #fff;
  font-weight: 600;
}

.user-profile-inner svg {
  width: 27px;
  height: 27px;
  fill: #fff;
}



    main {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .puzzle {
        width: 85px;
        position: absolute;
    }

    .top-left {
        top: 75px;
        left: 105px;
        transform: rotate(215deg);
    }

    .top-right {
        top: 75px;
        right: 105px;
        transform: rotate(345deg);
    }

    .bottom-left {
        bottom: 30px;
        left: 5px;
        transform: rotate(155deg);
    }

    .mid-right {
        top: 300px;
        right: 190px;
    }

    .mid-left {
        top: 240px;
        left: 170px;
        transform: rotate(205deg);
    }

    .bottom-right {
        transform: rotate(45deg);
        bottom: 30px;
        right: 25px;
    }

    .carousel-wrapper .carousel-title {
        font-size: 2.5rem;
        font-weight: 800;
        margin: 0;
        letter-spacing: .3px;
        color: transparent;
        background: linear-gradient(90deg, #ffd86b, #ff7aa2, #c084fc, #7c3aed);
        background-size: 300% 100%;
        -webkit-background-clip: text;
        background-clip: text;
        animation: shimmer 4.5s linear infinite;
        text-align: center;
        position: relative;
        top: -80px;
        width: 100%;
    }

    @keyframes shimmer {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }

    .carousel-wrapper {
        display: flex;
        justify-content: center;
        position: relative;
        top: 60px;
        align-items: center;
        height: 100%;
        flex-direction: column;
    }

    @keyframes autoRun3d {
        from {
            transform: perspective(800px) rotateY(-360deg);
        }

        to {
            transform: perspective(800px) rotateY(0deg);
        }
    }

    @keyframes animateBrightness {
        10% {
            filter: brightness(1);
        }

        50% {
            filter: brightness(0.6);
        }

        90% {
            filter: brightness(1);
        }
    }

    .card-3d {
        position: relative;
        width: 700px;
        height: 320px;
        transform-style: preserve-3d;
        transform: perspective(800px);
        animation: autoRun3d 20s linear infinite;
        will-change: transform;
        margin: 0 auto;
    }

    .card-3d div {
        position: absolute;
        width: 185px;
        height: 270px;
        background-color: purple;
        border: solid 2px lightgray;
        border-radius: 0.5rem;
        top: 50%;
        left: 50%;
        transform-origin: center center;
        animation: animateBrightness 5s linear infinite;
        transition-duration: 400ms;
        will-change: transform, filter;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        position: absolute;
        overflow: hidden;
    }

    .card-3d div img {
        width: 100%;
        height: 55%;
        object-fit: cover;
        display: block;
        border-radius: 0.5rem 0.5rem 0 0;
        background-color: #eee;
    }

    .card-3d div .overlay-text {
        position: absolute;
        margin-left: -170px;
        margin-top: 40px;
        width: 160%;
        height: 20%;
        padding: 12px;
        box-sizing: border-box;
        background: linear-gradient(135deg, rgba(24, 12, 50, 0.86), rgba(88, 10, 120, 0.62));
        color: #fff;
        font-size: 15px;
        font-weight: 700;
        letter-spacing: 0.1px;
        line-height: 1;
        text-align: center;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.06);
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.45);
        backdrop-filter: blur(6px);
    }

    .card-3d div .autor-btn {
        position: absolute;
        margin-left: auto;
        bottom: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 45px;
        height: 45px;
        padding: 6px;
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.06), rgba(0, 0, 0, 0.45));
        color: #fff;
        border-radius: 999px;
        text-decoration: none;
        border: 1px solid rgba(255, 255, 255, 0.12);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(4px);
        z-index: 40;
        transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
    }

    .card-3d div .autor-btn:hover,
    .card-3d div .autor-btn:focus {
        transform: translateY(-3px);
        filter: brightness(1.3);
    }

    .card-3d div:hover {
        z-index: 1000;
        transition: transform 0.3s ease, z-index 0s;
        cursor: pointer;
        animation-play-state: paused !important;
    }

    .card-3d:hover {
        animation-play-state: paused !important;
    }

    .card-3d:hover div {
        animation-play-state: paused !important;
    }

    .card-3d div:nth-child(1) {
        transform: translate(-50%, -50%) rotateY(0deg) translateZ(220px);
        animation-delay: -0s;
    }

    .card-3d div:nth-child(2) {
        transform: translate(-50%, -50%) rotateY(50deg) translateZ(220px);
        animation-delay: -2s;
    }

    .card-3d div:nth-child(3) {
        transform: translate(-50%, -50%) rotateY(100deg) translateZ(220px);
        animation-delay: -4s;
    }

    .card-3d div:nth-child(4) {
        transform: translate(-50%, -50%) rotateY(150deg) translateZ(220px);
        animation-delay: -6s;
    }

    .card-3d div:nth-child(5) {
        transform: translate(-50%, -50%) rotateY(200deg) translateZ(220px);
        animation-delay: -8s;
    }

    .card-3d div:nth-child(6) {
        transform: translate(-50%, -50%) rotateY(250deg) translateZ(220px);
        animation-delay: -10s;
    }

    .card-3d div:nth-child(7) {
        transform: translate(-50%, -50%) rotateY(310deg) translateZ(220px);
        animation-delay: -12s;
    }

    .feedback-carousel {
        margin: 0 auto;
        text-align: center;
        max-width: 85%;
        position: relative;
        top: 100px;
    }

    .feedback-carousel h2 {
        font-size: 2.5rem;
        font-weight: 800;
        margin: 0;
        letter-spacing: .3px;
        color: transparent;
        background: linear-gradient(90deg, #ffd86b, #ff7aa2, #c084fc, #7c3aed);
        background-size: 300% 100%;
        -webkit-background-clip: text;
        background-clip: text;
        animation: shimmer 4.5s linear infinite;
        text-align: center;
        position: relative;
        width: 100%;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        margin-bottom: 80px;
    }

    @keyframes shimmer {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }


    .feedback-container {
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }

    .feedback-track {
        display: flex;
        transition: transform 0.6s ease;
        margin-left: 400px;
    }

    .feedback-card {
        background: linear-gradient(135deg, #a770ef, #cf8bf3, #fdb99b);
        color: white;
        border-radius: 20px;
        margin: 0 5px;
        padding: 20px;
        width: 280px;
        flex-shrink: 0;
        text-align: left;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        animation: floatCard 4s ease-in-out infinite alternate;
    }

    .feedback-card img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 60%;
        margin-bottom: 10px;
        border: 2px solid white;
        background-color: #eee;
    }

    .default-profile-icon i {
        font-size: 60px;
        color: white;
        margin-bottom: 10px;
        display: block;
    }

    .feedback-info h4 {
        margin: 0;
        font-size: 1.1em;
        color: #fff;
    }

    .feedback-info p {
        font-size: 0.9em;
        margin: 8px 0;
    }

    .feedback-card i {
        font-size: 1.6em;
    }

    .feedback-card.happy i {
        color: #00ff88;
    }

    .feedback-card.neutral i {
        color: #f3f300;
    }

    .feedback-card.sad i {
        color: #ff4d4d;
    }

    .feedback-prev,
    .feedback-next {
        background: rgba(216, 82, 221, 0.79);
        border: none;
        color: white;
        font-size: 1.5em;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        cursor: pointer;
        z-index: 10;
        transition: 0.5s;
    }

    .feedback-prev:hover,
    .feedback-next:hover {
        background: rgba(131, 41, 134, 0.82);
    }

    .feedback-prev {
        position: absolute;
        left: 10px;
    }

    .feedback-next {
        position: absolute;
        right: 1px;
    }

    @keyframes floatCard {
        from {
            transform: translateY(0px);
        }

        to {
            transform: translateY(-8px);
        }
    }

    .chat {
        position: fixed;
        bottom: 30px;
        right: 70px;
        z-index: 1000;
    }

    .background {
        background-color: purple;
        border-radius: 50%;
        box-shadow: 0 2.1px 1.3px rgba(0, 0, 0, 0.044),
            0 5.9px 4.2px rgba(0, 0, 0, 0.054), 0 12.6px 9.5px rgba(0, 0, 0, 0.061),
            0 25px 20px rgba(0, 0, 0, 0.1);
        height: 80px;
        left: 10px;
        position: absolute;
        top: 10px;
        width: 80px;
    }

    .chat:hover .background {
        transform: scale(1.1);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.9),
            0 8px 20px rgba(0, 0, 0, 0.8);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        filter: brightness(1.2);
    }

    .chat .background {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .chat-bubble {
        cursor: pointer;
        position: relative;
    }

    .bubble {
        transform-origin: 50%;
        transition: transform 500ms cubic-bezier(0.17, 0.61, 0.54, 0.9);
    }

    .line {
        fill: none;
        stroke: white;
        stroke-width: 2.75;
        stroke-linecap: round;
        transition: stroke-dashoffset 500ms cubic-bezier(0.4, 0, 0.2, 1);
    }

    .line1 {
        stroke-dasharray: 60 90;
        stroke-dashoffset: -20;
    }

    .line2 {
        stroke-dasharray: 67 87;
        stroke-dashoffset: -18;
    }

    .circle {
        fill: white;
        stroke: none;
        transform-origin: 50%;
        transition: transform 500ms cubic-bezier(0.4, 0, 0.2, 1);
    }

    .active .bubble {
        transform: translateX(24px) translateY(4px) rotate(45deg);
    }

    .active .line1 {
        stroke-dashoffset: 21;
    }

    .active .line2 {
        stroke-dashoffset: 30;
    }

    .active .circle {
        transform: scale(0);
    }

    footer {
        width: 100%;
        background: linear-gradient(90deg, rgb(76, 0, 76), purple);
        color: white;
        padding: 50px 0 20px;
        font-family: 'Poppins', sans-serif;
    }

    .footer-container {
        width: 90%;
        margin: auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .footer-logo img {
        position: absolute;
        margin-top: -100px;
        width: 400px;
        margin-left: -30px;
    }

    .footer-links,
    .footer-contact {
        min-width: 200px;
    }

    .footer-links h3,
    .footer-contact h3 {
        font-size: 18px;
        margin-bottom: 15px;
        color: #fff;
        position: relative;
    }

    .footer-links h3::after,
    .footer-contact h3::after {
        content: "";
        position: absolute;
        width: 110px;
        height: 3px;
        background: #fff;
        left: 0;
        bottom: -4px;
        border-radius: 2px;
    }

    .footer-links ul,
    .footer-contact ul {
        list-style: none;
        padding: 0;
    }

    .footer-links ul li,
    .footer-contact ul li {
        margin: 10px 0;
        font-size: 15px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .footer-links ul li a {
        color: white;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .footer-links ul li a:hover {
        color: #d63de4ff;
    }

    .footer-bottom {
        text-align: center;
        border-top: 1px solid rgba(255, 255, 255, 0.2);
        margin-top: 50px;
        padding-top: 15px;
        font-size: 14px;
        color: #e0d6ff;
    }

    .footer-contact i,
    .footer-links i {
        color: #e0b3ff;
    }

    @media (max-width: 480px) {
        body {
            width: 480px;
        }

        header {
            height: 60px;
            padding: 10px 15px;
        }

        .section1,
        .section2 {
            height: 110%;
            margin: 0;
            padding: 0;
        }

        .logo img {
            width: 180px;
            margin-top: 15px;
            margin-left: -15px;
        }

        nav {
            display: none;
        }

        .user-profile {
            width: 100px;
            height: 40px;
            border-radius: 12px;
        }

        .user-profile-inner {
            width: 96px;
            height: 36px;
            gap: 8px;
            font-size: 0.9rem;
        }

        .user-profile-inner svg {
            width: 20px;
            height: 20px;
        }

        .hero-section {
            padding-top: 80px;
            min-height: 80vh;
        }

        .hero-content {
            padding: 15px;
        }

        .hero-content h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .hero-content p {
            font-size: 1.1rem;
            margin-bottom: 25px;
        }

        .cta-button {
            padding: 12px 25px;
            font-size: 1.1rem;
        }

        .cta-button:hover i {
            margin-left: 15px;
        }

        .idea-board {
            margin-top: 30px;
            width: 90%;
            max-width: 280px;
            height: 150px;
            margin-left: 20%;
        }

        .idea-board i {
            font-size: 3rem;
        }

        .idea-text {
            font-size: 1.2rem;
        }

        .blackboard-text {
            margin-top: 35px;
        }

        .puzzle {
            display: none;
        }

        .carousel-wrapper .carousel-title,
        .feedback-carousel h2 {
            font-size: 2rem;
            top: 20px;
            margin-bottom: 245px;
        }

        .card-3d {
            width: 40%;
            margin-bottom: 350px;
        }

        .feedback-carousel {
            top: -100px;
            max-width: 95%;
        }

        .feedback-carousel h2 {
            padding-top: 150px;
            margin-bottom: 80px;
        }

        .feedback-track {
            margin-left: 0;
            justify-content: flex-start;
            width: 100%;
            padding-bottom: 20px;
        }

        .feedback-container {
            overflow-x: scroll;
            -webkit-overflow-scrolling: touch;
            scroll-snap-type: x mandatory;
            justify-content: flex-start;
            padding: 0 10px;
        }

        .feedback-card {
            width: 100%;
            max-width: 280px;
            margin: 0 10px;
            scroll-snap-align: center;
        }

        .feedback-prev,
        .feedback-next {
            display: none;
        }

        .chat {
            bottom: 20px;
            right: 20px;
        }

        .background {
            height: 70px;
            width: 70px;
            top: 16px;
            left: 15px;
        }

        footer {
            padding: 30px 0 10px;
        }

        .footer-container {
            flex-direction: column;
            align-items: center;
            gap: 30px;
            text-align: center;
        }

        .footer-logo img {
            display: none;
        }

        .footer-links h3,
        .footer-contact h3 {
            text-align: center;
        }

        .footer-links h3::after,
        .footer-contact h3::after {
            left: 50%;
            transform: translateX(-50%);
        }

        .footer-links ul li,
        .footer-contact ul li {
            justify-content: center;
        }

        .footer-bottom {
            margin-top: 30px;
        }
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <a href="index.php"> <img src="imagens/logo-teajudamos.png" alt="logo"> </a>
    </div>
    <nav>
      <div class="menu">
        <div class="item">
          <a href="#" class="link">
            <span> Mais </span>
            <svg viewBox="0 0 360 360" xml:space="preserve">
              <g id="SVGRepo_iconCarrier">
                <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393 c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393 s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
              </g>
            </svg>
          </a>
          <div class="submenu">
            <div class="submenu-item">
              <a href="tarefas.php" class="submenu-link"> Tarefas </a>
            </div>

            <div class="submenu-item">
              <a href="feedback.php" class="submenu-link"> Feedback </a>
            </div>
            <div class="submenu-item">
              <a href="#footer" class="submenu-link"> Contato </a>
            </div>
            <div class="submenu-item">
              <a href="blog.php" class="submenu-link"> Blog </a>
            </div>

          </div>
        </div>
      </div>

      <div class="menu">
        <div class="item">
          <a href="#" class="link">
            <span> Templates </span>
            <svg viewBox="0 0 360 360" xml:space="preserve">
              <g id="SVGRepo_iconCarrier">
                <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393 c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393 s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
              </g>
            </svg>
          </a>
          <div class="submenu">
            <div class="submenu-item">
              <a href="tarefas.php" class="submenu-link"> Tarefas </a>
            </div>
            
            <div class="submenu-item">
              <a href="tarefas.php?filtro=matematica" class="submenu-link"> Matemática </a>
            </div>
            
            <div class="submenu-item">
              <a href="tarefas.php?filtro=portugues" class="submenu-link"> Português </a>
            </div>

          </div>
        </div>
      </div>

    </nav>

    <div class="profile-icon">

  <?php if ($usuario_logado): ?>

      <a href="perfil.php" style="text-decoration: none;">

<?php

echo $foto_perfil_existe
    ? '<img class="profile-pic" src="get_imagem_usuario.php?id=' . $user_id . '&t=' . $cache_buster . '" alt="' . $nome_usuario . '" />'
    : '<i class="fa-solid fa-user-circle"></i>';
?>

      </a>

  <?php else: ?>

      <a href="login.php" style="text-decoration: none;">
        <div aria-label="User Login Button" tabindex="0" role="button" class="user-profile">
          <div class="user-profile-inner">
            <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                 viewBox="0 0 24 24">
                <g id="Layer_2">
                  <path d="m15.626 11.769a6 6 0 1 0 -7.252 0 9.008 9.008 0 0 0 -5.374 8.231 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 9.008 9.008 0 0 0 -5.374-8.231zm-7.626-4.769a4 4 0 1 1 4 4 4 4 0 0 1 -4-4zm10 14h-12a1 1 0 0 1 -1-1 7 7 0 0 1 14 0 1 1 0 0 1 -1 1z">
                  </path>
                </g>
            </svg>
            <p>Entrar</p>
          </div>
        </div>
      </a>

  <?php endif; ?>

</div>

  </header>


  <main>

    <div class="hero-section">
      <span class="idea-particle" style="top: 10%; left: 5%; width: 10px; height: 10px;"></span>
      <span class="idea-particle" style="top: 80%; left: 20%; width: 15px; height: 15px; animation-delay: 3s; animation-duration: 25s;"></span>
      <span class="idea-particle" style="top: 45%; right: 15%; width: 8px; height: 8px; animation-delay: 8s; animation-duration: 18s;"></span>
      <span class="idea-particle" style="bottom: 10%; right: 5%; width: 12px; height: 12px; animation-delay: 5s; animation-duration: 22s;"></span>
      <span class="idea-particle" style="top: 25%; left: 40%; width: 14px; height: 14px; animation-delay: 1s; animation-duration: 15s;"></span>


      <div class="hero-content">
        <h1>Compartilhe o Conhecimento. Utilize o TEAJUDAMOS!</h1>
        <p>
          <b>TEAJUDAMOS </b> é a sua plataforma de colaboração: um espaço onde professores de todo o Brasil podem
          postar e encontrar lições adequadas para alunos com Transtorno do Espectro Autista (TEA).
          Nossa missão é facilitar o acesso a recursos educacionais inclusivos,
          promovendo um ambiente de aprendizado adaptado às necessidades específicas desses estudantes.
          Navegue por uma variedade de atividades

        </p>

        <a href="tarefas.php" class="cta-button">
          Explorar Ideias de Lição <i class="fa-solid fa-arrow-right"></i>
        </a>

        <div class="idea-board" onclick="changeIdeaText()">
          <i class="fa-solid fa-lightbulb"></i>
          <div class="idea-text-wrapper">
            <span class="idea-text active" data-index="0">Lições de Matemática para TEA</span>
            <span class="idea-text" data-index="1">Lições de Português para TEA</span>
            <span class="idea-text" data-index="2">Ilustrações em suas tarefas</span>
            <span class="idea-text" data-index="3">Anexe documentos em suas tarefas</span>
            <span class="idea-text" data-index="4">Avalie lições de outros professores</span>
            <span class="idea-text" data-index="5">Diversifique seus métodos de ensino</span>
          </div>
        </div>
        <p class="blackboard-text">Clique na caixa acima para ver mais exemplos de ideias!</p>
      </div>
    </div>

    <div class="section1">
      <img src="imagens/peca.png" class="puzzle top-left" alt="Ícone de quebra-cabeça" />
      <img src="imagens/peca.png" class="puzzle top-right" alt="Ícone de quebra-cabeça" />
      <img src="imagens/peca.png" class="puzzle bottom-left" alt="Ícone de quebra-cabeça" />
      <img src="imagens/peca.png" class="puzzle bottom-right" alt="Ícone de quebra-cabeça" />
      <img src="imagens/peca.png" class="puzzle mid-right" alt="Ícone de quebra-cabeça" />
      <img src="imagens/peca.png" class="puzzle mid-left" alt="Ícone de quebra-cabeça" />



      <div class="carousel-wrapper">
    <h2 class="carousel-title">Nossas Atividades Destacadas <i class="fa-solid fa-graduation-cap"></i></h2>
    <div class="card-3d">

        <?php if ($licoes_resultado && $licoes_resultado->num_rows > 0): ?>
            <?php while ($licao = $licoes_resultado->fetch_assoc()): ?>

                <div>
                    <?php if ($licao['TEM_CAPA']): // Se a lição tem capa ?>
                        <img src="get_imagem_licao.php?id=<?php echo $licao['ID']; ?>&tipo=capa" alt="<?php echo htmlspecialchars($licao['TITULO']); ?>">
                    <?php else: // Se a lição não tem capa, mostra o logo ?>
                        <img class="logo-fallback" src="imagens/logo-teajudamos.png" alt="Logo padrão - Sem capa">
                    <?php endif; ?>

                    <div class="overlay-text"><?php echo htmlspecialchars($licao['TITULO']); ?></div>

                    <a class="autor-btn" href="licao.php?id=<?php echo $licao['ID']; ?>" title="Abrir Tarefa">
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>

            <?php endwhile; ?>
        <?php else: ?>
            <p style="color: white; text-align: center; width: 100%;">Nenhuma atividade encontrada.</p>
        <?php endif; ?>

    </div>
</div>
    </div>

    <div class="section2">

      <section class="feedback-carousel">
        <h2>O que nossos usuários dizem <i class="fa-solid fa-comments"></i></h2>

        <div class="feedback-container">
          <button class="feedback-prev"><i class="fa-solid fa-chevron-left"></i></button>

          <div class="feedback-track">

            <?php if ($feedbacks_resultado && $feedbacks_resultado->num_rows > 0): ?>
              <?php while ($fb = $feedbacks_resultado->fetch_assoc()): ?>

                <?php
                $card_class = 'neutral';
                $icon_class = 'fa-solid fa-face-meh';

                if ($fb['AVALIACAO'] == 5) {
                  $card_class = 'happy';
                  $icon_class = 'fa-solid fa-face-smile-beam';
                } elseif ($fb['AVALIACAO'] == 1) {
                  $card_class = 'sad';
                  $icon_class = 'fa-solid fa-face-frown';
                }
                ?>

                <div class="feedback-card <?php echo $card_class; ?>">
<?php if ($fb['TEM_FOTO']): ?>
    <img src="get_imagem_usuario.php?id=<?php echo $fb['USUARIO_ID']; ?>&v=<?php echo urlencode($fb['DATA_ATUALIZACAO'] ?? time()); ?>" 
         alt="Foto de Perfil de <?php echo htmlspecialchars($fb['NOME']); ?>">
<?php else: ?>
    <div class="default-profile-icon"><i class="fa-solid fa-user-circle"></i></div>
<?php endif; ?>

                  <div class="feedback-info">
                    <h4><?php echo htmlspecialchars($fb['NOME']); ?></h4>
                    <p>"<?php echo htmlspecialchars($fb['TEXTO']); ?>"</p>
                    <i class="<?php echo $icon_class; ?>"></i>
                  </div>
                </div>

              <?php endwhile; ?>
            <?php else: ?>
            <?php endif; ?>

          </div>


          <button class="feedback-next"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
      </section>

    </div>

    <a href="feedback.php">
      <div class="chat">
        <div class="background"></div>
        <svg viewBox="0 0 100 100" height="100" width="100" class="chat-bubble">
          <g class="bubble">
            <path d="M 30.7873,85.113394 30.7873,46.556405 C 30.7873,41.101961
          36.826342,35.342 40.898074,35.342 H 59.113981 C 63.73287,35.342
          69.29995,40.103201 69.29995,46.784744" class="line line1"></path>
            <path d="M 13.461999,65.039335 H 58.028684 C
            63.483128,65.039335
            69.243089,59.000293 69.243089,54.928561 V 45.605853 C
            69.243089,40.986964 65.02087,35.419884 58.339327,35.419884" class="line line2"></path>
          </g>
          <circle cx="42.5" cy="50.7" r="1.9" class="circle circle1"></circle>
          <circle r="1.9" cy="50.7" cx="49.9" class="circle circle2"></circle>
          <circle cx="57.3" cy="50.7" r="1.9" class="circle circle3"></circle>
        </svg>
      </div>
    </a>

    <footer id="footer">
      <div class="footer-container">
        <div class="footer-logo">
          <img src="imagens/logo-teajudamos.png" alt="Logo TEAJUDAMOS">
        </div>
        
        <?php 
// 1. Verifica se a sessão está iniciada e se o usuário é administrador
// É crucial garantir que session_start(); foi chamado no topo da sua página.
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

$login_link_href = 'login.php';
$login_link_text = 'Entrar';
$login_icon_class = 'fa-user';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $login_link_href = 'logout.php'; 
    $login_link_text = 'Sair';
    $login_icon_class = 'fa-sign-out-alt'; 
}
?>

        <div class="footer-links">
          <h3>Navegação</h3>
          <ul>

        <li><a href="index.php"><i class="fa-solid fa-house"></i> Início</a></li>
        <li><a href="tarefas.php"><i class="fa-solid fa-book-open"></i> Tarefas</a></li>
        <li><a href="blog.php"><i class="fa-solid fa-newspaper"></i> Blog</a></li>
        <li><a href="feedback.php"><i class="fa-solid fa-comments"></i> Feedback</a></li>
        
        <?php 
        // 3. Bloco Condicional para Administrador
        if ($is_admin) {
            // Este link só será renderizado se o papel for 'admin'
            // Utilize o ícone 'fa-user-cog' para o ícone de administrador
            echo '<li><a href="administrador.php"><i class="fa-solid fa-user-cog"></i> Administração</a></li>';
        }
        ?>

        <!-- 4. Link de Entrar/Sair Dinâmico -->
        <li><a href="<?php echo $login_link_href; ?>"><i class="fa-solid <?php echo $login_icon_class; ?>"></i> <?php echo $login_link_text; ?></a></li>

            
          </ul>
        </div>

        <div class="footer-contact">
          <h3>Contato</h3>
          <ul>
            <li><i class="fa-solid fa-envelope"></i> teajudamos@gmail.com</li>
            <li><i class="fa-solid fa-location-dot"></i> ETEC POLIVALENTE DE AMERICANA</li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <p>© 2025 TEAJUDAMOS — Todos os direitos reservados.</p>
      </div>
    </footer>
  </main>

  <script>
    const track = document.querySelector('.feedback-track');
    const next = document.querySelector('.feedback-next');
    const prev = document.querySelector('.feedback-prev');

    let index = 0;
    const cards = document.querySelectorAll('.feedback-card').length;
    const cardWidth = 200;

    function moveCarousel() {
      if (cards > 0) {
        track.style.transform = `translateX(-${index * cardWidth}px)`;
      }
    }

    next.addEventListener('click', () => {
      if (cards > 0) {
        index = (index + 1) % cards;
        moveCarousel();
      }
    });

    prev.addEventListener('click', () => {
      if (cards > 0) {
        index = (index - 1 + cards) % cards;
        moveCarousel();
      }
    });

    setInterval(() => {
      if (cards > 0) {
        index = (index + 1) % cards;
        moveCarousel();
      }
    }, 4000);
  </script>

  <script>
    let currentIdeaIndex = 0;
    const ideaTexts = document.querySelectorAll('.idea-text');
    const totalIdeas = ideaTexts.length;

    function changeIdeaText() {
      if (totalIdeas > 0) {
        ideaTexts[currentIdeaIndex].classList.remove('active');
        currentIdeaIndex = (currentIdeaIndex + 1) % totalIdeas;
        ideaTexts[currentIdeaIndex].classList.add('active');
      }
    }

    setInterval(changeIdeaText, 4500);
  </script>

  <?php
  if ($conexao && !$conexao->connect_error) {
    $conexao->close();
  }
  ?>

</body>
</html>