<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $licao_id = intval($_POST['licao_id']);
    
    // ... (Verificação de autor mantém igual) ...
    // Para economizar espaço, vou focar na parte de montar a query
    
    $titulo = $_POST['titulo'];
    $materia = $_POST['materia'];
    $email = $_POST['email_contato'];
    
    $obs = isset($_POST['obs']) ? array_values(array_filter($_POST['obs'])) : [];
    $obj = isset($_POST['obj']) ? array_values(array_filter($_POST['obj'])) : [];
    
    $obs_1 = $obs[0]??null; $obs_2 = $obs[1]??null; $obs_3 = $obs[2]??null;
    $obj_1 = $obj[0]??null; $obj_2 = $obj[1]??null; $obj_3 = $obj[2]??null;

    $sql_parts = [
        "TITULO = ?", "MATERIA = ?", "EMAIL_CONTATO = ?",
        "OBSERVACAO_1 = ?", "OBSERVACAO_2 = ?", "OBSERVACAO_3 = ?",
        "OBJETIVOS_1 = ?", "OBJETIVOS_2 = ?", "OBJETIVOS_3 = ?"
    ];
    $types = "sssssssss";
    $params = [$titulo, $materia, $email, $obs_1, $obs_2, $obs_3, $obj_1, $obj_2, $obj_3];
    $blob_data = [];
    $blob_indices = [];

    // Capa e Imagens (Mantém igual ao anterior)
    if (isset($_POST['remover_capa'])) $sql_parts[] = "CAPA = NULL";
    elseif (!empty($_FILES['capa']['tmp_name'])) {
        $sql_parts[] = "CAPA = ?"; $types .= "b"; $params[] = null;
        $blob_data[] = file_get_contents($_FILES['capa']['tmp_name']);
        $blob_indices[] = strlen($types)-1;
    }
    
    // Imagens 1 e 2 (Mantém igual)
    if (isset($_POST['remover_img1'])) $sql_parts[] = "IMAGEM_1 = NULL";
    elseif (!empty($_FILES['img1']['tmp_name'])) {
        $sql_parts[] = "IMAGEM_1 = ?"; $types .= "b"; $params[] = null;
        $blob_data[] = file_get_contents($_FILES['img1']['tmp_name']);
        $blob_indices[] = strlen($types)-1;
    }
    if (isset($_POST['remover_img2'])) $sql_parts[] = "IMAGEM_2 = NULL";
    elseif (!empty($_FILES['img2']['tmp_name'])) {
        $sql_parts[] = "IMAGEM_2 = ?"; $types .= "b"; $params[] = null;
        $blob_data[] = file_get_contents($_FILES['img2']['tmp_name']);
        $blob_indices[] = strlen($types)-1;
    }

    // (MODIFICADO) Anexos: Salva conteúdo E Nome
    if (isset($_POST['remover_anexo1'])) {
        $sql_parts[] = "ANEXO_1 = NULL";
        $sql_parts[] = "NOME_ANEXO_1 = NULL";
    } elseif (!empty($_FILES['anexo1']['tmp_name'])) {
        $sql_parts[] = "ANEXO_1 = ?"; 
        $sql_parts[] = "NOME_ANEXO_1 = ?"; // Salva o nome
        $types .= "bs";
        $params[] = null; // Blob
        $params[] = $_FILES['anexo1']['name']; // Nome
        $blob_data[] = file_get_contents($_FILES['anexo1']['tmp_name']);
        $blob_indices[] = strlen($types)-2; // Índice do blob (2 posições atrás por causa do 's')
    }

    if (isset($_POST['remover_anexo2'])) {
        $sql_parts[] = "ANEXO_2 = NULL";
        $sql_parts[] = "NOME_ANEXO_2 = NULL";
    } elseif (!empty($_FILES['anexo2']['tmp_name'])) {
        $sql_parts[] = "ANEXO_2 = ?";
        $sql_parts[] = "NOME_ANEXO_2 = ?";
        $types .= "bs";
        $params[] = null;
        $params[] = $_FILES['anexo2']['name'];
        $blob_data[] = file_get_contents($_FILES['anexo2']['tmp_name']);
        $blob_indices[] = strlen($types)-2;
    }

    $sql = "UPDATE LICAO SET " . implode(", ", $sql_parts) . " WHERE ID = ?";
    $types .= "i";
    $params[] = $licao_id;

    // Execução (padrão)
    $stmt = $conexao->prepare($sql);
    $bind_params = [$types];
    foreach ($params as $k => &$v) $bind_params[] = &$v;
    call_user_func_array([$stmt, 'bind_param'], $bind_params);
    
    $b_count = 0;
    foreach ($blob_indices as $idx) {
        $stmt->send_long_data($idx, $blob_data[$b_count++]);
    }

    if ($stmt->execute()) {
        header('Location: licao.php?id=' . $licao_id);
    } else {
        echo "Erro: " . $stmt->error;
    }
}
?>