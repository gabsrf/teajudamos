<?php

session_start();

date_default_timezone_set('America/Sao_Paulo');

define('DB_HOST', 'localhost');
define('DB_USER', 'u896535670_user');
define('DB_PASS', 'G4BR13l31460T34JUD4M0S_20102025');
define('DB_NAME', 'u896535670_TEAJUDAMOS');

mysqli_report(MYSQLI_REPORT_OFF);

$conexao = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conexao && !$conexao->connect_error) {
    try {
        @$conexao->query("SET time_zone = 'America/Sao_Paulo'");
        if ($conexao->error) {
            throw new Exception("Timezone name failed, using offset.");
        }
    } catch (Exception $e) {
        $conexao->query("SET time_zone = '-03:00'");
    }

    $conexao->set_charset("utf8mb4");
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);


function redirecionar(string $mensagem, string $tipo = "erro"): void {

    $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
    

    $url = $referer . (strpos($referer, '?') === false ? '?' : '&') . $tipo . '=' . urlencode($mensagem);
    
    header("Location: " . $url);
    exit;
}


if ($conexao->connect_error) {
    error_log("Falha na conexão com o banco de dados: " . $conexao->connect_error);
    redirecionar("Não foi possível conectar ao banco de dados.", "erro");
}

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    session_unset();
    session_destroy();
    header('Location: login.php?erro=' . urlencode('Usuário não logado.'));
    exit;
}

$current_user_id = (int)$_SESSION['user_id'];
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');


if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirecionar("ID do feedback inválido ou ausente.", "erro");
}

$feedback_id = (int) $_GET['id']; // Usa o parâmetro 'id' do link

// ----------------------------------------------------------------------
// 5. VERIFICAÇÃO DE AUTORIZAÇÃO (Dono ou Admin)
// ----------------------------------------------------------------------

// Busca o ID do autor do feedback
$sql_select = "SELECT USUARIO_ID FROM FEEDBACKS_SITE WHERE ID = ?";
$stmt = $conexao->prepare($sql_select);

if (!$stmt) {
    $conexao->close();
    redirecionar("Erro de preparação da consulta: " . $conexao->error, "erro");
}

$stmt->bind_param("i", $feedback_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    $conexao->close();
    redirecionar("Feedback não encontrado.", "erro");
}

$feedback_data = $result->fetch_assoc();
$owner_id = (int) $feedback_data['USUARIO_ID'];
$stmt->close();

// Lógica de Autorização: Deve ser o dono OU o administrador
$is_owner = ($current_user_id === $owner_id);

if (!$is_owner && !$is_admin) {
    // Se não for o dono E não for administrador, nega o acesso.
    $conexao->close();
    redirecionar("Você não tem permissão para excluir este feedback.", "erro");
}

// ----------------------------------------------------------------------
// 6. EXCLUSÃO DO FEEDBACK (Autorizado)
// ----------------------------------------------------------------------

// Prepara a query de exclusão
$sql_delete = "DELETE FROM FEEDBACKS_SITE WHERE ID = ?";
$stmt_delete = $conexao->prepare($sql_delete);

if (!$stmt_delete) {
    $conexao->close();
    redirecionar("Erro de preparação da exclusão: " . $conexao->error, "erro");
}

$stmt_delete->bind_param("i", $feedback_id);

if ($stmt_delete->execute()) {
    $stmt_delete->close();
    $conexao->close();
    
    // Sucesso: Redireciona para a página anterior com uma mensagem de sucesso
    redirecionar("Feedback excluído com sucesso.", "sucesso");

} else {
    // Erro na exclusão
    $error_message = "Erro ao excluir o feedback: " . $stmt_delete->error;
    $stmt_delete->close();
    $conexao->close();
    
    redirecionar($error_message, "erro");
}
?>