<?php
session_start();
include 'conexao.php'; // Assume que 'conexao.php' abre a conexão $conexao
$erro_login = "";

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email_login'];
    $senha = $_POST['senha_login'];

    if ($conexao->connect_error) {
        die("Falha na conexão: " . $conexao->connect_error);
    }


$stmt_admin = $conexao->prepare("SELECT id, email FROM ADMINISTRADORES WHERE email = ? AND senha1 = ?");
$stmt_admin->bind_param("ss", $email, $senha);
$stmt_admin->execute();
$resultado_admin = $stmt_admin->get_result();

if ($resultado_admin->num_rows > 0) {
    $admin = $resultado_admin->fetch_assoc();

    $_SESSION['admin_pending_id'] = $admin['id'];
    $_SESSION['admin_pending_email'] = $admin['email'];
    
    $stmt_admin->close();

    header("Location: login_admin.php");
    exit;
}

$stmt_admin->close();

    $stmt = $conexao->prepare("SELECT ID, NOME, SENHA FROM USUARIOS WHERE EMAIL = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();

        // Verifica a senha do usuário comum (hashed password)
        if (password_verify($senha, $usuario['SENHA'])) {
            // SUCESSO! Cria a sessão
            $_SESSION['user_id'] = $usuario['ID'];
            $_SESSION['user_nome'] = $usuario['NOME'];
            $_SESSION['user_role'] = 'common'; // Definindo role padrão para usuários comuns

            $stmt->close();
            $conexao->close();
            
            // Redireciona para a página principal (usuário comum)
            header("Location: index.php");
            exit;
        } else {
            $erro_login = "E-mail ou senha inválidos.";
        }
    } else {
        $erro_login = "E-mail ou senha inválidos.";
    }
    $stmt->close();
    $conexao->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>LOGIN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logo.png">


    <style>
        /* --- GERAL (DESKTOP) --- */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(#46004A, #8B0091);
            height: 100vh;
            position: relative;
        }

        header {
            position: absolute;
            top: -95px;
            left: 20px;
        }

        .logo img {
            width: 300px;
            height: auto;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        .container {
            width: 520px;
            min-height: 570px;
            background-color: #FFFFFF;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .container p {
            margin-top: 70px;
            font-size: 35px;
            font-weight: bold;
            display: flex;
            justify-content: center;
        }

        .container input[type="email"],
        .password-wrapper input {
            width: 300px;
            height: 35px;
            margin-left: 18%;
            border-radius: 10px;
            margin-top: 25px;
            background-color: #898989;
            color: #000000;
            font-size: 15px;
            font-weight: bold;
            padding: 0 35px 0 10px;
            border: none;
        }

        .container input::placeholder {
            color: rgba(0, 0, 0, 0.69);
        }

        .container a {
            text-decoration: none;
        }

        .container a p {
            margin-top: 10px;
            color: #800080;
            font-size: 15px;
            margin-left: -28%;
            text-decoration: none;
        }

        .container a p:hover {
            text-decoration: underline;
        }

        .container button {
            background-color: rgb(114, 114, 114);
            width: 200px;
            height: 40px;
            margin-left: 30%;
            margin-top: 30px;
            font-size: 20px;
            font-weight: bold;
            color: #4C004C;
            border-radius: 8px;
            cursor: pointer;
            transition: color 0.5s, transform 0.5s ease-in-out, box-shadow 0.5s ease;
            border: none;
        }

        .container button:hover,
        .container button:focus {
            transform: scale(1.05);
            box-shadow: 0 0 15px #46004A;
            background-color: rgb(92, 91, 91);
            color: #ec03ecff;
        }

        .cadastrar {
            display: flex;
            justify-content: center;
            gap: 5px;
        }

        .cadastrar p {
            color: #800080;
            font-size: 18px;
            text-decoration: none;
        }

        .cadastrar a {
            color: #800080;
            margin-top: 0px;
            font-size: 18px;
            text-decoration: none;
            transition: color 0.3s ease-in-out;
        }

        .cadastrar a:hover {
            text-decoration: underline;
            color: #ec03ecff;
        }

        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            width: 300px;
        }

        .toggle-password {
            position: absolute;
            right: 90px;
            top: 70%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 18px;
            color: #4C004C;
        }

        /* Estilo para a mensagem de erro */
        .error-message {
            color: #D8000C;
            background-color: #FFD2D2;
            border: 1px solid #D8000C;
            border-radius: 8px;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            width: 300px;
            margin: 15px auto 0 auto;
            /* Centralizado relativo ao container, ou use margin-left 18% para alinhar com inputs */
            margin-left: 18%;
        }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 480px) {
            body {
                width: 100%;
                height: 90vh;
            }

            .logo img {
                margin-top: 15px;
                margin-left: 10%;
                width: 280px;
            }

            .container {
                width: 85%;
                min-height: auto;
                padding-bottom: 10px;
            }

            .container p {
                font-size: 28px;
                margin-top: 25px;
            }

            .container input[type="email"],
            .container input[type="password"],
            .password-wrapper input {
                width: 90%;
                height: 40px;
                margin-left: 5%;
                margin-right: 5%;
                font-size: 18px;
                box-sizing: border-box;
            }

            .container a p {
                margin-top: 20px;
                margin-left: 0;
                text-align: center;
                width: 100%;
            }

            .toggle-password {
                right: 20px;
                top: 70%;
                font-size: 22px;
            }

            .container button {
                width: 80%;
                margin-left: 10%;
                margin-right: 10%;
            }

            .cadastrar {
                margin-top: 20px;
            }

            .cadastrar p,
            .cadastrar a {
                font-size: 16px;
            }

            .error-message {
                width: 70%;
                margin-left: 12%;
            }
        }
    </style>
</head>

<body>
    <header>
        <a href="index.php">
            <div class="logo">
                <img src="imagens/logo-teajudamos.png" alt="logo">
            </div>
        </a>
    </header>

    <div class="container">
        <p>
            <span style="color: #800080;">TEA</span>
            <span style="color: #000000;">JUDAMOS</span>
        </p>

        <form action="login.php" method="POST">

            <input type="email" name="email_login" placeholder="LOGIN" required>

            <div class="password-wrapper">
                <input type="password" id="senha" name="senha_login" placeholder="SENHA" required>
                <i class="fa-solid fa-eye toggle-password" id="togglePassword"></i>
            </div>

            <br>

            <button type="submit">ENTRAR</button>

            <?php if (!empty($erro_login)): ?>
                <div class="error-message"><?php echo $erro_login; ?></div>
            <?php endif; ?>

        </form>
        <div class="cadastrar">
            <p>Não tem uma conta? <a href="cadastro.php">
                    <p>CADASTRAR</p>
                </a></p>
        </div>

    </div>

    <script>
        const senhaInput = document.getElementById('senha');
        const togglePassword = document.getElementById('togglePassword');

        togglePassword.addEventListener('click', () => {
            const isPassword = senhaInput.type === 'password';
            senhaInput.type = isPassword ? 'text' : 'password';

            togglePassword.classList.toggle('fa-eye');
            togglePassword.classList.toggle('fa-eye-slash');
        });
    </script>

</body>

</html>