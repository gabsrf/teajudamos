<?php
session_start();
include 'conexao.php';

$licao_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$tipo = $_GET['tipo'] ?? 'anexo1'; 

if ($licao_id == 0) die("Erro.");

// Seleciona Coluna de Dados e Coluna de Nome
$col_dados = 'ANEXO_1';
$col_nome = 'NOME_ANEXO_1';

if ($tipo == 'anexo2') {
    $col_dados = 'ANEXO_2';
    $col_nome = 'NOME_ANEXO_2';
}

// Busca os dados
$stmt = $conexao->prepare("SELECT $col_dados, $col_nome, TITULO FROM LICAO WHERE ID = ?");
$stmt->bind_param("i", $licao_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $conteudo = $row[$col_dados];
    $nome_original = $row[$col_nome];
    $titulo_licao = $row['TITULO'];

    if (empty($conteudo)) die("Arquivo vazio.");

    // Usa o nome do banco se existir, senão gera um
    $filename = !empty($nome_original) ? $nome_original : "documento.pdf";

    header("Content-Type: application/pdf");
    header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
    header("Content-Length: " . strlen($conteudo));
    echo $conteudo;
} else {
    die("Arquivo não encontrado.");
}
?>